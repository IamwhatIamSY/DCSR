#include "converter.h"

generate_main(gbbs::converter, false);
