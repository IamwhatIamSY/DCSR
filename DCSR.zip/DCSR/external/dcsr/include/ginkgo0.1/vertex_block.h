#include "types.h"
#include "integer_log2.h"

#include <algorithm>
#include <cassert>
#include <mutex>
#include <sys/mman.h>
#include <vector>

namespace dcsr {

inline Index illegalIndex() { return static_cast<Index>(-1); };
inline Index tombstoneIndex() { return static_cast<Index>(-2); };

// Taken from https://stackoverflow.com/a/12996028.
inline unsigned int hash_node(unsigned int x) {
    x = ((x >> 16) ^ x) * 0x45d9f3b;
    x = ((x >> 16) ^ x) * 0x45d9f3b;
    x = (x >> 16) ^ x;
    return x;
}

inline Index index_hash_table(unsigned int hash, Index current_index,
                                   unsigned int block_size) {
    return (hash + current_index) & (2 * block_size - 1);
}

// define vertex block: degree, index in PMA, a pointer to hash index, and a pointer to the neighbor list
class VertexBlock {
  private:
    Degree degree;
    Offset offset;
    Hsize bsize;
    uintV* nbrs;
    Index* htab;

    void rebuild_ht() {
        Index* const hash_table = htab;

        // Clear the hash table.
        for (size_t j = 0; j < 2 * bsize; ++j) {
            hash_table[j] = illegalIndex();
        }

        // Re-insert all vertices.
        for (size_t i = 0; i < degree; ++i) {
            auto v = nbrs[i];

            // Find a free slot within the hash table.
            unsigned int const h = hash_node(v);
            size_t j = 0; // Hash table index.
            for (Index p = 0; true; ++p) {
                j = index_hash_table(h, p, bsize);

                if (hash_table[j] == illegalIndex() || hash_table[j] == tombstoneIndex()) {
                    break;
                }

                // There cannot be any duplicates.
               // assert(*(nbrs + hash_table[j]) != v);
            }

            // Insert into the hash table.
            hash_table[j] = i;
        }
    }

  public:
    struct iterator {
      private:
        uintV* nbr_ptr;
      
      public:
        using difference_type = ptrdiff_t;
        // In the legacy sense, this is only an input iterator since the reference type
        // is not a true reference. In the modern sense, this is a random access iterator.
        using iterator_category = std::input_iterator_tag;
        using iterator_concept = std::random_access_iterator_tag;

        friend bool operator==(iterator lhs, iterator rhs) { return lhs.nbr_ptr== rhs.nbr_ptr; }
        friend bool operator!=(iterator lhs, iterator rhs) { return lhs.nbr_ptr != rhs.nbr_ptr; }

        friend ptrdiff_t operator-(iterator lhs, iterator rhs) { return lhs.nbr_ptr - rhs.nbr_ptr; }

        iterator() : nbr_ptr(nullptr) {}

        explicit iterator(uintV* ptr) : nbr_ptr(ptr) {}

        iterator operator+(ptrdiff_t delta) const {
            iterator copy = *this;
            copy += delta;
            return copy;
        }

        iterator& operator++() {
            ++nbr_ptr;
            return *this;
        }
        iterator& operator--() {
            --nbr_ptr;
            return *this;
        }
        iterator operator++(int) {
            iterator copy = *this;
            ++(*this);
            return copy;
        }
        iterator operator--(int) {
            iterator copy = *this;
            --(*this);
            return copy;
        }
        iterator& operator+=(ptrdiff_t delta) {
            nbr_ptr += delta;
            return *this;
        }
        iterator& operator-=(ptrdiff_t delta) {
            nbr_ptr -= delta;
            return *this;
        }

        uintV* get_ptr() const { return nbr_ptr; }

    };

    VertexBlock() : degree{0}, offset{UINT_V_MAX}, nbrs{nullptr}, htab{nullptr} {}

    VertexBlock(const VertexBlock&) = delete;

    VertexBlock(VertexBlock&& other) = default;

    VertexBlock& operator=(const VertexBlock&) = delete;

    VertexBlock& operator=(VertexBlock&&) = default;

    ptrdiff_t degree() const { return degree; }

    // Returns true if the neighbor was inserted.
    // Returns false if the neighbor was found.
    bool insert(uintV v) {
        Index* hash_table = htab;
        auto h = hash_node(v);
        Index j;
        Index ts = illegalIndex();
        for (Index i = 0; true; ++i) {
            j = index_hash_table(h, i, bsize);

            if (hash_table[j] == illegalIndex())
                break;
            if (hash_table[j] == tombstoneIndex()) {
                ts = j;
                continue;
            }
            auto nbr = nbrs[hash_table[j]];
            if (nbr == v)
                return false;
        }

        // If we did hit a tombstone, insert at the tombstone.
        if (ts != illegalIndex())
            j = ts;

        // Insert into the adjacency list.
        auto i = degree++;
        htab[j] = i;
        nbrs[i] = v;
        return true;
    }

    // true = node was removed.
    bool remove(uintV const v) {
        Index* const hash_table = htab;

        unsigned int const hv = hash_node(v);
        size_t jv = 0; // Hash table index.
        for (Index i = 0; true; ++i) {
            if (i == bsize) {
                return false;
            }

            jv = index_hash_table(hv, i, bsize);

            if (hash_table[jv] == illegalIndex()) {
                return false;
            }

            if (hash_table[jv] == tombstoneIndex()) {
                continue;
            }

            if (*(nbrs + hash_table[jv]) == v) {
                break;
            }
        }

        auto back_it = std::prev(nbrs + degree);
        if (nbrs + hash_table[jv] != back_it) {
            auto w = *back_it;

            unsigned int const hw = hash_node(w);
            size_t jw = 0; // Hash table index.
            for (Index i = 0; true; ++i) {
                jw = index_hash_table(hw, i, bsize);

                // Otherwise, w is not in the HT.
               // assert(hash_table[jw] != illegalIndex());

                if (hash_table[jw] == tombstoneIndex()) {
                    continue;
                }

                if (*(nbrs + hash_table[jw]) == w) {
                    break;
                }
            }

            *(nbrs + hash_table[jv]) = *back_it;
            hash_table[jw] = hash_table[jv];
        }

        hash_table[jv] = tombstoneIndex();
        --degree;

        return true;
    }

    void clear() {
        degree = 0;
        for (size_t j = 0; j < 2 * bsize; ++j)
            htab[j] = illegalIndex();
    }

    template <typename L> void sort(L less) {
        std::sort(nbrs, nbrs + degree, std::move(less));
        rebuild_ht();
    }

    iterator iterator_to(uintV v) const {
        // Find the node within the hash table.
        auto h = hash_node(v);
        size_t j = 0; // Hash table index.
        Index* const hash_table = htab;
        for (Index i = 0; true; ++i) {
            if (i == bsize)
                return valid_end();
            j = index_hash_table(h, i, bsize);

            if (hash_table[j] == illegalIndex())
                return valid_end();
            if (hash_table[j] == tombstoneIndex())
                continue;
            if (*(nbrs + hash_table[j]) == v)
                break;
        }

        return iterator(nbrs + hash_table[j]);
    }

    bool empty() const { return !degree; }

    bool full() const { return degree == bsize; }

    iterator valid_end() const { return iterator(nbrs + degree); }

    iterator begin() { return iterator(nbrs); }

};


}