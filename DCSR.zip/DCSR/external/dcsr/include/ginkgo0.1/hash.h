#pragma once

#include "integer_log2.h"

#include <algorithm>
#include <cassert>
#include <mutex>
#include <sys/mman.h>
#include <vector>