#pragma once

// #include "batcher.h"
#include "vertex_block2.h"
#include "buckets2.h"
#include "types.h"
#include "PMA.hpp"
#include "gbbs/bridge.h"

#include <variant>
#include <cassert>
#include <functional>
#include <memory>
#include <mutex>
#include <omp.h>
#include <vector>
#include <iterator>
#include <stdlib.h>

namespace dcsr {

// define the max number of vertices in the block
constexpr size_t MAX_BLOCK_NUM = (1ULL << 10); 

// if vertex's degree larger than the threshold, edges should be stored in the edge list
constexpr size_t TO_HASH_NUM = (1ULL << 10);

inline std::vector<Degree> degrees_from(Edges const& edges) {
    // unsigned int count = graph::vertex_count(edges); 
    std::vector<Degree> associated_degree(MAX_BLOCK_NUM, 0u);

    for (Edge const& edge : edges) {
        associated_degree[(edge.source & (MAX_BLOCK_NUM - 1))]++;
    }

    return associated_degree;
}

// define the graph blocks
template <typename E> struct BlockIndex {
  public:

    struct NeighborView {
        using iterator = typename BlockState<E>::iterator;
        using proxy = typename BlockState<E>::proxy;

        NeighborView(BlockIndex* g, Vertex u) : m_g{g}, m_u{u} {}

        auto begin() { return m_g->vblock[m_u].begin(); }

        auto end() { return m_g->vblock[m_u].valid_end(); }

        auto iterator_to(Vertex v) { return m_g->vblock[m_u].iterator_to(v); }

        bool exists(Vertex v) { return iterator_to(v) != end(); }

        void clear() { m_g->vblock[m_u].clear(); }

        size_t degree() { return end() - begin(); }

        proxy operator[](size_t i) { return *(begin() + i); }

        std::tuple<iterator, bool> insert(Vertex v, E ed) {
            auto& state = m_g->vblock[m_u];

            if (!state.full())
                return state.insert(v, ed);

            // We need to reallocate the adjacency block.
            auto new_bhandle = m_g->vmanager->allocate_block(state.bsize() + 1);
            BlockState<E> new_block{new_bhandle, state};
            auto result = new_block.insert(v, ed);

            [[maybe_unused]] auto old_block = std::move(m_g->vblock[m_u]);
            auto old_bhandle = m_g->vhandles[m_u];
            m_g->vblock[m_u] = std::move(new_block);
            m_g->vhandles[m_u] = new_bhandle;
            m_g->vmanager->free_block(old_bhandle);

            return result;
        }
        
      private:
        BlockIndex* m_g;
        Vertex m_u;
    };

    struct ConstNeighborView {
        using iterator = typename BlockState<E>::const_iterator;
        using proxy = typename BlockState<E>::const_proxy;

        ConstNeighborView(const BlockIndex* g, Vertex u) : m_g{g}, m_u{u} {}

        auto begin() { return m_g->vblock[m_u].begin(); }

        auto end() { return m_g->vblock[m_u].valid_end(); }

        auto iterator_to(Vertex v) { return m_g->vblock[m_u].iterator_to(v); }

        bool exists(Vertex v) { return iterator_to(v) != end(); }

        size_t degree() { return end() - begin(); }

        proxy operator[](size_t i) { return *(begin() + i); }

      private:
        const BlockIndex* m_g;
        Vertex m_u;
    };

    friend void swap(BlockIndex& p, BlockIndex& q) noexcept {
        using std::swap;
        swap(p.vblock, q.vblock);
        swap(p.vhandles, q.vhandles);
        swap(p.vmanager, q.vmanager);
        // swap(p.pblock, q.pblock);
    }

    BlockIndex() : BlockIndex(std::make_shared<BlockManager>(bytes_per_entry_for<E>())) {}

    BlockIndex(std::shared_ptr<BlockManager> manager) : vmanager(std::move(manager)) {}

    BlockIndex(Edges&& edges) : BlockIndex{} {
        std::vector<Degree> const extracted_degrees = degrees_from(edges);
        // unsigned int count = graph::vertex_count(edges);
        vblock.reserve(MAX_BLOCK_NUM);
        vhandles.reserve(MAX_BLOCK_NUM);
        // allocate blocks for each vertex
        for (size_t i = 0; i < MAX_BLOCK_NUM; ++i) {
            auto degree = extracted_degrees[i];
            if (degree > TO_HASH_NUM) {
                dcsr::BlockHandle bhandle = vmanager->allocate_block(degree);
                BlockState<E> block{bhandle};
                vblock.push_back(std::move(block));
                vhandles.push_back(bhandle);
            } else {
                dcsr::BlockHandle bhandle = vmanager->allocate_block(0);
                BlockState<E> block{bhandle};
                vblock.push_back(std::move(block));
                vhandles.push_back(bhandle);
            }  
        }

        // insert vertex and it's neighbours to respective block arrays and increase size
        // of block array if necessary
        for (Edges::iterator edge = std::begin(edges); edge != std::end(edges);) {
            Vertex source = edge->source & (MAX_BLOCK_NUM - 1);
            Degree degree = extracted_degrees[source];

            if (degree > TO_HASH_NUM) {
                Vertex next_source = source;
                auto& hblock = vblock[source];
                while (source == next_source && edge != std::end(edges)) {
                    hblock.insert(edge->target.vertex, edge->target.data);
                    ++edge;
                    if (edge != std::end(edges)) {
                        next_source = edge->source & (MAX_BLOCK_NUM - 1);
                    }
                }
            } else {
                Vertex next_source = source;
                while (source == next_source && edge != std::end(edges)) {
                    pblock.add_edge_update(source, edge->target.vertex, edge->target.data.weight);
                    ++edge;
                    if (edge != std::end(edges)) {
                        next_source = edge->source & (MAX_BLOCK_NUM - 1);
                    }
                }
            }  
        }
    }

    BlockIndex(uint32_t vertex_count) : vmanager(std::make_shared<BlockManager>(bytes_per_entry_for<E>())),  pblock(vertex_count) { 
        resize(vertex_count); 
    }

    BlockIndex(const BlockIndex& other) : BlockIndex{} {
        if (other.vertices_count())
            resize(other.vertices_count());
        other.for_edges([&](Vertex u, Vertex v, E ed) { neighbors(u).insert(v, ed); });
    }

    BlockIndex(BlockIndex&& other) noexcept : BlockIndex{} { swap(*this, other); }

    ~BlockIndex() {
        for (auto bhandle : vhandles)
            vmanager->free_block(bhandle);
        // pblock.~PMA();
    }

    BlockIndex& operator=(BlockIndex other) {
        swap(*this, other);
        return *this;
    }

    void resize(uint32_t vertex_count) {
        vblock.resize(vertex_count);
        vhandles.resize(vertex_count);
        // pblock = PMA(vertex_count);
    }

    void preallocate(Vertex u, unsigned int degree) {
        auto& associated_block = vblock[u];

        if (associated_block.bsize() < degree) {
            auto new_bhandle = vmanager->allocate_block(degree);
            BlockState<E> new_block{new_bhandle, associated_block};

            auto old_block = std::move(vblock[u]);
            auto old_bhandle = vhandles[u];
            vblock[u] = std::move(new_block);
            vhandles[u] = new_bhandle;
            vmanager->free_block(old_bhandle);
        }
    }

    bool insert(Vertex u, Vertex v, E ed, bool do_update = true) {
        auto& hblock = vblock[u];
        cout << "hblock.degree() " << hblock.degree() << endl;
        if (!(hblock.degree() > TO_HASH_NUM)) {
            if (pblock.add_edge_update(u, v, 1)) {
                cout << "pblock add edge: " << u << " " << v << endl;
                return true;
            }
            cout << "pblock add edge failed: " << u << " " << v << endl;
            return false;
        } else {
            auto result = neighbors(u).insert(v, ed);
            if (std::get<1>(result))
                return true;
            if (do_update) {
                std::get<0>(result)->data() = ed;
                return true;
            }
            return false;
        } 
    }

    template <typename EdgeIt> void insert(EdgeIt begin, EdgeIt end, bool do_update = true) {
        for (Edges::const_iterator edge = begin; edge != end; ++edge) {
            insert(edge->source, edge->target.vertex, edge->target.data, do_update);
        }
    }

    bool removeEdge(Vertex source, Vertex target) {
        if (source >= vblock.size()) {
            return false;
        }

        auto& associated_block = vblock[source];
        if (associated_block.degree() > TO_HASH_NUM) {
            if (associated_block.remove(target)) {
                return true;
            }
            return false;
        } else {
            if (pblock.remove_edge(source, target)) {
                return true;
            }
            return false;
        }
    }

    template <typename L> void sort(Vertex u, L less) { vblock[u].sort(std::move(less)); }

    NeighborView neighbors(Vertex u) { return {this, u}; }

    ConstNeighborView neighbors(Vertex u) const { return {this, u}; }

    template <typename F> void for_nodes(F&& handle) const {
        for (Vertex node = 0; node < vblock.size(); ++node) {
            handle(node);
        }
    }

    template <typename F> void for_edges(F&& handle) const {
        for (Vertex i = 0; i < vblock.size(); ++i) {
            if (vblock[i].degree() > 0) {
                auto& block = vblock[i];
                for (auto it = block.cbegin(); it != block.valid_end(); it++) {
                    handle(i, it->vertex(), it->data());
                }
            }
        }
    }

    template <typename F> void for_neighbors_node(Vertex const node, F&& handle) const {
       // assert(node < vblock.size());
        auto& block = vblock[node];

        for (auto it = block.cbegin(); it != block.valid_end(); it++) {
            handle(it->vertex());
        }
    }

    template <typename F> void for_neighbors_target(Vertex const node, F&& handle) const {
       // assert(node < vblock.size());
        auto& block = vblock[node];

        for (auto it = block.cbegin(); it != block.valid_end(); it++) {
            handle(it->vertex(), it->data());
        }
    }

    Vertex degree(Vertex node) const {
        // cout << "node: " << node << endl;
       // assert(node < vblock.size());
        if (!(vblock[node].degree() > TO_HASH_NUM)) {
            // cout << "pdegree: " << pblock.nodes[node].num_neighbors << endl;
            return pblock.nodes[node].num_neighbors;
        } else {
            // cout << "hdegree: " << vblock[node].degree() << endl;
            return vblock[node].degree();
        }
    }

    Vertex vertices_count() const { return vblock.size(); }

    Vertex edges_count() const {
        return std::accumulate(
            std::cbegin(vblock), std::end(vblock), 0u,
            [](Vertex sum, const BlockState<E>& block) { return sum + block.degree(); });
    }

    std::vector<BlockState<E>> vblock;
    PMA pblock;

  private:
    std::vector<BlockHandle> vhandles;
    std::shared_ptr<BlockManager> vmanager;
};

template <typename E> class dcsr {
  public:
    dcsr(uint32_t num_v); // create a graph with the given size (#num nodes)

    // dcsr(std::string prefix); // read graph from disk

    ~dcsr();

    // void dcsr(std::string prefix); // write graph to disk

    bool add_edge(const Vertex s, const Vertex d, E ed);

    bool remove_edge(const Vertex s, const Vertex d);

    // void build_from_batch(Vertex *srcs, Vertex *dests, uint32_t vertex_count, uint32_t edge_count);
    
    // check for the existence of the edge
    // uint32_t is_edge(const Vertex s, const Vertex d);
    // get out neighbors of vertex s

    BlockIndex<E>::ConstNeighborView neighbors(const Vertex v) const;
    // get out degree of vertex v
    Degree degree(const Vertex v) const;
    
    //uint64_t get_size(void);

    // uint32_t get_max_degree(void) const;
    template <class F>
    void map_neighbors(size_t i, F &&f) const;

    template <class F>
    void map_neighbors_early_exit(size_t i, F &&f) const;

    size_t get_num_edges(void) const;

    Vertex get_num_vertices(void) const;
  
  private:
    std::vector<BlockIndex<E>> a_block;
    Vertex num_vertices{0};
    size_t num_edges{0};
    // uint32_t max_degree{0};
};

template <typename E>
inline dcsr<E>::dcsr(uint32_t num_v) : num_vertices(num_v) {
    // get the number of blocks
	unsigned int num_b = (num_v + MAX_BLOCK_NUM - 1) >> integer_log2_ceil(MAX_BLOCK_NUM);
    a_block.reserve(num_b);
    cout << "num_b: " << num_b << endl;
    for (unsigned int i = 0; i < num_b; ++i) {
        // initialize the block and push it to the vector
        BlockIndex<E> block{MAX_BLOCK_NUM};
        a_block.push_back(std::move(block));
    }
}

template <typename E>
inline dcsr<E>::~dcsr() {
    // free the blocks
    for (auto& block : a_block) {
        block.~BlockIndex();
    }
}

template <typename E>
inline bool dcsr<E>::add_edge(const Vertex s, const Vertex d, E ed) {
    // check if the edge already exists
    //if (is_edge(s, d)) {
        //return false;
    //}
    // get the block index
    unsigned int block_index = s >> integer_log2_ceil(MAX_BLOCK_NUM);
    unsigned int s_id = s & (MAX_BLOCK_NUM - 1);
    // add the edge to the block
    cout << "s: " << s << " d: " << d << endl;
    cout << "block_index: " << block_index << " s_id: " << s_id << endl;
    a_block[block_index].insert(s_id, d, ed, 1);
    num_edges++;
    return true;
}

template <typename E>
inline bool dcsr<E>::remove_edge(const Vertex s, const Vertex d) {
    // check if the edge exists
    //if (!is_edge(s, d)) {
        //return false;
    //}
    // get the block index
    unsigned int block_index = s >> integer_log2_ceil(MAX_BLOCK_NUM);
    unsigned int s_id = s & (MAX_BLOCK_NUM - 1);
    // remove the edge from the block
    a_block[block_index].removeEdge(s_id, d);
    num_edges--;
    return true;
}

template <typename E>
inline typename BlockIndex<E>::ConstNeighborView dcsr<E>::neighbors(const Vertex v) const{
    // get the block index
    unsigned int block_index = v >> integer_log2_ceil(MAX_BLOCK_NUM);
    unsigned int v_id = v & (MAX_BLOCK_NUM - 1);
    // get the neighbors of the vertex
    auto neighbors = a_block[block_index].neighbors(v_id);
    return neighbors;
}

template <typename E>
inline Degree dcsr<E>::degree(const Vertex v) const {
    // get the block index
    unsigned int block_index = v >> integer_log2_ceil(MAX_BLOCK_NUM);
    unsigned int v_id = v & (MAX_BLOCK_NUM - 1);
    // get the degree of the vertex
    auto degree = a_block[block_index].degree(v_id);
    return degree;
}


template <typename E>
inline size_t dcsr<E>::get_num_edges(void) const {
	return num_edges;
}

template <typename E>
inline Vertex dcsr<E>::get_num_vertices(void) const {
    return num_vertices;
}

template <typename E>
template <class F>
inline void dcsr<E>::map_neighbors(size_t i, F &&f) const {
    // get the block index
    unsigned int block_index = i >> integer_log2_ceil(MAX_BLOCK_NUM);
    unsigned int v_id = i & (MAX_BLOCK_NUM - 1);
    if (a_block[block_index].degree(v_id) > TO_HASH_NUM) {
        auto neighbors = a_block[block_index].neighbors(v_id);
        for (auto neighbor : neighbors) {
            size_t other_vertex = neighbor.vertex();
            E weight = neighbor.data();
            f(i, other_vertex, weight);
        }
    } else {
        uint64_t start = a_block[block_index].pblock.nodes[i].beginning + 1;
        uint64_t end = a_block[block_index].pblock.nodes[i].end;
        E empty_weight = E();
        for (uint64_t j = start; j < end; j++) {
            if (a_block[block_index].pblock.edges.dests[j] != NULL_VAL) {
                f(i, a_block[block_index].pblock.edges.dests[j], empty_weight);
            }
        }    
    }
}

template <typename E>
template <class F>
inline void dcsr<E>::map_neighbors_early_exit(size_t i, F &&f) const {
    // get the block index
    unsigned int block_index = i >> integer_log2_ceil(MAX_BLOCK_NUM);
    unsigned int v_id = i & (MAX_BLOCK_NUM - 1);
    if (a_block[block_index].degree(v_id) > TO_HASH_NUM) {
        auto neighbors = a_block[block_index].neighbors(v_id);
        for (auto neighbor : neighbors) {
            size_t other_vertex = neighbor.vertex();
            E weight = neighbor.data();
            if (f(i, other_vertex, weight)) {
                return;
            }
        }
    } else {
        uint64_t start = a_block[block_index].pblock.nodes[i].beginning + 1;
        uint64_t end = a_block[block_index].pblock.nodes[i].end;
        E empty_weight = E();
        for (uint64_t j = start; j < end; j++) {
            if (a_block[block_index].pblock.edges.dests[j] != NULL_VAL) {
                if (f(i, a_block[block_index].pblock.edges.dests[j], empty_weight)) {
                    break;
                }
            }
        }
    }
}

} // namespace dcsr
