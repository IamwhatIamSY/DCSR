#pragma once

#include <limits>
#include <random>
#include <tuple>
#include <vector>

namespace dcsr {

/*
// define vertex, degree and offset types
#if defined(VERTEXLONG)
typedef long intV;
typedef unsigned long uintV;
typedef unsigned long Degree;
typedef unsigned long Offset;
using Index = size_t;
#define INT_V_MAX LONG_MAX
#define UINT_V_MAX ULONG_MAX
#else
typedef int intV;
typedef unsigned int uintV;
typedef unsigned int Degree;
typedef unsigned int Offset;
#define INT_V_MAX INT_MAX
#define UINT_V_MAX UINT_MAX
#endif

// define edge types
#if defined(EDGELONG)
typedef long intE;
typedef unsigned long uintE;
#define INT_E_MAX LONG_MAX
#define UINT_E_MAX ULONG_MAX
#else
typedef int intE;
typedef unsigned int uintE;
#define INT_E_MAX INT_MAX
#define UINT_E_MAX UINT_MAX
#endif

// define weight types
typedef double Weight;


// define hash table types
typedef unsigned int Index;
typedef unsigned int Hsize;
*/

using Weight = double;
using Degree = unsigned int;
#ifdef DHB_64BIT_IDS
using Vertex = uint64_t;
using EdgeID = uint64_t;
#else
using Vertex = uint32_t;
using EdgeID = uint32_t;
#endif

struct EdgeData {
    Weight weight;
    EdgeID id;
};

struct Target {
    Vertex vertex;
    EdgeData data;
};

struct Edge {
    Edge() = default;

    Edge(Vertex _source, Target _target) : source(_source), target(_target) {}

    Vertex source;
    Target target;
};

using Edges = std::vector<Edge>;
using Targets = std::vector<Target>;

Vertex invalidVertex();
Weight invalidWeight();
EdgeID invalidEdgeID();
Edge invalidEdge();
Target invalidTarget();

namespace graph {
inline Vertex vertex_count(Edges const& edges) {
    // Determine n as the maximal node ID.
    Vertex n = 0;
    for (Edge const& edge : edges) {
        Vertex const vertex = std::max(edge.source, edge.target.vertex);
        n = std::max(n, vertex);
    }

    n += 1;
    return n;
}
inline Edge into(Vertex source, Target const&);
inline Target into(Edge const&);
} // namespace graph

inline Vertex invalidVertex() { return std::numeric_limits<Vertex>::max(); }
inline Weight invalidWeight() { return std::numeric_limits<float>::infinity(); }
inline EdgeID invalidEdgeID() { return std::numeric_limits<EdgeID>::max(); }

inline Edge invalidEdge() { return Edge(invalidVertex(), invalidTarget()); }

inline Target invalidTarget() { return {invalidVertex(), {invalidWeight(), invalidEdgeID()}}; }

}
