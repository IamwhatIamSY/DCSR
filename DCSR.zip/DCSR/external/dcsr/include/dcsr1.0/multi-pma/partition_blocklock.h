// Discription: the main structure of dcsr subgraph

using namespace std;

#pragma once

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <vector>
#include <tuple>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <immintrin.h>
#include <atomic>
#include <stdint.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream> 
#include <string> 
#include <malloc.h>

#include "ParallelTools/parallel.h"
#include "ParallelTools/reducer.h"
#include "gbbs/bridge.h"
#include "pma_lock.hpp"

#include <cassert>
#include <mutex>
#include <sys/mman.h>
#include "types.h"
#include "integer_log2.h"

#include <immintrin.h>
#include <iostream>
#include <iomanip>  

namespace dcsr {

// define the null value in the dcsr
#define NULL_VAL (UINT32_MAX)
// define the sentinel value in the pma
#define SENT_VAL (UINT32_MAX - 1)
// define the lower density bound for the pma
// #define LOWER_DENSITY_BOUND (0.25)

// define the max number of vertices in the block
// MAX_PMA_SIZE should be the max memory size of the PMA, each vertex can store 32 edges in average
constexpr size_t MAX_PMA_SIZE = 64 * 64 * 64 * 64; // 128 cache lines
// define the max number of vertices in the node array
constexpr size_t MAX_NODE_NUM = 1 << 6; // 1 million vertices
// define the threshold for high degree vertices, the edges of which should be stores in the hash
constexpr size_t HIGH_DEGREE_T = 1024000000; 

// define the hash index type
using index_type = size_t;

typedef struct _edge {
  uint32_t value;
  uint32_t dest;
} edge_t;

typedef struct _node {
  // beginning and end of the associated region in the edge list
  uint_t beginning;     // deleted = max int
  uint_t end;
  uint32_t degree; // number of edges with this node as source
  uint32_t hash_id;
} node_t;

typedef struct _pma {
// this stores the num of edges in the pma, we maybe need another
// variable to store the number of edges in the hash table?
  uint_t N; // edges in pma
  uint_t H; // we do not need to store the height of the pma, we can calculate it from N
  uint_t logN;
  uint32_t *vals; // pointer to the values of the edges
  uint32_t *dests; // pointer to the destinations of the edges
} pma_t;

typedef struct hash_list {
  uint32_t bsize; // size of the hash Block
  uint32_t *bdests; // pointer to the destinations of the edges
  uint32_t *bvals; // pointer to the values of the edges
  index_type *htab; // pointer to the hash index
} hash_list_t;

class BLOCK {
public:
  PMA_LOCK block_lock;
  std::vector<hash_list_t> hash_lists;
  pma_t pma_edges;
  node_t nodes[MAX_NODE_NUM];
  
  // BLOCK OPERATIONS
  BLOCK();
  ~BLOCK();
  void print_graph();
  void init_node();
  void clear();
  void build_from_edges(uint32_t *srcs, uint32_t *dests, uint8_t * pma_edges, uint_t vertex_count, uint_t edge_count, uint32_t* additional_degrees);

  // PMA OPERATIONS
  void double_list();
  void half_list();
  void slide_right(uint_t index);
  void slide_left(uint_t index);
  void redistribute(uint_t index, int len);
  // void fix_sentinel_build(uint32_t node_index, uint32_t node_index_last, uint_t in);
  void fix_sentinel(uint32_t node_index, uint_t in);
  uint32_t find_value(uint32_t src, uint32_t dest);
  bool pma_insert(uint_t index, edge_t elem, uint32_t src);
  bool pma_delete(uint_t index, edge_t elem, uint32_t src);
  
  // HASH OPERATIONS
  void rebuild_hash(uint32_t src);
  void double_hash(uint32_t src);
  bool hash_insert(uint32_t src, edge_t elem);
  bool hash_delete(uint32_t src, edge_t elem);

  // update operations
  void add_edge(uint32_t src, uint32_t dest, uint32_t value);
  // void add_edge_update(uint32_t src, uint32_t dest, uint32_t value);
  void remove_edge(uint32_t src, uint32_t dest);

  // find operations
  uint_t get_size();
  // figure out whether we need this
  // uint_t get_n() const;
  // vector<tuple<uint32_t, uint32_t, uint32_t>> get_edges();
};

inline index_type illegalIndex() { return static_cast<index_type>(-1); };
inline index_type tombstoneIndex() { return static_cast<index_type>(-2); };

// To deal with the hash conflict?
inline index_type index_hash_table(unsigned int hash, index_type current_index,
                                   unsigned int bsize) {
    return (hash + current_index) & (2 * bsize - 1);
}

// Taken from https://stackoverflow.com/a/12996028.
inline unsigned int hash_node(unsigned int x) {
    x = ((x >> 16) ^ x) * 0x45d9f3b;
    x = ((x >> 16) ^ x) * 0x45d9f3b;
    x = (x >> 16) ^ x;
    return x;
}

int isPowerOfTwo(int x) { return ((x != 0) && !(x & (x - 1))); }

int find_node(int index, int len) { return (index / len) * len; }

//bool is_sentinel(edge_t e) {
  //return e.dest == SENT_VAL;
//}

// bool is_null(edge_t e) { return e.dest == NULL_VAL; }

double get_density(pma_t *list, int index, int len) {
  int full = 0;
  for (int i = index; i < index + len; i++) {
    full += (list->dests[i]!= NULL_VAL);
  }
  double full_d = (double)full;
  return full_d / len;
}

// height of this node in the tree
int get_depth(pma_t *list, int len) { return bsr_word(list->N / len); }

// get parent of this node in the tree
pair_int get_parent(pma_t *list, int index, int len) {
  int parent_len = len * 2;
  int depth = get_depth(list, len);
  pair_int pair;
  pair.x = parent_len;
  pair.y = depth;
  return pair;
}

// we do nt need keep the density bound, we set the upper bound to be 1
// and set the lower bound to be 1/4
// or we can adynamically adjust the density bound

// when adjusting the list size, make sure you're still in the
// density bound
pair_double density_bound(pma_t *list, int depth) {
  pair_double pair;

  // between 1/4 and 1/2
  // pair.x = 1.0/2.0 - (( .25*depth)/list->H);
  // between 1/8 and 1/4
  pair.x = 1.0 / 4.0 - ((.125 * depth) / list->H);
  pair.y = 3.0 / 4.0 + ((.25 * depth) / list->H);
  return pair;
}

// true if e1, e2 are equals
bool edge_equals(edge_t e1, edge_t e2) {
  return e1.dest == e2.dest && e1.value == e2.value;
}

// given index, return the starting index of the leaf it is in
int find_leaf(pma_t *list, int index) {
  return (index / list->logN) * list->logN;
}

void print_array(pma_t *list, uint_t index, int len) {
  for (uint_t i = index; i < index + len; i++) {
    // printf("(%d, %u)", i, list->items[i].dest);
  }
  // printf("\n");
}

// important: make sure start, end don't include sentinels
// returns the index of the smallest element bigger than you in the range
// [start, end) if no such element is found, returns end (because insert shifts
// everything to the right)
uint32_t binary_search(pma_t *list, edge_t *elem, uint32_t start,
                       uint32_t end) {
  while (start + 1 < end) {
    uint32_t mid = (start + end) / 2;

    uint32_t item = list->dests[mid];
    uint32_t change = 1;
    uint32_t check = mid;

    bool flag = true;
    while ((item == NULL_VAL) && flag) {
      flag = false;
      check = mid + change;
      if (check < end) {
        flag = true;
        if (check <= end) {
          item = list->dests[check];
          if (item != NULL_VAL) {
            break;
          } else if (check == end) {
            break;
          }
        }
      }
      check = mid - change;
      if (check >= start) {
        flag = true;
        item = list->dests[check];
      }
      change++;
    }

    if ((item == NULL_VAL) || start == check || end == check) {
      if ((item != NULL_VAL) && start == check && elem->dest <= item) {
        return check;
      }
      return mid;
    }

    // if we found it, return
    if (elem->dest == item) {
      return check;
    } else if (elem->dest < item) {
      end =
          check; // if the searched for item is less than current item, set end
    } else {
      start = check;
      // otherwise, searched for item is more than current and we set start
    }
  }
  if (end < start) {
    start = end;
  }
  // handling the case where there is one element left
  // if you are leq, return start (index where elt is)
  // otherwise, return end (no element greater than you in the range)
  // // // // printf("start = %d, end = %d, n = %d\n", start,end, list->N);
  if (elem->dest <= list->dests[start] && (list->dests[start] != NULL_VAL)) {
    return start;
  }
  return end;
}

// at beginning, we allocate some edges (pma_edges.N = 2^(bsr_word(MAX_NODE_NUM) + 1), pma_edges.N > init_n)
// in pma, and initialize the nodes
BLOCK::BLOCK() {
  // pma_edges.N = 2^(bsr_word(MAX_NODE_NUM) + 1), MAX_NODE_NUM > init_n
  uint32_t init_n = MAX_NODE_NUM;
  block_lock = PMA_LOCK();
  pma_edges.N = 2 << bsr_word(init_n);
  pma_edges.logN = (1 << bsr_word(bsr_word(pma_edges.N) + 1));
  pma_edges.H = bsr_word(pma_edges.N / pma_edges.logN);
  // // // // printf("pma_edges.N = %u, pma_edges.logN = %u, pma_edges.H = %u\n", pma_edges.N, pma_edges.logN, pma_edges.H);
  // the difference between aligned_alloc and malloc
  // pma_edges.items = (edge_t *)aligned_alloc(32, pma_edges.N * sizeof(*(pma_edges.items)));
  pma_edges.vals = (uint32_t *)aligned_alloc(64, pma_edges.N * sizeof(uint32_t));
  pma_edges.dests = (uint32_t *)aligned_alloc(64, pma_edges.N * sizeof(uint32_t));
  // we initialize the pma edges to be empty
  for (int i = 0; i < pma_edges.N; i++) {
    pma_edges.vals[i] = NULL_VAL;
    pma_edges.dests[i] = NULL_VAL;
  }
  // we have already allocated the nodes, so we do not need to add them
  // but we need initialize the nodes
  init_node();
  // // // printf("malloc_usable_size(pma_edges.items), %u \n", malloc_usable_size(pma_edges.items));
  // hash_lists.reserve(1); // reserve space for the first hash list
}

BLOCK::~BLOCK() { 
    free(pma_edges.vals); 
    free(pma_edges.dests);
    for (auto &hash_list : hash_lists) {
        free(hash_list.bdests);
        free(hash_list.bvals);
        free(hash_list.htab);
    }
}

void BLOCK::print_graph() {
  int num_vertices = MAX_NODE_NUM;
  // printf("pma_edges.N = %u, pma_edges.logN = %u, pma_edges.H = %u \n", pma_edges.N, pma_edges.logN, pma_edges.H);
  for (int i = 0; i < num_vertices; i++) {
    // +1 to avoid sentinel
    //int matrix_index = 0;
    printf("%u, %u, %u, %u\n", i, nodes[i].beginning, nodes[i].end, nodes[i].degree);
    // if the edges of the node are in the pma, print pma edges, else in the 
    // hash table, print hash edges
    if (nodes[i].hash_id == NULL_VAL) { 
        for (uint32_t j = nodes[i].beginning + 1; j < nodes[i].end; j++) {
            //if (!is_null(pma_edges.items[j])) {
                //while (matrix_index < pma_edges.items[j].dest) {
                    ////// // printf("000 ");
                    //matrix_index++;
                ////}
                printf("%03d ", pma_edges.dests[j]);
                //matrix_index++;
            //}
        }
        printf("\n");
        //for (uint32_t j = matrix_index; j < num_vertices; j++) {
           // // // printf("000 ");
        //}
    } else {
      // if (nodes[i].hash_id != NULL_VAL) {
        // print the edges in the hash list
        for (uint32_t j = 0; j < nodes[i].degree; j++) {
            //if (!is_null(edge)) { // the edges in hash tabel may not be null
                //while (matrix_index < edge.dest) {
                    //// // printf("000 ");
                    //matrix_index++;
                //}
                printf("%03d ", hash_lists[nodes[i].hash_id].bdests[j]);
                //matrix_index++;
            //}
        }
        //for (uint32_t j = matrix_index; j < num_vertices; j++) {
            //// // printf("000 ");
        //}
        printf("\n");
      }
    // // printf("\n");
  }
}

// initialize the nodes in the block
void inline BLOCK::init_node() {
  for (uint32_t i = 0; i < MAX_NODE_NUM; i++) {
    edge_t sentinel;
    sentinel.dest = SENT_VAL; // placeholder
    sentinel.value = i;       // back pointer
    if (i == 0) {
      nodes[i].beginning = 0;
      nodes[i].end = 1;
      // why we should specially handle the sentinel of the first node?
      // sentinel.value = SENT_VAL; 
    } else {
      nodes[i].beginning = nodes[i-1].end;
      nodes[i].end = nodes[i].beginning + 1;
    }
    nodes[i].degree = 0;
    nodes[i].hash_id = NULL_VAL; // no hash id assigned yet
    // insert the sentinel at nodes[i].beginning
    // should we parallelize this?
    // // // // printf("inserting sentinel %u at position %u\n", i, nodes[i].beginning);
    pma_insert(nodes[i].beginning, sentinel, i);
  } 
}

void BLOCK::clear() {
  // clear the pma edges
   free(pma_edges.vals);
   free(pma_edges.dests);
   int n = 0;
   pma_edges.N = 2 << bsr_word(n);
   pma_edges.logN = (1 << bsr_word(bsr_word(pma_edges.N) + 1));
   pma_edges.H = bsr_word(pma_edges.N / pma_edges.logN);
  
  // clear the nodes
  for (int i = 0; i < MAX_NODE_NUM; i++) {
    nodes[i].beginning = 0;
    nodes[i].end = 0;
    nodes[i].degree = 0;
    nodes[i].hash_id = NULL_VAL; // no hash id assigned yet
  }
  
  // clear the hash lists
  for (auto &hash_list : hash_lists) {
    free(hash_list.bdests);
    free(hash_list.bvals);
    free(hash_list.htab);
    hash_list.bdests = nullptr;
    hash_list.bvals = nullptr;
    hash_list.htab = nullptr;
    hash_list.bsize = 0;
  }
}


void inline BLOCK::build_from_edges(uint32_t *srcs, uint32_t *dests, uint8_t * edges, uint_t vertex_count, uint_t edge_count, uint32_t* additional_degrees) {
  // step 1 : build a CSR offset array
  uint32_t* vertex_array = (uint32_t*)calloc(vertex_count, sizeof(uint32_t)); // calloc初始化为0
  uint_t edges_num = 0;
  for (uint_t i = 0; i < edge_count; i++) {
    if (edges[i]) {
      uint32_t s = srcs[i];
      additional_degrees[s]++;
      vertex_array[s]++;
      edges_num++;
    }
  }

  // step 2 : build a CSR edges array
  uint32_t* edges_array = (uint32_t*)malloc(edges_num * sizeof(uint32_t));
  uint_t edges_so_far = 0;
  for (uint_t i = 0; i < edge_count; i++) {
    if (edges[i]) {
      edges_array[edges_so_far] = dests[i];
      edges_so_far++;
    }
  }
  
  // step 3 : calculate the CSR offset array and get the degree of nodes
  uint_t pma_edges_num = 0;
  nodes[0].degree = additional_degrees[0];
  if (additional_degrees[0] < HIGH_DEGREE_T) {
    nodes[0].hash_id = NULL_VAL; // no hash id assigned yet
    pma_edges_num += additional_degrees[0];
  }

  for (uint32_t i = 1; i < vertex_count; i++) {
    vertex_array[i] += vertex_array[i-1];
    nodes[i].degree = additional_degrees[i];

    // calculate the pma_edges_num
    if (additional_degrees[i] < HIGH_DEGREE_T) {
      nodes[i].hash_id = NULL_VAL; // no hash id assigned yet
      pma_edges_num += additional_degrees[i];
    }
  }
  // we keep sentinels for all the nodes
  uint_t num_elts = vertex_count + pma_edges_num;
  // // // printf("pma_node_num %u, pma_edges_num %u, num_elts %u \n", pma_node_num, pma_edges_num, num_elts);
  // from double_list
  pma_edges.N = 2 << bsr_word(num_elts);
  pma_edges.logN = (1 << bsr_word(bsr_word(pma_edges.N) + 1));
  pma_edges.H = bsr_word(pma_edges.N / pma_edges.logN);

  uint32_t *space_vals = (uint32_t *)aligned_alloc(64, num_elts * sizeof(uint32_t));
  uint32_t *space_dests = (uint32_t *)aligned_alloc(64, num_elts * sizeof(uint32_t));

  // step 2: write the edges at the front of the pma array or put them in the hash table
  uint_t position_so_far = 0;
  for (uint_t i = 0; i < vertex_count; i++) {
    // set the sentinels for all the nodes
    space_dests[position_so_far] = SENT_VAL;
    space_vals[position_so_far] = i;
    position_so_far++;
    // then write the edges
    if (additional_degrees[i] < HIGH_DEGREE_T) {
      for (uint_t j = 0; j < additional_degrees[i]; j++) {
        if (i == 0) {
          space_dests[position_so_far] = edges_array[j];
          space_vals[position_so_far] = 1;
        } else {
          space_dests[position_so_far] = edges_array[vertex_array[i - 1] + j];
          space_vals[position_so_far] = 1;
        }
        position_so_far++;
      }
    } else {
      hash_list_t hash_list;
      hash_list.bsize = 2 << bsr_word(additional_degrees[i]);
      hash_list.bdests = (uint32_t *)aligned_alloc(64, hash_list.bsize * sizeof(uint32_t));
      hash_list.bvals = (uint32_t *)aligned_alloc(64, hash_list.bsize * sizeof(uint32_t));
      hash_list.htab = (index_type *)aligned_alloc(64, 2 * hash_list.bsize * sizeof(index_type));
      for (uint_t j = 0; j < additional_degrees[i]; j++) {
        if (i == 0) {
          hash_list.bdests[j] = edges_array[j];
          hash_list.bvals[j] = 1;
        } else {
          hash_list.bdests[j] = edges_array[vertex_array[i - 1] + j];
          hash_list.bvals[j] = 1;
        }
      }
      nodes[i].hash_id = hash_lists.size();
      hash_lists.push_back(std::move(hash_list));
      rebuild_hash(i);
    }
  }
 // assert(num_elts == position_so_far);

  // step 3: redistribute the pma
  uint_t num_leaves = pma_edges.N / pma_edges.logN;
  uint_t count_per_leaf = num_elts / num_leaves;
  uint_t extra = num_elts % num_leaves;
  // // // printf("num_leaves = %u, count_per_leaf = %u, extra = %u\n", num_leaves, count_per_leaf, extra);
  // // // printf("pma_edges.N = %u, pma_edges.logN = %u, pma_edges.H = %u\n", pma_edges.N, pma_edges.logN, pma_edges.H);
  
  uint32_t *new_vals = (uint32_t *)aligned_alloc(64, pma_edges.N * sizeof(uint32_t));
  uint32_t *new_dests = (uint32_t *)aligned_alloc(64, pma_edges.N * sizeof(uint32_t));
  // printf("pma_edges.N = %u \n", pma_edges.N);
  parlay::parallel_for (0, pma_edges.N, [&](uint_t i) {
    new_vals[i] = NULL_VAL; // setting to null
    new_dests[i] = NULL_VAL; // setting to null
  });
  
  //parlay::parallel_for(0, num_leaves, [&](uint_t i) {
  // uint32_t node_index_last = NULL_VAL;
  for(uint_t i = 0; i < num_leaves; i++) {
    // how many are going to this leaf
    uint_t count_for_leaf = count_per_leaf + (i < extra);
    // start of leaf in output
    uint_t in = ((i) << bsr_word(pma_edges.logN));
    // start in input
    uint_t j2 = count_per_leaf*i +min(i,extra);
    uint_t j3 = j2;
    // // // // printf("real count %u, num_leaves %u, leaf %u, count_for_leaf = %u, in = %u, j2 = %u, j3 = %u\n", num_elts, num_leaves, i, count_for_leaf, in, j2, j3);
    for(uint_t k = in; k < count_for_leaf+in; k++) {
     // assert(j2 < num_elts);
      new_vals[k] = space_vals[j2];
      j2++;
    }
    for (uint_t k = in; k < count_for_leaf+in; k++) {
      new_dests[k] = space_dests[j3];
      if (new_dests[k] == SENT_VAL) {
        // fixing pointer of node that goes to this sentinel
        uint32_t node_index = space_vals[j3];
        fix_sentinel(node_index, k);
      }
      j3++;
    } 
  }

  free(space_dests);
  free(space_vals);
  free(vertex_array);
  free(edges_array);
  free(pma_edges.vals);
  free(pma_edges.dests); 
  pma_edges.vals = new_vals;
  pma_edges.dests = new_dests;
}
  
void BLOCK::double_list() {
  pma_edges.N *= 2;
  pma_edges.logN = (1 << bsr_word(bsr_word(pma_edges.N) + 1));
  pma_edges.H = bsr_word(pma_edges.N / pma_edges.logN);
  // pma_edges.vals =
      // (uint32_t *)realloc(pma_edges.vals, pma_edges.N * sizeof(*(pma_edges.vals)));
  // pma_edges.dests =
      // (uint32_t *)realloc(pma_edges.dests, pma_edges.N * sizeof(*(pma_edges.dests)));
  uint32_t *new_dests = (uint32_t *)aligned_alloc(64, pma_edges.N * sizeof(*(pma_edges.dests)));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(64, pma_edges.N * sizeof(*(pma_edges.vals)));
  //for (int i = 0; i < pma_edges.N / 2; i++) {
    //new_vals[i] = pma_edges.vals[i]; // setting second half to null
    //new_dests[i] = pma_edges.dests[i];  // setting second half to null
  //}
  std::memcpy(new_vals, pma_edges.vals, (pma_edges.N / 2) * sizeof(uint32_t));
  std::memcpy(new_dests, pma_edges.dests, (pma_edges.N / 2) * sizeof(uint32_t));
  for (int i = pma_edges.N / 2; i < pma_edges.N; i++) {
    new_vals[i] = NULL_VAL; // setting second half to null
    new_dests[i] = NULL_VAL;  // setting second half to null
  }
  // printf("before free \n");
  free(pma_edges.dests);
  free(pma_edges.vals);
  // printf("after free \n");
  pma_edges.dests = new_dests;
  pma_edges.vals = new_vals;
  redistribute(0, pma_edges.N);
  // printf("doubling the pma, new pma_edges.N = %u \n", pma_edges.N);
}

void BLOCK::half_list() {
  // printf("pma_edges.N = %u, pma_edges.logN = %u, pma_edges.H = %u \n", pma_edges.N, pma_edges.logN, pma_edges.H);
  pma_edges.N /= 2;
  pma_edges.logN = (1 << bsr_word(bsr_word(pma_edges.N) + 1));
  pma_edges.H = bsr_word(pma_edges.N / pma_edges.logN);
  uint32_t *new_dests = (uint32_t *)aligned_alloc(64, pma_edges.N * sizeof(*(pma_edges.dests)));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(64, pma_edges.N * sizeof(*(pma_edges.vals)));
  // uint32_t *new_vals = (uint32_t *)malloc(pma_edges.N * sizeof(*(pma_edges.vals)));
  // uint32_t *new_dests = (uint32_t *)malloc(pma_edges.N * sizeof(*(pma_edges.dests)));
  int j = 0;
  // printf("pma_edges.N = %u, pma_edges.logN = %u, pma_edges.H = %u \n", pma_edges.N, pma_edges.logN, pma_edges.H);
  for (int i = 0; i < pma_edges.N * 2; i++) {
    if (pma_edges.dests[i] != NULL_VAL) {
      new_vals[j] = pma_edges.vals[i];
      new_dests[j] = pma_edges.dests[i];
      j++;
      // printf("%u, %u\n", i, j);
    }
  }
  for (uint_t i = j; i < pma_edges.N; i++) {
		new_vals[i] = NULL_VAL; 
    new_dests[i] = NULL_VAL;
	}
  free(pma_edges.vals);
  free(pma_edges.dests);
  pma_edges.vals = new_vals;
  pma_edges.dests = new_dests;
  // printf("redistribute edges\n");
  redistribute(0, pma_edges.N);
  // printf("halfing the pma, new pma_edges.N = %u \n", pma_edges.N);
}

// index is the beginning of the sequence that you want to slide right.
// notice that slide right does not not null the current spot.
// this is ok because we will be putting something in the current index
// after sliding everything to the right.
/*
int BLOCK::slide_right(int index) {
  int rval = 0;
  edge_t el = pma_edges.items[index];
  pma_edges.items[index].dest = NULL_VAL;
  pma_edges.items[index].value = NULL_VAL;
  index++;
  while (index < pma_edges.N && !is_null(pma_edges.items[index])) {
    edge_t temp = pma_edges.items[index];
    pma_edges.items[index] = el;
    if (!is_null(el) && is_sentinel(el)) {
      // fixing pointer of node that goes to this sentinel
      uint32_t node_index = el.value;
      if (node_index == UINT32_MAX) {
        node_index = 0;
      }
      fix_sentinel(node_index, index);
    }
    el = temp;
    index++;
  }
  if (!is_null(el) && is_sentinel(el)) {
    // fixing pointer of node that goes to this sentinel
    uint32_t node_index = el.value;
    if (node_index == UINT32_MAX) {
      node_index = 0;
    }
    fix_sentinel(node_index, index);
  }
  // There might be an issue with this going of the end sometimes
  if (index == pma_edges.N) {
    index--;
    slide_left(index);
    rval = -1;
    // // // printf("slide off the end on the right, should be rare\n");
  }
  pma_edges.items[index] = el;
  return rval;
}

// only called in slide right if it was going to go off the edge
// since it can't be full this doesn't need to worry about going off the other
// end
void BLOCK::slide_left(int index) {
  edge_t el = pma_edges.items[index];
  pma_edges.items[index].dest = NULL_VAL;
  pma_edges.items[index].value = NULL_VAL;

  index--;
  while (index >= 0 && !is_null(pma_edges.items[index])) {
    edge_t temp = pma_edges.items[index];
    pma_edges.items[index] = el;
    if (!is_null(el) && is_sentinel(el)) {
      // fixing pointer of node that goes to this sentinel
      uint32_t node_index = el.value;
      if (node_index == UINT32_MAX) {
        node_index = 0;
      }

      fix_sentinel(node_index, index);
    }
    el = temp;
    index--;
  }

  if (index == -1) {
    double_list();

    slide_right(0);
    index = 0;
  }
  if (!is_null(el) && is_sentinel(el)) {
    // fixing pointer of node that goes to this sentinel
    uint32_t node_index = el.value;
    if (node_index == UINT32_MAX) {
      node_index = 0;
    }
    fix_sentinel(node_index, index);
  }

  pma_edges.items[index] = el;
}
*/

void inline BLOCK::slide_right(uint_t index) {
  uint32_t el_dest = pma_edges.dests[index];
  uint32_t el_value = pma_edges.vals[index];
  pma_edges.dests[index] = NULL_VAL;
  pma_edges.vals[index] = NULL_VAL;
  index++;
  while (index < pma_edges.N && (pma_edges.dests[index] != NULL_VAL)) {
    uint32_t temp_dest = pma_edges.dests[index];
    uint32_t temp_value = pma_edges.vals[index];
    pma_edges.dests[index] = el_dest;
    pma_edges.vals[index] = el_value;
    if (el_dest == SENT_VAL) {
      // fixing pointer of node that goes to this sentinel
      uint32_t node_index = el_value;
      fix_sentinel(node_index, index);
    }
    el_dest = temp_dest;
    el_value = temp_value;
    index++;
  }
  if (el_dest == SENT_VAL) {
    // fixing pointer of node that goes to this sentinel
    uint32_t node_index = el_value;
    fix_sentinel(node_index, index);
  }

 // assert(index != edges.N);
  pma_edges.dests[index] = el_dest;
  pma_edges.vals[index] = el_value;
}


// index is the beginning of the sequence that you want to slide left.
// the element we start at will be deleted
// we wil always hold locks to the end of the leaf so we don't need to lock here
void inline BLOCK::slide_left(uint_t index) {
  while (index+1 < pma_edges.N) {
    uint32_t temp_dest = pma_edges.dests[index+1];
    uint32_t temp_value = pma_edges.vals[index+1];
    pma_edges.dests[index] = temp_dest;
    pma_edges.vals[index] = temp_value;
    if (temp_dest == SENT_VAL) {
      // fixing pointer of node that goes to this sentinel
      uint32_t node_index = temp_value;
      fix_sentinel(node_index, index);
    }
    if (pma_edges.dests[index] == NULL_VAL) {
      break;
    }
    index++;
  }
 // assert(index != edges.N);
}

// Evenly redistribute elements in the ofm, given a range to look into
// index: starting position in ofm structure
// len: area to redistribute
void BLOCK::redistribute(uint_t index, int len) {
  // // // // printf("REDISTRIBUTE: \n");
  // print_array();
  // std::vector<edge_t> space(len); //
  uint32_t *space_dests = (uint32_t *)malloc(len * sizeof(*(pma_edges.dests)));
  uint32_t *space_vals = (uint32_t *)malloc(len * sizeof(*(pma_edges.vals)));
  int j = 0;

  // move all items in ofm in the range into
  // a temp array
  for (int i = index; i < index + len; i++) {
    space_dests[j] = pma_edges.dests[i];
    space_vals[j] = pma_edges.vals[i];
    // counting non-null edges
    j += (pma_edges.dests[i] != NULL_VAL);
    // setting section to null
    pma_edges.dests[i] = NULL_VAL;
    pma_edges.vals[i] = NULL_VAL;
  } 
  // printf("redistribute: index = %u, len = %d, j = %d\n", index, len, j);
  // evenly redistribute for a uniform density
  double index_d = index;
  double step = ((double)len) / j;
  for (int i = 0; i < j; i++) {
    int in = index_d;
    // // printf("redistribute: i = %d, in = %d, index_d = %f, step = %f\n", i, in, index_d, step);

    pma_edges.dests[in] = space_dests[i];
    pma_edges.vals[in] = space_vals[i];
    if (space_dests[i] == SENT_VAL) {
      // fixing pointer of node that goes to this sentinel
      uint32_t node_index = space_vals[i];
      //if (node_index == UINT32_MAX) {
        //node_index = 0;
      //}
      fix_sentinel(node_index, in);
    }
    index_d += step;
  }
  free(space_dests);
  free(space_vals);
}

/*
// fix pointer from node to moved sentinel
void BLOCK::fix_sentinel_build(uint32_t node_index, uint32_t node_index_last, uint_t in) {
  nodes[node_index].beginning = in;
  if (node_index > 0 && node_index_last != NULL_VAL) {
    nodes[node_index_last].end = in;
  }
  if (node_index == MAX_NODE_NUM - 1) {
    nodes[node_index].end = pma_edges.N - 1;
  }
}*/

void BLOCK::fix_sentinel(uint32_t node_index, uint_t in) {
  nodes[node_index].beginning = in;
  if (node_index > 0) {
    nodes[node_index - 1].end = in;
  }
  if (node_index == MAX_NODE_NUM - 1) {
    nodes[node_index].end = pma_edges.N - 1;
  }
}

uint32_t BLOCK::find_value(uint32_t src, uint32_t dest) {
  edge_t e;
  e.value = 0;
  e.dest = dest;
  uint32_t loc =
      binary_search(&pma_edges, &e, nodes[src].beginning + 1, nodes[src].end);
  if ((pma_edges.dests[loc] != NULL_VAL) && pma_edges.dests[loc] == dest) {
    return pma_edges.vals[loc];
  } else {
    return 0;
  }
}

// this function can handle the case when the edge is already in the pma
// it will update the value of the edge if it is already in the pma
// only return true
bool inline BLOCK::pma_insert(uint_t index, edge_t elem, uint32_t src) {
  int node_index = find_leaf(&pma_edges, index);
  int level = pma_edges.H;
  int len = pma_edges.logN;
  bool ret = false;
  // if the item is null, put the elem in it
  // is this the only case when the elem is a sentinel?
  if (pma_edges.dests[index] == NULL_VAL) {
    // // // // printf("pma_insert: inserting %u, %u at index %u\n", elem.value, elem.dest, index);
    pma_edges.dests[index] = elem.dest;
    pma_edges.vals[index] = elem.value;
    ret = true;
  } else {
    // else the item may be a sentinel or an edge
    // the 1st case, the item is a edge and is the same as the elem edge
    // this mean the elem edge already exists in the graph, update its value
    // the 2nd case, the item is a edge and is not the same as the elem edge
    // the 3rd case, the item is a edge and the elem edge is a sentinel
    // the 4th case, the item is a sentinel and the elem edge is a edge
    // the 5th case, the item is a sentinel and the elem edge is a sentinel
    // in these cases, we need to slide right
    if (pma_edges.dests[index] == elem.dest) {
      pma_edges.vals[index] = elem.value;
      ret = true;
      return ret;
    } else {
      slide_right(index); 
      pma_edges.dests[index] = elem.dest;
      pma_edges.vals[index] = elem.value;
      ret = true;
    }
  }
  // increment the degree of the node
  __sync_fetch_and_add(&nodes[src].degree, 1);

  // get density of the leaf you are in
  double density_b = (density_bound(&pma_edges, level)).y;
  double density = get_density(&pma_edges, node_index, len);
  // printf("pma_insert: density = %f, new density_b = %f, len = %d \n", density, density_b, len);
  // while density too high, go up the implicit tree
  // go up to the biggest node above the density bound
  bool redistribute_flag = false;
  // for the last node, we need to redistribute to let the last item in the pma to be NULL
  int last_node_index = ((pma_edges.N - 1) / pma_edges.logN) * pma_edges.logN;
  if (node_index == last_node_index) {
    redistribute_flag = true;
  }
  while (density >= density_b) {
    len *= 2;
    if (len <= pma_edges.N) {
      redistribute_flag = true;
      level--;
      node_index = find_node(node_index, len);
      density_b = (density_bound(&pma_edges, level)).y;
      density = get_density(&pma_edges, node_index, len);
      // printf("pma_insert: new density = %f, new density_b = %f, len = %d \n", density, density_b, len);
    } else {
      redistribute_flag = false;
      // if you reach the root, double the list
      // if the size of pma is smaller than MAX_PMA_SIZE, doulbe it
      // else, we need to move the max degree node to the hash table
      if (pma_edges.N < MAX_PMA_SIZE) {
        // printf("pma_insert: reached the root, len = %d, pma_edges.N = %u\n", len, pma_edges.N);
        // printf("index = %u, elem.dest = %u, elem.value = %u, src = %u \n", index, elem.dest, elem.value, src);
        double_list();
        return ret;
      } else { // TODO: to hash pma redistribute
        // move the max degree node to the hash table
        printf("move the max degree node to the hash table");
        uint32_t max_degree_node = 0;
        for (uint32_t i = 1; i < MAX_NODE_NUM; i++) {
          if (nodes[i].degree > nodes[max_degree_node].degree) {
            max_degree_node = i;
          }
        }
        // // // // printf("moving node %u to hash table\n", max_degree_node);
        hash_list_t hash_list;
        hash_list.bsize = 2 << bsr_word(nodes[max_degree_node].degree);
        hash_list.bdests = (uint32_t *)aligned_alloc(64, hash_list.bsize * sizeof(uint32_t));
        hash_list.bvals = (uint32_t *)aligned_alloc(64, hash_list.bsize * sizeof(uint32_t));
        hash_list.htab = (index_type *)aligned_alloc(64, 2 * hash_list.bsize * sizeof(index_type));
        
        uint start = nodes[max_degree_node].beginning + 1;
        uint ending = nodes[max_degree_node].end;
        int i = 0;
        for (uint_t j = start; j < ending; j++) {
          if (pma_edges.dests[j] != NULL_VAL) {
            hash_list.bdests[i] = pma_edges.dests[j];
            hash_list.bvals[i] = pma_edges.vals[j];
            i++;
          }
          pma_edges.dests[j] = NULL_VAL; // clear the pma edge
          pma_edges.vals[j] = NULL_VAL; // clear the pma edge
        }
        
        //uint_t sentinel_id = nodes[max_degree_node].beginning;
        //pma_edges.dests[sentinel_id];
        
        //nodes[max_degree_node - 1].end = nodes[max_degree_node + 1].beginning;
        //nodes[max_degree_node].beginning = NULL_VAL;
        //nodes[max_degree_node].end = NULL_VAL;
        nodes[max_degree_node].hash_id = hash_lists.size();
        hash_lists.push_back(std::move(hash_list)); // TODO
        rebuild_hash(max_degree_node);

        return ret;
      }
    }
  }
  if (redistribute_flag) {
    redistribute(node_index, len);
    // printf("pma redistributed at node_index = %u, len = %u\n", node_index, len);
  }
  // printf("pma_insert: new density = %f, new density_b = %f\n", density, density_b);
  //print_array(&pma_edges, node_index, len);
  //redistribute(node_index, len);
  //print_array(&pma_edges, node_index, len);s
  return ret;
}

// this function can not handle the case when the edge is not in the pma
// so we need to make sure that the edge is in the pma before calling this function
// only return true
bool inline BLOCK::pma_delete(uint_t index, edge_t elem, uint32_t src) {
  uint_t node_index = find_leaf(&pma_edges, index);
  int level = pma_edges.H;
  uint_t len = pma_edges.logN;

  // delte the element at index by slide left
  slide_left(index);
  __sync_fetch_and_add(&nodes[src].degree, -1);

  double density_b = (density_bound(&pma_edges, level)).x;
  double density = get_density(&pma_edges, node_index, len);
  // printf("pma_delete: density = %f, density_b = %f\n", density, density_b);
  // while density too low, go up the implicit tree
  // go up to the biggest node below the density bound
  bool redistribute_flag = false;
  while (density <= density_b) {
    len *= 2;
    if (len <= pma_edges.N) {
      redistribute_flag = true;
      level--;
      // orig_n = pma_edges.N;
      node_index = find_node(node_index, len);
      density_b = (density_bound(&pma_edges, level)).x;
      density = get_density(&pma_edges, node_index, len);
      // printf("pma_delete: new density = %f, new density_b = %f\n", density, density_b);
    } else {
      // printf("pma_delete: reached the root, len = %u, pma_edges.N = %u\n", len, pma_edges.N);
      redistribute_flag = false;
      half_list();
      return true;
    }
  }
  if (redistribute_flag) {
    // printf("pma_delete: redistributing at node_index = %u, len = %u\n", node_index, len);
    redistribute(node_index, len);
  }
  //redistribute(node_index, len);
  return true;
}

void BLOCK::rebuild_hash(uint32_t src) {
  
    uint32_t hash_id = nodes[src].hash_id;
    index_type* const hash_table = hash_lists[hash_id].htab;

    // Clear the hash table.
    for (size_t j = 0; j < 2 * hash_lists[hash_id].bsize; ++j) {
        hash_table[j] = illegalIndex();
    }

    // Re-insert all vertices.
    for (size_t i = 0; i < nodes[src].degree; ++i) {
        auto v = hash_lists[hash_id].bdests[i];

        // Find a free slot within the hash table.
        unsigned int const h = hash_node(v);
        size_t j = 0; // Hash table index.
        for (index_type p = 0; true; ++p) {
           // assert(p < hash_lists[hash_id].bsize);
            j = index_hash_table(h, p, hash_lists[hash_id].bsize);

            if (hash_table[j] == illegalIndex() || hash_table[j] == tombstoneIndex()) {
              break;
            }

            // There cannot be any duplicates.
            // 
        }

        // Insert into the hash table.
        hash_table[j] = i;
    }
}

void BLOCK::double_hash(uint32_t src) {
    // Double the size of the hash table.
    hash_list_t& hash_list = hash_lists[nodes[src].hash_id];
    size_t bsize = hash_list.bsize;
    hash_list.bsize *= 2;

    // Allocate new dests, vals, and hash table.
    uint32_t* new_bdests = (uint32_t*)aligned_alloc(64, hash_list.bsize * sizeof(uint32_t));
    uint32_t* new_bvals = (uint32_t*)aligned_alloc(64, hash_list.bsize * sizeof(uint32_t));
    index_type* new_htab = (index_type*)aligned_alloc(64, 2 * hash_list.bsize * sizeof(index_type));

    // copy old entries to new entries
    for (size_t i = 0; i < nodes[src].degree; ++i) {
        new_bdests[i] = hash_list.bdests[i];
        new_bvals[i] = hash_list.bvals[i];
    }

    // Free old entries and hash table.
    free(hash_list.bdests);
    free(hash_list.bvals);
    free(hash_list.htab);

    // Assign the new entries and hash table.
    hash_list.bdests = new_bdests;
    hash_list.bvals = new_bvals;
    hash_list.htab = new_htab;
}

// this function can handle the edge that is already in the hash table
// it will update the value of the edge if it is already in the pma
// only return true
bool inline BLOCK::hash_insert(uint32_t src, edge_t elem) {
    bool ret = false;
    hash_list_t& hash_list = hash_lists[nodes[src].hash_id];
   // assert(nodes[src].degree < hash_list.bsize);
    auto h = hash_node(elem.dest);
    index_type j;
    index_type ts = illegalIndex();
    for (index_type i = 0; true; ++i) {
        if (i == hash_list.bsize) {
           // assert(ts != illegalIndex());
            break;
        }
        j = index_hash_table(h, i, hash_list.bsize);

        if (hash_list.htab[j] == illegalIndex()) {
            break;
        }
        if (hash_list.htab[j] == tombstoneIndex()) {
            ts = j;
            continue;
        }
        uint32_t edge_dest = hash_list.bdests[hash_list.htab[j]];
        uint32_t edge_value = hash_list.bvals[hash_list.htab[j]];
        if (edge_dest == elem.dest) {
            // If we found the edge, update its value.
            edge_value = elem.value;
            ret = true;
            return ret;
        }
    }
        // If we did hit a tombstone, insert at the tombstone.
    if (ts != illegalIndex()) {
        j = ts;
    }

    // Insert into the edge list.
    auto i = nodes[src].degree;
    __sync_fetch_and_add(&nodes[src].degree, 1);
    hash_list.htab[j] = i;
    hash_list.bdests[i] = elem.dest;
    hash_list.bvals[i] = elem.value;
    ret = true;

    // if the hash table is full, double and rebuild it
    if (nodes[src].degree == hash_list.bsize) {
        double_hash(src);
        rebuild_hash(src);
    }
    return ret;
}

// this function can handle the edge that is not in the hash table
// if the edge is in the hash table, it will delete it and return true
// if the edge is not in the hash table, it will return false
bool inline BLOCK::hash_delete(uint32_t src, edge_t elem) {
    bool ret = false;
    hash_list_t& hash_list = hash_lists[nodes[src].hash_id];
    unsigned int const hv = hash_node(elem.dest);
    size_t jv = 0; // Hash table index.
    for (index_type i = 0; true; ++i) {
        if (i == hash_list.bsize) {
            return ret;
        }

        jv = index_hash_table(hv, i, hash_list.bsize);

        if (hash_list.htab[jv] == illegalIndex()) {
            return ret;
        }

        if (hash_list.htab[jv] == tombstoneIndex()) {
            continue;
        }
        
        uint32_t edge_dest = hash_list.bdests[hash_list.htab[jv]];
        if (edge_dest == elem.dest) {
            break;
        }
    }

    uint32_t last_edge_dest = hash_list.bdests[nodes[src].degree - 1];
    uint32_t last_edge_value = hash_list.bvals[nodes[src].degree - 1];
    if (hash_list.bdests[hash_list.htab[jv]] != last_edge_dest) {
        unsigned int const hw = hash_node(last_edge_dest);
        size_t jw = 0; // Hash table index.
        for (index_type i = 0; true; ++i) {
            // Otherwise, w is not in the HT.
           // assert(i != hash_list.bsize);

            jw = index_hash_table(hw, i, hash_list.bsize);

            // Otherwise, w is not in the HT.
            //// assert(hash_list.hash_table[jw] != illegalIndex());

            if (hash_list.htab[jw] == tombstoneIndex()) {
                continue;
            }
            
            uint32_t edge_dest = hash_list.bdests[hash_list.htab[jw]];
            if (edge_dest == last_edge_dest) {
                break;
            }
        }

       // Move the last edge to the deleted position.
        hash_list.bdests[hash_list.htab[jv]] = last_edge_dest;
        hash_list.bvals[hash_list.htab[jv]] = last_edge_value;
        hash_list.htab[jw] = hash_list.htab[jv];
    }

    hash_list.htab[jv] = tombstoneIndex();
     __sync_fetch_and_add(&nodes[src].degree,-1);
    ret = true;
    return ret;
}

void BLOCK::add_edge(uint32_t src, uint32_t dest, uint32_t value) {
  edge_t e;
  e.dest = dest;
  e.value = value;
  if (nodes[src].hash_id != NULL_VAL) {
    // if the vertex is in the hash table, add the edge to the hash table
    // printf("adding edge %u -> %u to hash table\n", src, dest);
    if (hash_insert(src, e)) {
      return; // edge added to hash table
    }
  } else {
    block_lock.lock();
    node_t node = nodes[src];
    uint32_t loc_to_add =
        binary_search(&pma_edges, &e, node.beginning + 1, node.end);
    if (pma_insert(loc_to_add, e, src)) {
      block_lock.unlock();
      return; // edge added to pma
    }
  }
}

// remove edge from the block
void inline BLOCK::remove_edge(uint32_t src, uint32_t dest) {
  edge_t e;
  e.dest = dest;
  e.value = NULL_VAL;
  node_t node = nodes[src];
  if (node.hash_id != NULL_VAL) {
    // printf("removing edge %u -> %u from hash table\n", src, dest);
    // if the vertex is in the hash table, add the edge to the hash table
    if (hash_delete(src, e)) { // return true or false
      return; // edge added to hash table
    }
  } else {
    block_lock.lock();
    // printf("node.beginning = %u, node.end = %u\n", node.beginning, node.end);
    uint32_t loc_to_remove =
        binary_search(&pma_edges, &e, node.beginning + 1, node.end);
    // printf("loc_to_remove = %u \n", loc_to_remove);
    // make sure that the edge is in the pma
    if (pma_edges.dests[loc_to_remove] == dest) {
      // printf("removing edge %u -> %u from pma\n", src, dest);
      if (pma_delete(loc_to_remove, e, src)) {
        block_lock.unlock();
        return; // edge added to hash table
      }
    } else {
      block_lock.unlock();
      return; // edge not found in pma
    } 
  }
}

uint_t BLOCK::get_size() {
  // the size of block includes the size of the block, 
  // edges in the pma and hash lists, the hash table, and the hash list
  uint_t size = sizeof(BLOCK);
  size += pma_edges.N * sizeof(edge_t);
  size += hash_lists.size() * sizeof(hash_list_t);
  for (const auto &hash_list : hash_lists) {
    size += hash_list.bsize * sizeof(edge_t);
    size += 2 * hash_list.bsize * sizeof(index_type);
  }
  return size;
}

// get all the edges in the block, I think it is similar to print graph
//vector<tuple<uint32_t, uint32_t, uint32_t>> inline BLOCK::get_edges() {
  /*
  uint_t n = MAX_NODE_NUM;
  vector<tuple<uint32_t, uint32_t, uint32_t>> output;

  for (int i = 0; i < n; i++) {
    // TODO: if the vertex is in the hash table, get the edges from the hash table
    /////////////////////////////////////
    
    uint32_t start = nodes[i].beginning;
    uint32_t end = nodes[i].end;
    for (int j = start + 1; j < end; j++) {
      if (!is_null(edges.items[j])) {
        output.push_back(
            make_tuple(i, edges.items[j].dest, edges.items[j].value));
      }
    }
  }
  return output;*/
//}

}