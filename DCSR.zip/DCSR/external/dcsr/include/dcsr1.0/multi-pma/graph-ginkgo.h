// Discription: dcsr graph header file, which defines the graph 
// API and the overrall structure.

#pragma once

#include "partition-dcsr.h"
#include "types.h"
#include "gbbs/bridge.h"

#include <variant>
#include <cassert>
#include <functional>
#include <memory>
#include <mutex>
#include <omp.h>
#include <vector>
#include <iterator>
#include <stdlib.h>

#include <cmath>
#include <chrono>  

namespace dcsr {
// define the max number of vertices in the block
size_t BLOCK_SIZE_log2 = 6; 

class dcsr {
  public:
    dcsr(uint32_t num_v); // create a graph with the given size (#num nodes)

    // dcsr(std::string prefix); // read graph from disk

    // ~dcsr();

    // void dcsr(std::string prefix); // write graph to disk

    bool add_edge(const uint32_t s, const uint32_t d, E ed);

    void add_edge_batch(pair_uint *es, uint_t edge_count);

    bool remove_edge(const uint32_t s, const uint32_t d);

    void remove_edge_batch(pair_uint *es, uint_t edge_count);

    // void build_from_batch(uint32_t *srcs, uint32_t *dests, uint32_t vertex_count, uint32_t edge_count);
    
    // check for the existence of the edge
    // uint32_t is_edge(const uint32_t s, const uint32_t d);
    // get out neighbors of vertex s

    // BlockIndex<E>::ConstNeighborView neighbors(const uint32_t v) const;
    // get out degree of vertex v
    uint32_t degree(const uint32_t v) const;
    
    //uint64_t get_size(void);

    // uint32_t get_max_degree(void) const;
    template <class F>
    void map_neighbors(uint32_t v, F &&f) const;

    template <class F>
    void map_neighbors_early_exit(uint32_t v, F &&f) const;

    uint_t get_num_edges(void) const;

    uint32_t get_num_vertices(void) const;
  
  private:
    std::vector<Block<E>> blocks;
    uint32_t num_vertices{0};
    uint_t num_edges{0};
    unsigned int BLOCK_NUM{0}; // number of blocks
};

inline dcsr::dcsr(uint32_t num_v) : num_vertices(num_v) {
    // get the number of blocks
    BLOCK_NUM = (num_v + (1 << BLOCK_SIZE_log2) - 1) >> BLOCK_SIZE_log2; // 向上取整
    blocks.reserve(BLOCK_NUM);
    cout << "BLOCK_NUM: " << BLOCK_NUM << endl;
    cout << "BLOCK_SIZE: " << (1 << BLOCK_SIZE_log2) << endl;
    // cout << "num_edges: " << num_edges << endl;
    for (unsigned int i = 0; i < BLOCK_NUM; ++i) {
        // initialize the block and push it to the vector
        BLOCK block{(1 << BLOCK_SIZE_log2)};
        blocks.push_back(std::move(block));
    }
    cout << "sizeof(Block<E>)" << sizeof(Block<E>) << endl;
    cout << "sizeof(nodes)" << sizeof(blocks[0].nodes[0])*(1 << BLOCK_SIZE_log2)<< endl;
    cout << "here1" << endl;
}

//template <typename E>
//inline dcsr<E>::~dcsr() {}

inline bool dcsr::add_edge(const uint32_t src, const uint32_t dest, uint32_t ed) {
    unsigned int block_index = src >> BLOCK_SIZE_log2; // 取整得到 block_index
    unsigned int v_id = src & ((1 << BLOCK_SIZE_log2) - 1); // 余数
    blocks[block_index].add_edge(v_id, dest, ed);
}

inline bool dcsr::remove_edge(const uint32_t src, const uint32_t dest) {
   unsigned int block_index = src >> BLOCK_SIZE_log2; // 取整得到 block_index
   unsigned int v_id = src & ((1 << BLOCK_SIZE_log2) - 1); // 余数
   blocks[block_index].remove_edge(v_id, dest);
}

inline void dcsr::add_edge_batch(pair_uint *es, uint_t edge_count) {
    // 假设 BLOCK_SIZE 和 blocks 已经定义
    std::vector<std::vector<edge_t>> insert_edges(BLOCK_NUM); // 每个 block 的边
    parlay::parallel_for(0, edge_count, [&](uint_t i) {
       unsigned int block_index = es[i].x >> BLOCK_SIZE_log2; // 取整得到 block_index
       insert_edges[block_index].push_back(es[i]);   // 将边加入对应 block
    });

   // 并行更新不同 block 的边
    parlay::parallel_for(0, BLOCK_NUM, [&](uint32_t j) {
        BLOCK& block = blocks[j]; // 获取对应 block
        // 串行更新同一个 block 的边
        for (const auto& edge : insert_edges[j]) {
            uint32_t src = edge.x;
            uint32_t dest = edge.y;
            uint32_t ed = NULL_VAL; // 假设边的权重为 NULL_VAL 或者其他默认值
            // 插入边到 block 中
            block.add_edge(src, dest, ed);
        }
    });
}

inline void dcsr::remove_edge_batch(pair_uint *es, uint_t edge_count) {
   // 假设 BLOCK_SIZE 和 blocks 已经定义
    std::vector<std::vector<edge_t>> delete_edges(BLOCK_NUM); // 每个 block 的边
    parlay::parallel_for(0, edge_count, [&](uint_t i) {
       unsigned int block_index = es[i].x >> BLOCK_SIZE_log2; // 取整得到 block_index
       delete_edges[block_index].push_back(es[i]);   // 将边加入对应 block
    });

   // 并行更新不同 block 的边
    parlay::parallel_for(0, BLOCK_NUM, [&](uint32_t j) {
        BLOCK& block = blocks[j]; // 获取对应 block
        // 串行更新同一个 block 的边
        for (const auto& edge : delete_edges[j]) {
            uint32_t src = edge.x;
            uint32_t dest = edge.y;
            // 插入边到 block 中
            block.remove_edge(src, dest);
        }
    });
}

inline uint32_t dcsr::degree(const uint32_t v) const {
    // get the block index
    unsigned int block_index = v >> BLOCK_SIZE_log2; // 取整得到 block_index
    unsigned int v_id = v & ((1 << BLOCK_SIZE_log2) - 1); // 余数
    // get the degree of the vertex
    auto degree = blocks[block_index].nodes[v_id].degree;
    // auto degree = blocks[0].nodes[v].degree;
    return degree;
}

inline uint_t dcsr::get_num_edges(void) const {
	return num_edges;
}

inline uint32_t dcsr::get_num_vertices(void) const {
    return num_vertices;
}

template <class F>
inline void dcsr::map_neighbors(uint32_t v, F &&f) const{
    // get the block index
    unsigned int block_index = v >> BLOCK_SIZE_log2; // 取整得到 block_index
    unsigned int v_id = v & ((1 << BLOCK_SIZE_log2) - 1); // 余数
    auto& block = blocks[block_index];
    auto& hash_id = block.nodes[v_id].hash_id;
    auto& degree = block.nodes[v_id].degree;
    if (hash_id != NULL_VAL) {
        edge_t* neighbors = block.hash_lists[hash_id].entries;
        for (uint32_t i = 0; i < degree; i++) {
            uint32_t vertex = neighbors[i].dest;
            uint32_t weight = neighbors[i].value;
            f(v, vertex, weight);
        }
    } else {
        uint64_t start = block.nodes[v_id].beginning + 1;
        uint64_t end = block.nodes[v_id].end;
        for (uint_t j = start; j < end; j++) {
            edge_t edge = block.pma_edges.items[j];
            uint32_t vertex = edge.dest;
            uint32_t weight = edge.value;
            if (vertex != NULL_VAL) {
                f(v, vertex, weight);
            }
        }    
    }
}

template <class F>
inline void dcsr::map_neighbors_early_exit(uint32_t v, F &&f) const {
    // get the block index
    unsigned int block_index = v >> BLOCK_SIZE_log2; // 取整得到 block_index
    unsigned int v_id = v & ((1 << BLOCK_SIZE_log2) - 1); // 余数
    auto& block = blocks[block_index];
    auto& hash_id = block.nodes[v_id].hash_id;
    auto& degree = block.nodes[v_id].degree;
    if (hash_id != NULL_VAL) {
        edge_t* neighbors = block.hash_lists[hash_id].entries;
        for (uint32_t i = 0; i < degree; i++) {
            uint32_t vertex = neighbors[i].dest;
            uint32_t weight = neighbors[i].value;
            if (f(v, vertex, weight)) {
                return;
            }
        }
    } else {
        uint64_t start = block.nodes[v_id].beginning + 1;
        uint64_t end = block.nodes[v_id].end;
        for (uint32_t j = start; j < end; j++) {
            edge_t edge = block.pma_edges.items[j];
            uint32_t vertex = edge.dest;
            uint32_t weight = edge.value;
            if (vertex != NULL_VAL) {
                if (f(v, vertex, weight)) {
                    return;
                }
            }
        }    
    } 
}

} // namespace dcsr