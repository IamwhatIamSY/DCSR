#include <atomic>
#include <unistd.h>
#include <stdio.h>
#include "util.h"

#pragma once
#define num_tries 3
#define wait_time 1

class LOCK {
public:
  uint32_t x;
  void init();
  bool lock();
  bool try_lock();
  void unlock();
};

//IMPORTANT!!!!!!!!! locks need to be initialized as all zeros
inline void LOCK::init() {
  x = 0;
}

inline bool cas(uint32_t *old, uint32_t old_val, uint32_t new_val) {
  return __sync_bool_compare_and_swap(old, old_val, new_val);
}

// exclusive lock
inline bool LOCK::lock() {
  bool success = false;
  while(!success) {
    success = cas(&x, 0, 1);
    if (success) {
        break;
    }
  }
  return true;
}

inline bool LOCK::try_lock() {
  int tries = 0;
  bool success = false;
  while (tries < num_tries) {
    if (x == 0) {
      success = cas(&x, 0, 1);
      if (success) { break; }
    }
    tries++;
  }
  return success;
}


inline void LOCK::unlock() {
  cas(&x, 1, 0);
}
