// Discription: dcsr graph header file, which defines the graph 
// API and the overrall structure.

#pragma once

#include "partition.h"
#include "types.h"
#include "gbbs/bridge.h"

#include <variant>
#include <cassert>
#include <functional>
#include <memory>
#include <mutex>
#include <omp.h>
#include <vector>
#include <iterator>
#include <stdlib.h>

#include <cmath>
#include <chrono>  

namespace dcsr {
// define the max number of vertices in the block
size_t BLOCK_SIZE_log2; 

template <typename E> class dcsr {
  public:
    dcsr(uint32_t num_v); // create a graph with the given size (#num nodes)

    // dcsr(std::string prefix); // read graph from disk

    // ~dcsr();

    // void dcsr(std::string prefix); // write graph to disk

    bool add_edge(const Vertex s, const Vertex d, E ed);

    void add_edge_batch(pair_uint *es, uint64_t edge_count);

    bool remove_edge(const Vertex s, const Vertex d);

    void remove_edge_batch(pair_uint *es, uint64_t edge_count);

    // void build_from_batch(Vertex *srcs, Vertex *dests, uint32_t vertex_count, uint32_t edge_count);
    
    // check for the existence of the edge
    // uint32_t is_edge(const Vertex s, const Vertex d);
    // get out neighbors of vertex s

    // BlockIndex<E>::ConstNeighborView neighbors(const Vertex v) const;
    // get out degree of vertex v
    Degree degree(const Vertex v) const;
    
    //uint64_t get_size(void);

    // uint32_t get_max_degree(void) const;
    template <class F>
    void map_neighbors(size_t i, F &&f) const;

    template <class F>
    void map_neighbors_early_exit(size_t i, F &&f) const;

    size_t get_num_edges(void) const;

    Vertex get_num_vertices(void) const;
  
  private:
    std::vector<Block<E>> partitions;
    Vertex num_vertices{0};
    size_t num_edges{0};
    //unsigned int BLOCK_SIZE_log2{10};
    size_t num_b{1};
    // unsigned int num_b{1};
    // uint32_t max_degree{0};
};

template <typename E>
inline dcsr<E>::dcsr(uint32_t num_v) : num_vertices(num_v) {
    // get the number of blocks
    num_b = 1;
    partitions.reserve(num_b);
    cout << "num_v: " <<num_v << endl;
    // cout << "MAX_BLOCK_NUM: " << MAX_BLOCK_NUM << endl;
    cout << "num_b: " << num_b << endl;
    // cout << "num_edges: " << num_edges << endl;
    for (unsigned int i = 0; i < num_b; ++i) {
        // initialize the block and push it to the vector
        Block<E> block{num_v};
        partitions.push_back(std::move(block));
    }
}

//template <typename E>
//inline dcsr<E>::~dcsr() {}

template <typename E>
inline void dcsr<E>::add_edge_batch(pair_uint *es, uint64_t edge_count) {
    auto& block = partitions[0];
    block.node_lock.lock_shared(0);
    uint64_t task_id = __sync_fetch_and_add(&block.next_task_id, 2*edge_count);
    parlay::parallel_for (0, edge_count, [&](uint64_t i) {
    // temp_pfor (uint32_t i = 0; i < edge_count; i++) {
      uint32_t src = es[i].x;
      uint32_t dest = es[i].y;
      //if (block.nodes[src].in_htab()) {
        //auto result = block.nodes[src].insert(dest,{});
      //} else {
        block.add_edge_update_fast(src,dest,1,task_id+2*i);
      //}
    });
#if ENABLE_PMA_LOCK
    block.node_lock.unlock_shared(0);
#endif
}

template <typename E>
inline bool dcsr<E>::add_edge(const Vertex s, const Vertex d, E ed) {
    unsigned int block_index = 0;
    unsigned int s_id = s;
    // add the edge to the block
    //cout << "s: " << s << " d: " << d << endl;
    //cout << "block_index: " << block_index << " s_id: " << s_id << endl;
    auto& block = partitions[block_index];
    // if the edges of vertex are stored in the hash table, insert the edge into the hash table
    if (block.nodes[s_id].in_htab()) {
        auto result = block.nodes[s_id].insert(d, ed);
        if (std::get<1>(result)) {
            return true;
        }
        return false;
    } else {
        if (block.add_edge_update(s_id, d, 1)) {
            // cout << "pblock add edge: " << s_id << " " << d << endl;
            return true;
        }
        // cout << "pblock add edge failed: " << s_id << " " << d << endl;
        return false;
    }
    return true;
    /*auto& block = partitions[0];
    if (block.nodes[s].in_htab()) {
        auto result = block.nodes[s].insert(d, ed);
        if (std::get<1>(result)) {
            return true;
        }
        return false;
    } else {
        if (block.add_edge_update(s, d, 1)) {
            // cout << "pblock add edge: " << s_id << " " << d << endl;
            return true;
        }
        // cout << "pblock add edge failed: " << s_id << " " << d << endl;
        return false;
    }*/
}

template <typename E>
inline void dcsr<E>::remove_edge_batch(pair_uint *es, uint64_t edge_count) {
    auto& block = partitions[0];
    block.node_lock.lock_shared(0);
    uint64_t task_id = __sync_fetch_and_add(&block.next_task_id, 2*edge_count);
    parlay::parallel_for (0, edge_count, [&](uint64_t i) {
    // temp_pfor (uint32_t i = 0; i < edge_count; i++) {
      uint32_t src = es[i].x;
      uint32_t dest = es[i].y;
      //if (block.nodes[src].in_htab()) {
        //auto result = block.nodes[src].remove(dest);
      //} else {
        block.remove_edge_fast(src,dest,task_id+2*i);
      //}
    });
#if ENABLE_PMA_LOCK
    block.node_lock.unlock_shared(0);
#endif
}

template <typename E>
inline bool dcsr<E>::remove_edge(const Vertex s, const Vertex d) {
   auto& block = partitions[0];
    if (block.nodes[s].in_htab()) {
        if (block.nodes[s].remove(d)) {
            return true;
        }
        return false;
    } else {
        if (block.remove_edge(s, d)) {
            // cout << "pblock remove edge: " << s_id << " " << d << endl;
            return true;
        }
        // cout << "pblock remove edge failed: " << s_id << " " << d << endl;
        return false;
    }
}

template <typename E>
inline Degree dcsr<E>::degree(const Vertex v) const {
    // get the block index
    //unsigned int block_index = v >> BLOCK_SIZE_log2; // 取整得到 block_index
    //unsigned int v_id = v & ((1 << BLOCK_SIZE_log2) - 1); // 余数
    // get the degree of the vertex
    auto degree = partitions[0].nodes[v].degree;
    // auto degree = partitions[0].nodes[v].degree;
    return degree;
}


template <typename E>
inline size_t dcsr<E>::get_num_edges(void) const {
	return num_edges;
}

template <typename E>
inline Vertex dcsr<E>::get_num_vertices(void) const {
    return num_vertices;
}

template <typename E>
template <class F>
inline void dcsr<E>::map_neighbors(size_t i, F &&f) const{
    auto& block = partitions[0];
    if (block.nodes[i].in_htab()) {
        auto start = block.nodes[i].begin();
        auto end = block.nodes[i].valid_end();
        for (auto neighbor = start; neighbor != end; ++neighbor) {
            size_t other_vertex = (*neighbor).vertex();
            E weight = (*neighbor).data();
            f(i, other_vertex, weight);
        }
    } else {
        uint64_t start = block.nodes[i].beginning + 1;
        uint64_t end = block.nodes[i].end;
        E empty_weight = E();
        for (uint64_t j = start; j < end; j++) {
            if (block.edges.dests[j] != NULL_VAL) {
                f(i, block.edges.dests[j], empty_weight);
            }
        }    
    }
}

template <typename E>
template <class F>
inline void dcsr<E>::map_neighbors_early_exit(size_t i, F &&f) const {
    auto& block = partitions[0];
    if (block.nodes[i].in_htab()) {
        auto start = block.nodes[i].begin();
        auto end = block.nodes[i].valid_end();
        for (auto neighbor = start; neighbor != end; ++neighbor) {
            size_t other_vertex = (*neighbor).vertex();
            E weight = (*neighbor).data();
            if (f(i, other_vertex, weight)) {
                return;
            }
        }
    } else {
        // static_assert(sizeof(BlockState<gbbs::empty>) > 0, "Check layout");
        uint64_t start = block.nodes[i].beginning + 1;
        uint64_t end = block.nodes[i].end;
        E empty_weight = E();
        for (uint64_t j = start; j < end; j++) {
            if (block.edges.dests[j] != NULL_VAL) {
                if (f(i, block.edges.dests[j], empty_weight)) {
                    return;
                }
            }
        }
    }
}
} // namespace dcsr