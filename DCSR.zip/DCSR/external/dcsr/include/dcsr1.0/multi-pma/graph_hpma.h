// Discription: hpma graph header file, which defines the graph 
// API and the overrall structure.

#pragma once

#include "hpma.hpp"
#include "types.h"
#include "gbbs/bridge.h"

#include <variant>
#include <cassert>
#include <functional>
#include <memory>
#include <mutex>
#include <omp.h>
#include <vector>
#include <iterator>
#include <stdlib.h>

#include <cmath>
#include <chrono>  

namespace hpma {

template <typename E> class hpma {
  public:
    hpma(uint32_t num_v); // create a graph with the given size (#num nodes)

    // hpma(std::string prefix); // read graph from disk

    // ~hpma();

    // void hpma(std::string prefix); // write graph to disk

    bool add_edge(const uint_t s, const uint_t d, E ed);

    void add_edge_batch(pair_uint *es, uint64_t edge_count);

    bool remove_edge(const uint_t s, const uint_t d);

    void remove_edge_batch(pair_uint *es, uint64_t edge_count);

    // void build_from_batch(uint_t *srcs, uint_t *dests, uint32_t vertex_count, uint32_t edge_count);
    
    // check for the existence of the edge
    // uint32_t is_edge(const uint_t s, const uint_t d);
    // get out neighbors of vertex s

    // BlockIndex<E>::ConstNeighborView neighbors(const uint_t v) const;
    // get out degree of vertex v
    uint_t degree(const uint_t v) const;
    
    //uint64_t get_size(void);

    // uint32_t get_max_degree(void) const;
    template <class F>
    void map_neighbors(size_t i, F &&f) const;

    template <class F>
    void map_neighbors_early_exit(size_t i, F &&f) const;

    size_t get_num_edges(void) const;

    uint_t get_num_vertices(void) const;
  
  private:
    PMA hpma;
    uint_t num_vertices{0};
    size_t num_edges{0};
};

template <typename E>
inline hpma<E>::hpma(uint32_t num_v) : num_vertices(num_v) {
    // get the number of blocks
    PMA(num_v);
}

//template <typename E>
//inline hpma<E>::~hpma() {}

template <typename E>
inline void hpma<E>::add_edge_batch(pair_uint *es, uint64_t edge_count) {
    cout << "add_edge_batch: " << edge_count << endl;
  

}

template <typename E>
inline bool hpma<E>::add_edge(const uint_t s, const uint_t d, E ed) {
    
}

template <typename E>
inline void hpma<E>::remove_edge_batch(pair_uint *es, uint64_t edge_count) {
    
}

template <typename E>
inline bool hpma<E>::remove_edge(const uint_t s, const uint_t d) {
   
}

template <typename E>
inline uint_t hpma<E>::degree(const uint_t v) const {
    auto degree = hpma.nodes[v].degree;
    return degree;
}


template <typename E>
inline size_t hpma<E>::get_num_edges(void) const {
	return num_edges;
}

template <typename E>
inline uint_t hpma<E>::get_num_vertices(void) const {
    return num_vertices;
}

template <typename E>
template <class F>
inline void hpma<E>::map_neighbors(size_t i, F &&f) const{
    
    uint64_t start = block.nodes[v_id].beginning + 1;
    uint64_t end = block.nodes[v_id].end;
    E empty_weight = E();
    for (uint64_t j = start; j < end; j++) {
        if (block.edges.dests[j] != NULL_VAL) {
            f(i, block.edges.dests[j], empty_weight);
        }
    }    
}

template <typename E>
template <class F>
inline void hpma<E>::map_neighbors_early_exit(size_t i, F &&f) const {
    uint64_t start = block.nodes[v_id].beginning + 1;
    uint64_t end = block.nodes[v_id].end;
    E empty_weight = E();
    for (uint64_t j = start; j < end; j++) {
        if (block.edges.dests[j] != NULL_VAL) {
            if (f(i, block.edges.dests[j], empty_weight)) {
                return;
            }
        }
    }
}
} // namespace hpma