#pragma once

#include <limits>
#include <random>
#include <tuple>
#include <vector>

namespace dcsr {

//#if defined(LONG)
////typedef uint64_t uint_t;
//typedef int64_t int_t;
//#define REDISTRIBUTE_PAR_SIZE (UINT64_MAX)
//#else
typedef uint32_t uint_t;
typedef int32_t int_t;
//#define REDISTRIBUTE_PAR_SIZE (UINT32_MAX)
//#endif


} // namespace dcsr
