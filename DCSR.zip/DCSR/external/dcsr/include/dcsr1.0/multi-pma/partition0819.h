// Discription: the main structure of dcsr subgraph

using namespace std;

#pragma once

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <vector>
#include <tuple>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <immintrin.h>
#include <atomic>
#include <stdint.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream> 
#include <string> 
#include <malloc.h>

#include "ParallelTools/parallel.h"
#include "ParallelTools/reducer.h"
#include "gbbs/bridge.h"
#include "lock.h"

#include <cassert>
#include <mutex>
#include <sys/mman.h>
#include "types.h"

#include <immintrin.h>
#include <iostream>
#include <iomanip>  

namespace dcsr {

// define the null value in the array
#define NULL_VAL (UINT32_MAX)

// define the sentinel value in the array
#define SENT_VAL (UINT32_MAX - 1)

// define the lower density bound for the pma
#define LOWER_DENSITY_BOUND (0.25)

// define the upper density bound for the pma
#define UPPER_DENSITY_BOUND (0.75)

// define the block size, 16 cache lines
constexpr size_t BLOCK_SIZE = 16 * 64;

typedef struct _node {
  uint_t beginning;
  uint_t end;
  uint32_t degree;
} node_t;

typedef struct _index {
  uint32_t index;
  uint_t non_null_num;
  LOCK locks;
  double last_dist_time;
} index_t;

class SMA {
public:
  uint_t N; // number of items in the SMA
  uint_t BN; // number of items in a blcok
  uint32_t num_blocks;
  uint_t H; // height of the SMA
  index_t *indices;
  uint32_t *dests;
  uint32_t *vals;
  std::vector<node_t> nodes;
  
  SMA(uint32_t init_n);
  ~SMA();
  void print_graph();
  void print_array(uint_t index, uint32_t len);
  void add_node();
  void clear();
  uint_t get_size();
  void build_from_edges(uint32_t *srcs, uint32_t *dests, uint8_t *is_edge, uint_t vertex_count, uint_t edge_count, uint32_t *degrees);

  void double_list();
  void half_list();
  void slide_right(uint_t index);
  void slide_left(uint_t index);
  void redistribute(uint_t index, uint32_t len);
  uint_t fix_sentinel(uint32_t node_index, uint_t in);
  uint32_t find_value(uint32_t src, uint32_t dest);
  uint32_t get_depth(uint32_t len);
  uint32_t find_block(uint32_t index);
  uint32_t binary_search(uint32_t elem, uint32_t start, uint32_t end);

  bool insert(uint_t index, uint32_t src, uint32_t dest, uint32_t value);
  bool delete(uint_t index, uint32_t src, uint32_t dest);
  void add_edge(uint32_t src, uint32_t dest, uint32_t value);
  void remove_edge(uint32_t src, uint32_t dest);
};

inline void SMA::print_array(uint_t index, uint32_t len) {
  for (uint_t i = index; i < index + len; i++) {
    printf("(%d, %u) ", i, dests[i]);
  }
  printf("\n");
}

inline uint32_t SMA::find_block(uint32_t index) { return (index / BN) * BN; }

// height of this node in the tree
inline uint32_t SMA::get_depth(uint32_t len) { return bsr_word(N / len); }

// TODO: optimize this function
// important: make sure start, end don't include sentinels
// returns the index of the smallest element bigger than you in the range
// [start, end) if no such element is found, returns end (because insert shifts
// everything to the right)
inline uint32_t SMA::binary_search(uint32_t elem, uint32_t start, uint32_t end) {
  while (start + 1 < end) {
    uint32_t mid = (start + end) / 2;

    uint32_t item = dests[mid];
    uint32_t change = 1;
    uint32_t check = mid;

    bool flag = true;
    while ((item == NULL_VAL) && flag) {
      flag = false;
      check = mid + change;
      if (check < end) {
        flag = true;
        if (check <= end) {
          item = dests[check];
          if (item != NULL_VAL) {
            break;
          } else if (check == end) {
            break;
          }
        }
      }
      check = mid - change;
      if (check >= start) {
        flag = true;
        item = dests[check];
      }
      change++;
    }

    if ((item == NULL_VAL) || start == check || end == check) {
      if ((item != NULL_VAL) && start == check && elem <= item) {
        return check;
      }
      return mid;
    }

    // if we found it, return
    if (elem == item) {
      return check;
    } else if (elem < item) {
      end =
          check; // if the searched for item is less than current item, set end
    } else {
      start = check;
      // otherwise, searched for item is more than current and we set start
    }
  }
  if (end < start) {
    start = end;
  }

  if (elem <= dests[start] && (dests[start] != NULL_VAL)) {
    return start;
  }
  return end;
}

inline SMA::SMA(uint32_t init_n) {
  N = 2 << bsr_word(init_n);
  BN = BLOCK_SIZE / sizeof(uint32_t);
  num_blocks = N / BN;
  H = bsr_word(num_blocks);
  
  indices = (index_t *)aligned_alloc(64, num_blocks * sizeof(index_t));
  dests = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t)); 
  vals = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));

  for (int i = 0; i < N; i++) {
    vals[i] = NULL_VAL;
    dests[i] = NULL_VAL;
  }

  for (int i = 0; i < (N / BN); i++) {
    indices[i].index = NULL_VAL;
    indices[i].non_null_num = 0;
    indices[i].locks.init();
    indices[i].last_dist_time = 0.0;
  }

  nodes.reserve(init_n);
  for (uint32_t i = 0; i < init_n; i++) {
    add_node();
  }
}

inline SMA::~SMA() { 
  free(indices);
  free(dests);
  free(vals);  
}

inline void SMA::print_graph() {
  for (int i = 0; i < nodes.size(); i++) { 
    for (uint32_t j = nodes[i].beginning + 1; j < nodes[i].end; j++) {
        if (dests[j] != NULL_VAL) {
            printf("(%03d, %03d)", i, dests[j]);
        }
    }
    printf("\n");   
  }
}

void inline SMA::add_node() {
  node_t node;
  int len = nodes.size();
  uint32_t sentinel_dest = SENT_VAL;
  uint32_t sentinel_value = len;

  if (len > 0) {
    node.beginning = nodes[len - 1].end;
    node.end = node.beginning + 1;
  } else {
    node.beginning = 0;
    node.end = 1;
  }
  node.degree = 0;
  nodes.push_back(node);
  insert(node.beginning, nodes.size() - 1, sentinel_dest, sentinel_value);
}

inline void SMA::clear() {
  free(indices);
  free(dests);
  free(vals);
  uint32_t n = 0;
  N = 2 << bsr_word(n);
  H = bsr_word(N / BN);
  
  for (int i = 0; i < nodes.size(); i++) {
    nodes[i].beginning = 0;
    nodes[i].end = 0;
    nodes[i].degree = 0;
  }
}


inline void SMA::build_from_edges(uint32_t *srcs, uint32_t *dests, uint8_t *is_edge, uint_t vertex_count, uint_t edge_count, uint32_t *degrees) {
  // step 1 : build a CSR offset array
  uint32_t* vertex_array = (uint32_t*)calloc(vertex_count, sizeof(uint32_t));
  uint_t edges_num = 0;
  for (uint_t i = 0; i < edge_count; i++) {
    if (is_edge[i]) {
      uint32_t s = srcs[i];
      degrees[s]++;
      vertex_array[s]++;
      edges_num++;
    }
  }

  // step 2 : build a CSR edges array
  uint32_t* edges_array = (uint32_t*)malloc(edges_num * sizeof(uint32_t));
  uint_t edges_so_far = 0;
  for (uint_t i = 0; i < edge_count; i++) {
    if (is_edge[i]) {
      edges_array[edges_so_far] = dests[i];
      edges_so_far++;
    }
  }
  
  // step 3 : calculate the CSR offset array and get the degree of nodes
  uint_t sma_edges_num = 0;
  nodes[0].degree = degrees[0];
  sma_edges_num += degrees[0];

  for (uint32_t i = 1; i < vertex_count; i++) {
    vertex_array[i] += vertex_array[i-1];
    nodes[i].degree = degrees[i];
    sma_edges_num += degrees[i];
  }

  uint_t num_items = vertex_count + sma_edges_num;
  uint32_t *space_vals = (uint32_t *)aligned_alloc(64, num_items * sizeof(uint32_t));
  uint32_t *space_dests = (uint32_t *)aligned_alloc(64, num_items * sizeof(uint32_t));

  uint_t position_so_far = 0;
  for (uint_t i = 0; i < vertex_count; i++) {
    // set the sentinels for all the nodes
    space_dests[position_so_far] = SENT_VAL;
    space_vals[position_so_far] = i;
    position_so_far++;
    // then write the edges, the values are all 1
    for (uint_t j = 0; j < degrees[i]; j++) {
        if (i == 0) {
          space_dests[position_so_far] = edges_array[j];
          space_vals[position_so_far] = 1;
        } else {
          space_dests[position_so_far] = edges_array[vertex_array[i - 1] + j];
          space_vals[position_so_far] = 1;
        }
        position_so_far++;
    }
  }
 // assert(num_items == position_so_far);
  
  while (N < num_items) { N *= 2; }
  num_blocks = N / BN;
  H = bsr_word(num_blocks);
  uint_t count_per_block = num_items / num_blocks;
  uint_t extra = num_items % num_blocks;
  
  uint32_t *new_vals = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  uint32_t *new_dests = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  uint32_t *new_indices = (index_t *)aligned_alloc(64, num_blocks * sizeof(index_t));

  parlay::parallel_for (0, N, [&](uint_t i) {
    new_vals[i] = NULL_VAL; // setting to null
    new_dests[i] = NULL_VAL; // setting to null
  });
  
  parlay::parallel_for(0, num_blocks, [&](uint_t i) {
  // uint32_t node_index_last = NULL_VAL;
  // for(uint_t i = 0; i < num_blocks; i++) {
    // how many are going to this leaf
    count_for_block = count_per_block + (i < extra);
    // start of leaf in output
    uint_t in = i * BN;
    // start in input
    uint_t j2 = count_per_block*i +min(i,extra);
    uint_t j3 = j2;
    // // // // printf("real count %u, num_leaves %u, leaf %u, count_for_block = %u, in = %u, j2 = %u, j3 = %u\n", num_items, num_leaves, i, count_for_block, in, j2, j3);
    for(uint_t k = in; k < count_for_block + in; k++) {
     // assert(j2 < num_items);
      new_vals[k] = space_vals[j2];
      j2++;
    }
    
    for (uint_t k = in; k < count_for_block + in; k++) {
      new_dests[k] = space_dests[j3];
      if (new_dests[k] == SENT_VAL) {
        // fixing pointer of node that goes to this sentinel
        uint32_t node_index = space_vals[j3];
        fix_sentinel(node_index, k);
      }
      j3++;
    } 

    new_indices[i].non_null_num = count_for_block;
    new_indices[i].index = new_dests[in];
    new_indices[i].locks.init();
    new_indices[i].last_dist_time = 0.0;
  });

  free(space_dests);
  free(space_vals);
  free(vertex_array);
  free(edges_array);
  free(vals);
  free(dests);
  free(indices);
  vals = new_vals;
  dests = new_dests;
  indices = new_indices;
}
  
inline void SMA::double_list() {
  N *= 2;
  num_blocks *= 2;
  H = H + 1;
  uint32_t *new_dests = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  index_t *new_indices = (index_t *)aligned_alloc(64, num_blocks * sizeof(index));

  std::memcpy(new_vals, vals, (N / 2) * sizeof(uint32_t));
  std::memcpy(new_dests, dests, (N / 2) * sizeof(uint32_t));
  std::memcpy(new_indices, indices, (num_blocks / 2) * sizeof(index_t));

  for (int i = N / 2; i < N; i++) {
    new_vals[i] = NULL_VAL;
    new_dests[i] = NULL_VAL;
  }

  for (int i = num_blocks / 2; i < num_blocks; i++) {
    new_indices[i].index = NULL_VAL;
    new_indices[i].item_num = 0;
    new_indices[i].locks.lock(); // lock the blocks
    new_indices[i].last_dist_time = 0.0;
  }

  free(dests);
  free(vals);
  free(indices);
  dests = new_dests;
  vals = new_vals;
  indices = new_indices;
  redistribute(0, N);
}

inline void SMA::half_list() {
  N /= 2;
  num_blocks /= 2;
  H = H - 1;
  uint32_t *new_dests = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  index_t *new_indices = (index_t *)aligned_alloc(64, num_blocks * sizeof(index));
 
  uint32_t j = 0;
  for (uint32_t i = 0; i < N * 2; i++) {
    if (dests[i] != NULL_VAL) {
      new_vals[j] = vals[i];
      new_dests[j] = dests[i];
      j++;
    }
  }
  for (uint_t i = j; i < N; i++) {
		new_vals[i] = NULL_VAL; 
    new_dests[i] = NULL_VAL;
	}

  for (int i = 0; i < num_blocks; i++) {
    new_indices[i].index = NULL_VAL;
    new_indices[i].item_num = 0;
    new_indices[i].locks.lock(); // lock the blocks
    new_indices[i].last_dist_time = 0.0;
  }

  free(vals);
  free(dests);
  free(indices);
  vals = new_vals;
  dests = new_dests;
  indices = new_indices;
  redistribute(0, N);
}

void inline SMA::slide_right(uint_t index) {
  uint32_t right_block_index = (find_block(index) + BN < N) ? (find_block(index) + BN) : N;
  uint32_t el_dest = dests[index];
  uint32_t el_value = vals[index];
  dests[index] = NULL_VAL;
  vals[index] = NULL_VAL;
  index++;
  while (index < right_block_index && (dests[index] != NULL_VAL)) {
    uint32_t temp_dest = dests[index];
    uint32_t temp_value = vals[index];
    dests[index] = el_dest;
    vals[index] = el_value;
    if (el_dest == SENT_VAL) {
      uint32_t node_index = el_value;
      fix_sentinel(node_index, index);
    }
    el_dest = temp_dest;
    el_value = temp_value;
    index++;
  }
  if (el_dest == SENT_VAL) {
    uint32_t node_index = el_value;
    fix_sentinel(node_index, index);
  }

  dests[index] = el_dest;
  vals[index] = el_value;
}

void inline SMA::slide_left(uint_t index) {
  uint32_t right_block_index = (find_block(index) + BN < N) ? (find_block(index) + BN) : N;
  while (index + 1 < right_block_index) {
    uint32_t temp_dest = dests[index + 1];
    uint32_t temp_value = vals[index + 1];
    dests[index] = temp_dest;
    vals[index] = temp_value;
    if (temp_dest == SENT_VAL) {
      uint32_t node_index = temp_value;
      fix_sentinel(node_index, index);
    }
    if (dests[index] == NULL_VAL) {
      break;
    }
    index++;
  }
}

inline void SMA::redistribute(uint_t index, uint32_t len) {
  uint32_t *space_vals = (uint32_t *)aligned_alloc(64, len * sizeof(uint32_t));
  uint32_t *space_dests = (uint32_t *)aligned_alloc(64, len * sizeof(uint32_t));
  
  uint_t j = 0;
  for (uint_t i = index; i < index + len; i + = 16) {
    for (uint_t k = i; k < i + 16; k++) {
      space_vals[j] = vals[k];
      space_dests[j] = dests[k];
      // counting non-null edges
      j += (space_dests[j]!=NULL_VAL);
    }
    // why
    memset (__builtin_assume_aligned((void*)&vals[i], 64), NULL_VAL, 16*sizeof(uint32_t));
    memset (__builtin_assume_aligned((void*)&dests[i], 64), NULL_VAL, 16*sizeof(uint32_t));
  }
  
  uint_t num_blocks = len / BN;
  uint_t count_per_block = j / num_blocks;
  uint_t extra = j % num_blocks;
  __builtin_prefetch ((void *)&nodes, 0, 3);

  // parallizing does not make it faster
  uint_t end_sentinel = 0;
  for (uint_t i = 0; i < num_blocks; i++) {
    uint_t count_for_block = count_per_block + (i < extra);
    uint_t in = index + (logN * (i));
    uint_t j2 = count_per_block*i + min(i,extra);
    //TODO could be parallized, but normally only up to size 32
    uint_t j3 = j2;
    memcpy(__builtin_assume_aligned((void*)&vals[in], 64), (void*)&space_vals[j2], count_for_block*sizeof(uint32_t));
    if (end_sentinel > in + count_for_block) {
      memcpy(__builtin_assume_aligned((void*)&dests[in], 64), (void*)&space_dests[j2], count_for_block*sizeof(uint32_t));
    } else { 
      for (uint_t k = in; k < count_for_block + in; k++) {
        dests[k] = space_dests[j3];
        if (dests[k]==SENT_VAL) {
          // fixing pointer of node that goes to this sentinel
          uint32_t node_index = vals[k];
          end_sentinel = fix_sentinel(node_index, k);
        }
        j3++;
      }
    }
  }
  free(space_dests);
  free(space_vals);
}

inline uint_t SMA::fix_sentinel(uint32_t node_index, uint_t in) {
  nodes[node_index].beginning = in;
  if (node_index > 0) {
    nodes[node_index - 1].end = in;
  }
  if (node_index == nodes.size() - 1) {
    nodes[node_index].end = N - 1;
  }
  return nodes[node_index].beginning + nodes[node_index].num_neighbors;
}

inline uint32_t SMA::find_value(uint32_t src, uint32_t dest) {
  uint32_t loc =
      binary_search(&dests, dest, nodes[src].beginning + 1, nodes[src].end);
  if ((dests[loc] != NULL_VAL) && dests[loc] == dest) {
    return vals[loc];
  } else {
    return 0;
  }
}

// this function can handle the case when the edge is already in the pma
// it will update the value of the edge if it is already in the pma
// only return true
bool inline SMA::insert(uint_t index, uint32_t src, uint32_t dest, uint32_t value) {
  //printf("insert: inserting %u, %u at index %u\n", src, elem.dest, index);
  int node_index = find_leaf(&pma_edges, index);
  int level = pma_edges.H;
  int len = pma_edges.logN;
  bool ret = false;
  // if the item is null, put the elem in it
  // is this the only case when the elem is a sentinel?
  if (pma_edges.dests[index] == NULL_VAL) {
    // // // // printf("insert: inserting %u, %u at index %u\n", elem.value, elem.dest, index);
    pma_edges.dests[index] = elem.dest;
    pma_edges.vals[index] = elem.value;
    ret = true;
  } else {
    // else the item may be a sentinel or an edge
    // the 1st case, the item is a edge and is the same as the elem edge
    // this mean the elem edge already exists in the graph, update its value
    // the 2nd case, the item is a edge and is not the same as the elem edge
    // the 3rd case, the item is a edge and the elem edge is a sentinel
    // the 4th case, the item is a sentinel and the elem edge is a edge
    // the 5th case, the item is a sentinel and the elem edge is a sentinel
    // in these cases, we need to slide right
    if (pma_edges.dests[index] == elem.dest) {
      pma_edges.vals[index] = elem.value;
      ret = true;
      return ret;
    } else {
      slide_right(index); 
      pma_edges.dests[index] = elem.dest;
      pma_edges.vals[index] = elem.value;
      ret = true;
    }
  }
  // increment the degree of the node
  nodes[src].degree++;
  // get density of the leaf you are in
  double density_b = (density_bound(&pma_edges, level)).y;
  double density = get_density(&pma_edges, node_index, len);
  //if (block_index == 32734) 
      //printf("insert: density = %f, density_b = %f, len = %d \n", density, density_b, len);
  // while density too high, go up the implicit tree
  // go up to the biggest node above the density bound
  // for the last node, we need to redistribute to let the last item in the pma to be NULL
  // int last_node_index = ((pma_edges.N - 1) / pma_edges.logN) * pma_edges.logN;
  while (density >= density_b) {
    len *= 2;
    if (len <= pma_edges.N) {
      level--;
      node_index = find_node(node_index, len);
      density_b = (density_bound(&pma_edges, level)).y;
      density = get_density(&pma_edges, node_index, len);
      //if (block_index == 32734) 
          //printf("insert: new density = %f, new density_b = %f, len = %d \n", density, density_b, len);
    } else {
      double_list();
      return ret;
    }
  }
  
  //uint32_t last_node_index = ((pma_edges.N - 1) / pma_edges.logN) * pma_edges.logN;
  //if (len > pma_edges.logN || node_index == last_node_index) {
    redistribute(node_index, len);
  //}

  // uint32_t last_node_index = ((pma_edges.N - 1) / pma_edges.logN) * pma_edges.logN;
  // get density of the leaf you are in
  //double density_b = (density_bound(&pma_edges, pma_edges.H)).y;
  //double density = get_density(&pma_edges, last_node_index, len);

  // printf("insert: new density = %f, new density_b = %f\n", density, density_b);
  //print_array(&pma_edges, node_index, len);
  //redistribute(node_index, len);
  //print_array(&pma_edges, node_index, len);s
  return ret;
}

// this function can not handle the case when the edge is not in the pma
// so we need to make sure that the edge is in the pma before calling this function
// only return true
bool inline SMA::delete(uint_t index, uint32_t src, uint32_t dest) {
  uint_t node_index = find_leaf(&pma_edges, index);
  int level = pma_edges.H;
  uint_t len = pma_edges.logN;

  // delte the element at index by slide left
  slide_left(index);
  // pma_edges.dests[index] = NULL_VAL;
  // pma_edges.vals[index] = NULL_VAL;
  nodes[src].degree--;

  double density_b = (density_bound(&pma_edges, level)).x;
  double density = get_density(&pma_edges, node_index, len);
  // printf("delete: density = %f, density_b = %f\n", density, density_b);
  // while density too low, go up the implicit tree
  // go up to the biggest node below the density bound
  while (density <= density_b) {
    len *= 2;
    if (len <= pma_edges.N) {
      level--;
      // orig_n = pma_edges.N;
      node_index = find_node(node_index, len);
      density_b = (density_bound(&pma_edges, level)).x;
      density = get_density(&pma_edges, node_index, len);
      // printf("delete: new density = %f, new density_b = %f\n", density, density_b);
    } else {
      // printf("delete: reached the root, len = %u, pma_edges.N = %u\n", len, pma_edges.N);
      half_list();
      return true;
    }
  }
  //if (len > pma_edges.logN) {
    // printf("delete: redistributing at node_index = %u, len = %u\n", node_index, len);
    redistribute(node_index, len);
  //}
  //redistribute(node_index, len);
  return true;
}

inline void SMA::add_edge(uint32_t src, uint32_t dest, uint32_t value) {
    node_t node = nodes[src];
    uint32_t loc_to_add =
        binary_search(&dests, dest, node.beginning + 1, node.end);
    if (insert(loc_to_add, src, dest, value)) {
     
      return;
    }
}

// remove edge from the block
inline void SMA::remove_edge(uint32_t src, uint32_t dest) {
    node_t node = nodes[src];
    uint32_t loc_to_remove =
        binary_search(&dests, dest, node.beginning + 1, node.end);
    // make sure that the edge is in the pma
    if (dests[loc_to_remove] == dest) {
      // printf("removing edge %u -> %u from pma\n", src, dest);
      if (delete(loc_to_remove, e, src)) {
        return; 
      }
    } else {
      return; // edge not found in pma
    } 
}

inline uint_t SMA::get_size() {
  // the size of block includes the size of the block, 
  uint_t size = sizeof(SMA);
  size += N * sizeof(uint32_t) * 2;
  size += nodes.size() * sizeof(node_t);
  size += sizeof(index_t) * (N / BN);
  return size;
}

}