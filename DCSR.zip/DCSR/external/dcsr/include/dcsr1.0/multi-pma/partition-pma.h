// Discription: the main structure of dcsr subgraph

using namespace std;

#pragma once

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <vector>
#include <tuple>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <immintrin.h>
#include <atomic>
#include <stdint.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream> 
#include <string> 

#include "ParallelTools/parallel.h"
#include "ParallelTools/reducer.h"
#include "gbbs/bridge.h"
#include "PMA_Lock.hpp"

#include <cassert>
#include <mutex>
#include <sys/mman.h>
#include "types.h"
#include "integer_log2.h"

#include <immintrin.h>
#include <iostream>
#include <iomanip>    


namespace dcsr {

#if defined(LONG)
typedef uint64_t uint_t;
typedef int64_t int_t;
#define REDISTRIBUTE_PAR_SIZE (UINT64_MAX)
#else
typedef uint32_t uint_t;
typedef int32_t int_t;
#define REDISTRIBUTE_PAR_SIZE (UINT32_MAX)
#endif

#define NULL_VAL (UINT32_MAX)
#define SENT_VAL (UINT32_MAX -1)

// define the max number of vertices in the block
constexpr size_t MAX_EDGES_PMA = (1ULL << 30); 

// ======================================================================
// HASH
// ======================================================================
using index_type = size_t;
inline index_type illegalIndex() { return static_cast<index_type>(-1); };
inline index_type tombstoneIndex() { return static_cast<index_type>(-2); };

// To deal with the hash conflict?
inline index_type index_hash_table(unsigned int hash, index_type current_index,
                                   unsigned int bsize) {
    return (hash + current_index) & (2 * bsize - 1);
}

// Taken from https://stackoverflow.com/a/12996028.
inline unsigned int hash_node(unsigned int x) {
    x = ((x >> 16) ^ x) * 0x45d9f3b;
    x = ((x >> 16) ^ x) * 0x45d9f3b;
    x = (x >> 16) ^ x;
    return x;
}

template <typename E> class BlockState {
  public:
    // TODO:
    // input: node ID, function: if degree is not zero but the begin and end 
    // index of PMA are the same, meaning the neighbors are in hash tabel
    inline bool in_htab() const{
      //if (degree > 0 && beginning == end) { // maybe wrong
        //return true;
      //}
      return false;
      // return degree > MAX_EDGES_PMA;
    }

    // TODO: when initializing the node state, if the degree of a vertex is 
    // larger than the maximum of edges in the PMA, then we use a hash table 
    inline bool use_htab() const{
      return degree > MAX_EDGES_PMA;
    }

    // TODO: if the size of PMA reaches a certain threshold, delete the neighbors
    // of vertex with max degree in PMA, and allocate a hash table and put its
    // neighbors in the hash table 
    //inline bool pma_to_htab(size_t bsize) {
      // delete pma
      // allocate hash table
      // insert hash table
    //}

    struct Entry {
        Vertex vertex;
        E data;
    };

    static constexpr size_t entry_size = sizeof(Entry);

    // Why we need a p pointer
    struct proxy {
        explicit proxy(Entry* ptr) : m_ptr(ptr) {}

        Vertex vertex() const { return m_ptr->vertex; }
        E& data() const { return m_ptr->data; }

      private:
        Entry* m_ptr;
    };

    struct const_proxy {
        explicit const_proxy(const Entry* ptr) : m_ptr(ptr) {}

        const Vertex vertex() const { return m_ptr->vertex; }
        const E& data() const { return m_ptr->data; }

      private:
        const Entry* m_ptr;
    };

    // Helper class to implement operator-> of iterator.
    struct arrow {
        arrow(Entry* ptr) : m_p(ptr) {}

        proxy* operator->() { return &m_p; }

      private:
        proxy m_p;
    };

    // Helper class to implement operator-> of const_iterator.
    struct const_arrow {
        const_arrow(const Entry* ptr) : m_p(ptr) {}

        const_proxy* operator->() { return &m_p; }

      private:
        const_proxy m_p;
    };

    struct iterator {
        using value_type = proxy;
        using reference = proxy; // decltype(operator*)
        using pointer = arrow;   // decltype(operator->)
        using difference_type = ptrdiff_t;
        // In the legacy sense, this is only an input iterator since the reference type
        // is not a true reference. In the modern sense, this is a random access iterator.
        using iterator_category = std::input_iterator_tag;
        using iterator_concept = std::random_access_iterator_tag;

        friend bool operator==(iterator lhs, iterator rhs) { return lhs.m_ptr == rhs.m_ptr; }
        friend bool operator!=(iterator lhs, iterator rhs) { return lhs.m_ptr != rhs.m_ptr; }

        friend ptrdiff_t operator-(iterator lhs, iterator rhs) { return lhs.m_ptr - rhs.m_ptr; }

        iterator() : m_ptr(nullptr) {}

        explicit iterator(Entry* ptr) : m_ptr(ptr) {}

        proxy operator*() const { return proxy(m_ptr); }
        arrow operator->() const { return arrow(m_ptr); }

        iterator operator+(ptrdiff_t delta) const {
            iterator copy = *this;
            copy += delta;
            return copy;
        }

        iterator& operator++() {
            ++m_ptr;
            return *this;
        }
        iterator& operator--() {
            --m_ptr;
            return *this;
        }
        iterator operator++(int) {
            iterator copy = *this;
            ++(*this);
            return copy;
        }
        iterator operator--(int) {
            iterator copy = *this;
            --(*this);
            return copy;
        }
        iterator& operator+=(ptrdiff_t delta) {
            m_ptr += delta;
            return *this;
        }
        iterator& operator-=(ptrdiff_t delta) {
            m_ptr -= delta;
            return *this;
        }

        Entry* get_ptr() const { return m_ptr; }

      private:
        Entry* m_ptr;
    };

    struct const_iterator {
        using value_type = const_proxy;
        using reference = const_proxy; // decltype(operator*)
        using pointer = const_arrow;   // decltype(operator->)
        using difference_type = ptrdiff_t;
        // In the legacy sense, this is only an input iterator since the reference type
        // is not a true reference. In the modern sense, this is a random access iterator.
        using iterator_category = std::input_iterator_tag;
        using iterator_concept = std::random_access_iterator_tag;

        friend bool operator==(const_iterator lhs, const_iterator rhs) {
            return lhs.m_ptr == rhs.m_ptr;
        }
        friend bool operator!=(const_iterator lhs, const_iterator rhs) {
            return lhs.m_ptr != rhs.m_ptr;
        }

        friend ptrdiff_t operator-(const_iterator lhs, const_iterator rhs) {
            return lhs.m_ptr - rhs.m_ptr;
        }

        const_iterator() : m_ptr(nullptr) {}

        explicit const_iterator(const Entry* ptr) : m_ptr(ptr) {}

        // Conversion of iterator to const_iterator.
        const_iterator(iterator other) : m_ptr(other.get_ptr()) {}

        const_proxy operator*() const { return const_proxy(m_ptr); }
        const_arrow operator->() const { return const_arrow(m_ptr); }

        const_iterator operator+(ptrdiff_t delta) const {
            const_iterator copy = *this;
            copy += delta;
            return copy;
        }

        const_iterator& operator++() {
            ++m_ptr;
            return *this;
        }
        const_iterator& operator--() {
            --m_ptr;
            return *this;
        }
        const_iterator operator++(int) {
            const_iterator copy = *this;
            ++(*this);
            return copy;
        }
        const_iterator operator--(int) {
            const_iterator copy = *this;
            --(*this);
            return copy;
        }
        const_iterator& operator+=(ptrdiff_t delta) {
            m_ptr += delta;
            return *this;
        }
        const_iterator& operator-=(ptrdiff_t delta) {
            m_ptr -= delta;
            return *this;
        }

        const Entry* get_ptr() const { return m_ptr; }

      private:
        const Entry* m_ptr;
    };

    BlockState() : bsize{0}, degree{0}, beginning{0}, end{0}, entries{nullptr}, htab{nullptr} {}

    /*
    // TODO: initialize the node state
    BlockState(BlockHandle bhandle)
        : bsize{bhandle.bsize()}, degree{0},
          entries{static_cast<Entry*>(bhandle.access_entries())}, htab{bhandle.access_htab()} {
        // Clear the hash table.
        if (use_htab()) {
            index_type* const hash_table = htab;
            for (size_t j = 0; j < 2 * bsize; ++j) {
                hash_table[j] = illegalIndex();
            }
        }
    }
    
    // TODO: copy the node state
    BlockState(BlockHandle bhandle, const BlockState& other)
        : bsize{bhandle.bsize()}, degree{other.degree},
          entries{static_cast<Entry*>(bhandle.access_entries())}, htab{bhandle.access_htab()} {
       // assert(other.degree <= bsize);
        for (size_t i = 0; i < other.degree; ++i)
            entries[i] = other.entries[i];
        if (in_htab())
            rebuild_ht();
    }*/

    BlockState(const BlockState&) = default;

    BlockState(BlockState&& other) = default;

    BlockState& operator=(const BlockState&) = default;

    BlockState& operator=(BlockState&&) = default;

    // ptrdiff_t bsize() const { return bsize; }

    // ptrdiff_t degree() const { return degree; }

    // Returns true if the neighbor was inserted.
    // Returns false if the neighbor was found.
    std::tuple<iterator, bool> insert(Vertex v, E ed) {
       // assert(degree < bsize);

        if (in_htab()) {
            index_type* htab = htab;
            auto h = hash_node(v);
            index_type j;
            index_type ts = illegalIndex();
            for (index_type i = 0; true; ++i) {
                if (i == bsize) {
                   // assert(ts != illegalIndex());
                    break;
                }
                j = index_hash_table(h, i, bsize);

                if (htab[j] == illegalIndex())
                    break;
                if (htab[j] == tombstoneIndex()) {
                    ts = j;
                    continue;
                }
                auto ptr = &entries[htab[j]];
                if (ptr->vertex == v)
                    return {iterator(ptr), false};
            }

            // If we did hit a tombstone, insert at the tombstone.
            if (ts != illegalIndex())
                j = ts;

            // Insert into the adjacency list.
            auto i = degree++;
            htab[j] = i;
            entries[i] = {v, ed};
            return {iterator(&entries[i]), true};
        } else {
            // Find the node with the adjacency list.
            for (index_type i = 0; i < degree; ++i)
                if (entries[i].vertex == v)
                    return {iterator(&entries[i]), false};

            // Insert into the adjacency list.
            auto i = degree++;
            entries[i] = {v, ed};
            return {iterator(&entries[i]), true};
        }
    }

    // true = node was removed.
    bool remove(Vertex const v) {
        if (in_htab()) {
            // Find the node within the hash table.
            index_type* const hash_table = htab;

            unsigned int const hv = hash_node(v);
            size_t jv = 0; // Hash table index.
            for (index_type i = 0; true; ++i) {
                if (i == bsize) {
                    return false;
                }

                jv = index_hash_table(hv, i, bsize);

                if (hash_table[jv] == illegalIndex()) {
                    return false;
                }

                if (hash_table[jv] == tombstoneIndex()) {
                    continue;
                }

                if ((entries + hash_table[jv])->vertex == v) {
                    break;
                }
            }

            auto back_it = std::prev(entries + degree);
            if (entries + hash_table[jv] != back_it) {
                auto w = back_it->vertex;

                unsigned int const hw = hash_node(w);
                size_t jw = 0; // Hash table index.
                for (index_type i = 0; true; ++i) {
                    // Otherwise, w is not in the HT.
                   // assert(i != bsize);

                    jw = index_hash_table(hw, i, bsize);

                    // Otherwise, w is not in the HT.
                   // assert(hash_table[jw] != illegalIndex());

                    if (hash_table[jw] == tombstoneIndex()) {
                        continue;
                    }

                    if ((entries + hash_table[jw])->vertex == w) {
                        break;
                    }
                }

                *(entries + hash_table[jv]) = *back_it;
                hash_table[jw] = hash_table[jv];
            }

            hash_table[jv] = tombstoneIndex();
            --degree;

            return true;
        } else {
            // Find the index.
            index_type iv;
            for (iv = 0; iv < degree; ++iv)
                if (entries[iv].vertex == v)
                    break;

            // Otherwise, v is not in the Block.
            if (iv == degree)
                return false;

            // Swap with the last entry.
            if (iv + 1 != degree)
                entries[iv] = entries[degree - 1];

            // Remove the last entry.
            --degree;

            return true;
        }
    }

    void clear() {
        degree = 0;
        if (in_htab()) {
            for (size_t j = 0; j < 2 * bsize; ++j)
                htab[j] = illegalIndex();
        }
    }

    template <typename L> void sort(L less) {
        std::sort(entries, entries + degree, std::move(less));
        if (in_htab())
            rebuild_ht();
    }

    iterator iterator_to(Vertex v) const {
        if (in_htab()) {
            // Find the node within the hash table.
            auto h = hash_node(v);
            size_t j = 0; // Hash table index.
            index_type* const hash_table = htab;
            for (index_type i = 0; true; ++i) {
                if (i == bsize)
                    return valid_end();
                j = index_hash_table(h, i, bsize);

                if (hash_table[j] == illegalIndex())
                    return valid_end();
                if (hash_table[j] == tombstoneIndex())
                    continue;
                if ((entries + hash_table[j])->vertex == v)
                    break;
            }

            return iterator(entries + hash_table[j]);
        } else {
            // Find the node within the adjacency list.
            for (index_type i = 0; i < degree; ++i)
                if (entries[i].vertex == v)
                    return iterator(&entries[i]);

            return valid_end();
        }
    }

    ~BlockState() {
        if (in_htab()) {
          free(htab);
          free(entries);
        }
    }

    bool empty() const { return !degree; }

    bool full() const { return degree == bsize; }

    iterator valid_end() { return iterator(entries + degree); }

    iterator begin() { return iterator(entries); }

    const_iterator begin() const { return const_iterator(entries); }

    const_iterator valid_end() const { return const_iterator(entries + degree); }

    const_iterator cbegin() const { return const_iterator(entries); }

    // beginning and end of the associated region in the edge list
    uint_t beginning;     // deleted = max int
    uint_t end;           // end pointer is exclusive
    uint32_t degree; // number of edges with this node as source
#if ENABLE_PMA_LOCK == 1
    PMA_Lock lock;
#endif
    // the hash table for high degree vertices
    unsigned int bsize; // size of the hash Block
    Entry* entries;
    index_type* htab;

  private:
    void rebuild_ht() {
       // assert(in_htab());

        index_type* const hash_table = htab;

        // Clear the hash table.
        for (size_t j = 0; j < 2 * bsize; ++j) {
            hash_table[j] = illegalIndex();
        }

        // Re-insert all vertices.
        for (size_t i = 0; i < degree; ++i) {
            auto v = entries[i].vertex;

            // Find a free slot within the hash table.
            unsigned int const h = hash_node(v);
            size_t j = 0; // Hash table index.
            for (index_type p = 0; true; ++p) {
               // assert(p < bsize);
                j = index_hash_table(h, p, bsize);

                if (hash_table[j] == illegalIndex() || hash_table[j] == tombstoneIndex()) {
                    break;
                }

                // There cannot be any duplicates.
               // assert((entries + hash_table[j])->vertex != v);
            }

            // Insert into the hash table.
            hash_table[j] = i;
        }
    }
};

template <typename E> constexpr size_t bytes_per_entry_for() { return BlockState<E>::entry_size; }

// ======================================================================
// PMA
// ======================================================================
#define temp_pfor for

typedef struct _edge {
  uint32_t value; // length in array
  uint32_t dest;
} edge_t;

typedef struct _pair_double {
  double x;
  double y;
} pair_double;

typedef struct edge_list {
  uint_t N;
  uint32_t H;
  uint32_t logN;
  uint32_t loglogN;
  uint32_t mask_for_leaf;
  uint32_t * vals;
  uint32_t * dests;

  // Lock list_lock;

  double density_limit;
} edge_list_t;

typedef struct max_vertex {
  uint32_t v_id;
  uint32_t v_degree;
} max_vertex_t;

template <typename E> class Block {
public:
  // data members
  edge_list_t edges;
  BlockState<E> nodes[64];
  uint32_t nodes_size;
#if ENABLE_PMA_LOCK == 1
  PMA_Lock node_lock;
#endif
  uint64_t next_task_id;

  double upper_density_bound[32];
  double lower_density_bound[32];

  max_vertex_t max_pma; // maximum degree of a vertex in the PMA

  // graph_t g;
  // function headings
  Block(uint32_t init_n = 16);
  Block(const Block &other);
  ~Block();
  void double_list(uint64_t task_id, std::vector<uint_t> &sub_counts, uint_t num_elements);
  void half_list(uint64_t task_id, std::vector<uint_t> &sub_counts, uint_t num_elements);
  //void half_list();
  void slide_right(uint_t index, uint32_t *vals, uint32_t *dests);
  void slide_left(uint_t index, uint32_t *vals, uint32_t *dests);
  void redistribute(uint_t index, uint64_t len);
  void redistribute_par(uint_t index, uint64_t len, std::vector<uint_t> &sub_counts, uint_t num_elements, bool for_double = false);
  uint_t fix_sentinel(uint32_t node_index, uint_t in);
  void print_array(uint64_t worker_num = 0);
  uint32_t find_value(uint32_t src, uint32_t dest);
  void print_graph();
  void add_node();

  //assumes the edge is not already in the graph
  void add_edge(uint32_t src, uint32_t dest, uint32_t value);
  bool add_edge_update(uint32_t src, uint32_t dest, uint32_t value);


  bool add_edge_update_fast(uint32_t src, uint32_t dest, uint32_t value, uint64_t task_id);

  void add_edge_batch_update(uint32_t *srcs, uint32_t *dests, uint32_t *values, uint_t edge_count);
  void add_edge_batch_update_no_val(uint32_t *srcs, uint32_t *dests, uint_t edge_count);

  void build_from_edges(uint32_t *srcs, uint32_t *dests, uint8_t * pma_edges, uint64_t vertex_count, uint64_t edge_count, uint32_t* additional_degrees);

  // merge functions in original PMA with no val
  void add_edge_batch_update_no_val_parallel(pair_uint *es, uint64_t edge_count);
  void add_edge_batch_wrapper(pair_uint *es, uint64_t edge_count, int64_t threshold = -1);
  void remove_edge_batch_update_no_val_parallel(pair_uint *es, uint64_t edge_count);
  void remove_edge_batch_wrapper(pair_uint *es, uint64_t edge_count, int64_t threshold = -1);

  bool remove_edge(uint32_t src, uint32_t dest);
  void remove_edge_fast(uint32_t src, uint32_t dest, uint64_t task_id);
  void remove_edge_batch(uint32_t *srcs, uint32_t *dests, uint_t edge_count);
  void insert(uint64_t task_id, uint_t index, uint32_t elem_dest, uint32_t elem_value, uint32_t src
    #if ENABLE_PMA_LOCK == 1
    , pair_int held_locks
    #endif
    );
  void remove(uint64_t task_id, uint_t index, uint32_t elem_dest, uint32_t src
    #if ENABLE_PMA_LOCK == 1
    , pair_int held_locks
    #endif
    );
  uint64_t get_size();
  uint64_t get_n();
  std::vector<std::tuple<uint32_t, uint32_t, uint32_t>> get_edges();
  void clear();
  bool check_no_locks();
  bool check_no_locks_for_me(uint64_t task_id);
  bool check_no_node_locks_for_me(uint64_t task_id);
  bool check_no_node_locks_held_by_me(uint64_t task_id);
  bool grab_all_locks(uint64_t task_id, bool exclusive, REASONS reason = GENERAL);
  void release_all_locks(uint64_t task_id, bool exclusive, REASONS reason = GENERAL);
  pair_int grab_locks_in_range_with_resets(uint64_t task_id, uint_t index, uint_t len, REASONS reason, uint32_t guess);
  pair_int grab_locks_for_leaf_with_resets(uint64_t task_id, uint32_t src, REASONS reason = GENERAL);
  void release_locks_in_range(uint64_t task_id, pair_int locks, REASONS reason = GENERAL);
  uint32_t find_contaning_node(uint_t index);

  pair_int which_locks_in_range(uint_t index, uint_t len, uint32_t guess);
  pair_int which_locks_for_leaf(uint32_t src);
  bool check_every_lock_in_leaf(uint64_t task_id, uint_t index);
  bool check_every_lock_in_node(uint64_t task_id, uint_t index, uint_t len);

  uint32_t num_neighbors(uint32_t node) {
    return nodes[node].degree;
  }
  uint64_t num_edges() {
    uint64_t num = 0;
    for (uint64_t i = 0; i < get_n(); i++) {
      num += num_neighbors(i);
    }
    return num;
  }

 class iterator {
  public:
    uint_t place;
    uint_t end;
    uint32_t * vals;
    uint32_t * dests;
    uint8_t loglogN;
    iterator(const Block *G, uint32_t node, bool start) {
      if (!start) {
        place = G->nodes[node].end;
        return;
      }
      place = G->nodes[node].beginning + 1;
      end = G->nodes[node].end;
      vals = (uint32_t *)G->edges.vals;
      dests = (uint32_t *)G->edges.dests;
      loglogN = G->edges.loglogN;
      while ((place < end) && (dests[place] == NULL_VAL)) {
        place = ((place >> loglogN) + 1) << (loglogN);
      }
      if (place > end) {
        place = end;
      }
      return;
    }
    iterator () {}
    iterator(const iterator & other) {
      place = other.place;
      end = other.end;
      vals = other.vals;
      dests = other.dests;
      loglogN = other.loglogN;
    }
    bool operator==(const iterator& other) const {
      return (place == other.place);
    }
    bool operator!=(const iterator& other) const {
      return (place != other.place);
    }
    iterator& operator++() {
      place += 1;
      while ((place < end) && (dests[place] == NULL_VAL)) {
        place = ((place >> loglogN) + 1) << (loglogN);
      }
      if (place > end) {
        place = end;
      }
      return *this;
    }
    edge_t operator*() const {
      return {vals[place], dests[place]};
    }
  };
  iterator begin(uint32_t node) const {
    return iterator(this, node, true);
  }
  iterator end(uint32_t node) const {
    return iterator(this, node, false);
  }
};

// same as find_leaf, but does it for any level in the tree
// index: index in array
// len: length of sub-level.
static inline uint_t find_node(uint_t index, uint_t len) { return (index / len) * len; }

// PMA.cpp below

// given index, return the starting index of the leaf it is in
//TODO this could be aster if we store a mask and just do a single and
static uint_t find_leaf(edge_list_t *list, uint_t index) {
  return index & list->mask_for_leaf;
}


static uint_t find_prev_valid(uint32_t volatile  * volatile dests, uint_t start) {
  while (dests[start] == NULL_VAL) {
    start--;
  }
  return start;
}

/*
// same as find_leaf, but does it for any level in the tree
// index: index in array
// len: length of sub-level.
static inline int find_node(int index, int len) { return (index / len) * len; }
*/
template <typename E>
bool inline Block<E>::check_no_locks() {
  bool ret = true;
#if ENABLE_PMA_LOCK == 1
  ret = ret && node_lock.check_unlocked();
 // assert(node_lock.check_unlocked());
  // ret = ret && edges.list_lock.check_unlocked();
  //// assert(edges.list_lock.check_unlocked());
  for (uint32_t i = 0; i < nodes_size; i++) {
    ret = ret && nodes[i].lock.check_unlocked();
    if (!ret) {
      printf("found lock on iter %d\n", i);
    }
    ret = ret && (nodes[i].lock.reason == GENERAL);
    if (!ret) {
      printf("found lock on iter %d with %d reason\n", i, nodes[i].lock.reason);
    }
   // assert(nodes[i].lock.check_unlocked());
   // assert(nodes[i].lock.reason == GENERAL);
  }
#endif
  return ret;
}

template <typename E>
bool inline Block<E>::check_no_locks_for_me(uint64_t task_id) {

  bool ret = true;
#if ENABLE_PMA_LOCK == 1
  ret = ret && !node_lock.i_own_lock(task_id);
 // assert(!node_lock.i_own_lock(task_id));
  // ret = ret && edges.list_lock.check_unlocked();
  //// assert(edges.list_lock.check_unlocked());
  for (uint32_t i = 0; i < nodes_size; i++) {
    ret = ret && !nodes[i].lock.i_own_lock(task_id);
    if (!ret) {
      printf("found lock on iter %d\n", i);
    }
    ret = ret && (nodes[i].lock.reason_set_by != task_id);
    if (!ret) {
      printf("found lock on iter %d that worker %lu set the reason with %d\n", i,task_id, nodes[i].lock.reason);
    }
   // assert(!nodes[i].lock.i_own_lock(task_id));
   // assert(nodes[i].lock.reason_set_by != task_id);
  }
#endif
  return ret;
}  

template <typename E>
bool inline Block<E>::check_no_node_locks_for_me(uint64_t task_id) {
#if ENABLE_PMA_LOCK == 0
  return true;
#else
bool ret = true;
  for (uint32_t i = 0; i < nodes_size; i++) {
    ret = ret && !nodes[i].lock.i_own_lock(task_id);
    if (!ret) {
      printf("found lock on iter %d\n", i);
    }
    ret = ret && (nodes[i].lock.reason_set_by != task_id);
    if (!ret) {
      printf("found lock on iter %d that worker %lu set the reason with %d\n", i,task_id, nodes[i].lock.reason);
    }
   // assert(!nodes[i].lock.i_own_lock(task_id));
   // assert(nodes[i].lock.reason_set_by != task_id);
  }
  return ret;
#endif
}  

template <typename E>
bool inline Block<E>::check_no_node_locks_held_by_me(uint64_t task_id) {
  #if ENABLE_PMA_LOCK != 1
      return true;
  #else
  bool ret = true;
  for (uint32_t i = 0; i < nodes_size; i++) {
    ret = ret && !nodes[i].lock.i_own_lock(task_id);
    if (!ret) {
      printf("found lock on iter %d\n", i);
    }
   // assert(!nodes[i].lock.i_own_lock(task_id));
  }
  return ret;
#endif
}  


uint_t inline next_leaf(uint_t index, int loglogN) {
  return ((index >> loglogN) + 1) << (loglogN);
}

template <typename E>
bool inline Block<E>::grab_all_locks(uint64_t task_id, bool exclusive, REASONS reason) {
  #if ENABLE_PMA_LOCK != 1
      return true;
  #else
  for (uint32_t i = 0; i < nodes_size; i++) {
    if (exclusive) {
      if (!nodes[i].lock.lock(task_id, reason)) {
        return false;
      }
    } else  {
      if (!nodes[i].lock.lock_shared(task_id)) {
        return false;
      }
    }
  }
  return true;
#endif
}

template <typename E>
void inline Block<E>::release_all_locks(uint64_t task_id, bool exclusive, REASONS reason) {
  #if ENABLE_PMA_LOCK != 1
      return;
  #else
  temp_pfor (uint32_t i = 0; i < nodes_size; i++) {
    if (exclusive) {
      nodes[i].lock.unlock(task_id, reason);
    } else  {
      nodes[i].lock.unlock_shared(task_id);
    }
  }
#endif
}

template <typename E>
void inline Block<E>::clear() {
  printf("clear called\n");
  uint_t n = 0;
  uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2);
  grab_all_locks(task_id, true, GENERAL);
  
  free((void*)edges.vals);
  free((void*)edges.dests);
  edges.N = 2UL << bsr_word(n);
  // printf("%d\n", bsf_word(list->N));
  edges.loglogN = bsr_word(bsr_word(edges.N) + 1);
  edges.logN = (1 << edges.loglogN);
  edges.H = bsr_word(edges.N / edges.logN);
}

// TODO jump to next leaf
template <typename E>
vector<tuple<uint32_t, uint32_t, uint32_t>> inline Block<E>::get_edges() {
  // TODO grab locks in the lock list
  // for now, grabs the global lock
#if ENABLE_PMA_LOCK == 1
  node_lock.lock_shared(); // lock node array
#endif
  // edges.list_lock.lock();
  uint64_t n = get_n();
  vector<tuple<uint32_t, uint32_t, uint32_t>> output;

  for (uint_t i = 0; i < n; i++) {
    uint_t start = nodes[i].beginning;
    uint_t end = nodes[i].end;
#if ENABLE_PMA_LOCK == 1
    nodes[i].lock.lock_shared();
#endif
    for (uint_t j = start + 1; j < end; j++) {
      if (edges.dests[j]!=NULL_VAL) {
        output.push_back(
            make_tuple(i, edges.dests[j], edges.vals[j]));
      }
    }
#if ENABLE_PMA_LOCK == 1
    nodes[i].lock.unlock_shared();
#endif
    }
  // edges.list_lock.unlock();
#if ENABLE_PMA_LOCK == 1
  node_lock.unlock_shared(); // lock node array
#endif
  return output;
}

template <typename E>
uint64_t inline Block<E>::get_n() {
#if ENABLE_PMA_LOCK == 1
  node_lock.lock_shared();
#endif
  uint64_t size = nodes_size;
#if ENABLE_PMA_LOCK == 1
  node_lock.unlock_shared();
#endif
  return size;
}

template <typename E>
uint64_t inline Block<E>::get_size() {
#if ENABLE_PMA_LOCK == 1
  node_lock.lock_shared();
#endif
  uint64_t size = nodes.capacity() * sizeof(BlockState<E>);
  size += sizeof(Block<E>);
  size += (uint64_t)edges.N * sizeof(edge_t);
#if ENABLE_PMA_LOCK == 1
  node_lock.unlock_shared();
#endif
  return size;
}

void inline print_array(edge_list_t *edges) {
  printf("N = %d, logN = %d\n", edges->N, edges->logN);
  for (uint_t i = 0; i < edges->N; i++) {
    if (edges->dests[i]==NULL_VAL) {
      printf("%d-x ", i);
    } else if ((edges->dests[i]==SENT_VAL) || i == 0) {
      uint32_t value = edges->vals[i];
      if (value == NULL_VAL) {
        value = 0;
      }
      printf("\n%d-s(%u):(?, ?) ", i, value);
    } else {
      printf("%d-(%d, %u) ", i, edges->dests[i], edges->vals[i]);
    }
  }
  printf("\n\n");
}

template <typename E>
void inline Block<E>::print_array(uint64_t worker_num) {
  printf("worker num: %lu, N = %d, logN = %d, density_limit = %f\n", worker_num, edges.N, edges.logN, edges.density_limit);
  for (uint_t i = 0; i < edges.N; i++) {
    if (edges.dests[i]==NULL_VAL) {
      printf("%d-x ", i);
    } else if ((edges.dests[i] == SENT_VAL) || i == 0) {
      uint32_t value = edges.vals[i];
      if (value == NULL_VAL) {
        value = 0;
      }
      printf("\n worker num: %lu, %d-s(%u):(%d, %d)(%d) ", worker_num, i, value, nodes[value].beginning,
             nodes[value].end, nodes[value].degree);
      #ifndef NDEBUG
      #if ENABLE_PMA_LOCK == 1
        printf("(%s, %d by %u)", nodes[value].lock.check_unlocked() ? "Unlocked": "Locked", nodes[value].lock.reason, nodes[value].lock.owner);
      #endif
      #else
        printf(")");
      #endif
    } else {
      printf("%d-(%d, %u) ", i, edges.dests[i], edges.vals[i]);
    }
  }
  printf("\n\n");
}


uint_t inline get_density_count(edge_list_t *list, uint_t index, uint_t len) {
 /* 
  uint32_t full = 0;
  uint32_t i = index;
  while (i < index + len) {
    if (!is_null(list->items[i].e)) {
      full++;
      i++;
    } else {
      i = next_leaf(i, list->logN);
    }
  }
  return full;
*/
  /*
  cilk::reducer< cilk::op_add<uint32_t> > full;
  temp_pfor (uint32_t i = index; i < index+len; i++) {
    if (!is_null(list->items[i].e)) {
      (*full)++;
    }
  }
  return full.get_value();
  */
  // fater without paralleliszation since it gets properly vectorized
  uint32_t * dests = (uint32_t *) list->dests;
  uint_t full = 0;
#ifdef  __AVX__
  if (len >= 8) {
    uint_t null_count = 0;
    for (uint_t i = index; i < index+len; i+=8) {
      //TODO if we keep things aligned this could be faster, but then we cant use realloc in double
      __m256i a = _mm256_loadu_si256((__m256i *)& dests[i]);
      __m256i b =  _mm256_set1_epi32(NULL_VAL);
      uint32_t add = __builtin_popcount(_mm256_movemask_ps((__m256)_mm256_cmpeq_epi32(a, b)));
      null_count += add;
    }
    full = len - null_count;
    return full;
  }
#endif
  for (uint_t i = index; i < index+len; i+=4) {
#ifdef __SSE2__
      __m128i a = _mm_load_si128((__m128i *)& dests[i]);
      __m128i b =  _mm_set1_epi32(NULL_VAL);
      uint32_t add = 4-__builtin_popcount(_mm_movemask_ps((__m128) _mm_cmpeq_epi32(a, b)));
#else
      uint32_t add = (dests[i]!=NULL_VAL) + (dests[i+1]!=NULL_VAL) + (dests[i+2]!=NULL_VAL) + (dests[i+3]!=NULL_VAL);
#endif
      //__sync_fetch_and_add(&full, add);
      full+=add;
  }
  return full;
  /*
  cilk::reducer< cilk::op_add<uint32_t> > full;
  temp_pfor (uint32_t i = index; i < index+len; i+=4) {
      uint32_t add = !is_null(list->items[i].e) + !is_null(list->items[i+1].e) + !is_null(list->items[i+2].e) + !is_null(list->items[i+3].e);
      (*full)+=add;
  }
  return full.get_value();
  */
  
}

uint64_t inline get_density_count_par(edge_list_t *list, uint_t index, uint_t len, std::vector<uint_t> &sub_counts) {
  std::vector<uint64_t> worker_counts(ParallelTools::getWorkers()*8);
  uint32_t volatile  * volatile dests = list->dests;
  temp_pfor(uint_t j = index; j < index+len; j+= REDISTRIBUTE_PAR_SIZE) {
    uint_t full = 0;
    for (uint_t i = j; i < j+REDISTRIBUTE_PAR_SIZE; i+=4) {
        uint32_t add = (dests[i]!=NULL_VAL) + (dests[i+1]!=NULL_VAL) + (dests[i+2]!=NULL_VAL) + (dests[i+3]!=NULL_VAL);
        full+=add;
    }
    worker_counts[ParallelTools::getWorkerNum()]+=full;
    sub_counts[(j-index)/REDISTRIBUTE_PAR_SIZE] = full;
  }

  uint64_t total = 0;  
  for (uint64_t i = 0; i < worker_counts.size(); i+=8) {
    total += worker_counts[i];
  }
  return total;  
}

// get density of a node
// should already be locked if you are calling get density
double inline get_density(edge_list_t *list, uint_t index, uint_t len) {
  double full_d = (double)get_density_count(list, index, len);
  return full_d / len;
}

bool inline check_no_full_leaves(edge_list_t *list, uint_t index, uint_t len) {
  for (uint_t i = index; i < index + len; i+= list->logN) {
    bool full = true;
    for (uint_t j = i; j < i + list->logN; j++) {
       if (list->dests[j]==NULL_VAL) {
        full = false;
      }
    }
    if (full) {
      return false;
    }
  }
  return true;
}

// height of this node in the tree
int inline get_depth(edge_list_t *list, uint_t len) { return bsr_word(list->N / len); }

// when adjusting the list size, make sure you're still in the
// density bound
pair_double inline density_bound(edge_list_t *list, int depth) {
  pair_double pair;

  // between 1/4 and 1/2
  // pair.x = 1.0/2.0 - (( .25*depth)/list->H);
  // between 1/8 and 1/4
  pair.x = 1.0 / 4.0 - ((.125 * depth) / list->H);
  pair.y = 3.0 / 4.0 + ((.25 * depth) / list->H);
  if (pair.y > list->density_limit) {
    pair.y = list->density_limit-.001;
  }
  return pair;
}

//TODO make it so the first element is known to always be the first element and don't special case it so much
//assumes the node_lock is held
//returns where me have to start checking for sentinals again
// ths is just the start + the degree so we can run some fasts paths
template <typename E>
uint_t inline Block<E>::fix_sentinel(uint32_t node_index, uint_t in) {
  // we know the first sentinal will never move so we just ignore it
 // assert(node_index > 0);
  //node_lock.lock_shared();
  nodes[node_index - 1].end = in;

  nodes[node_index].beginning = in;
  if (node_index == nodes_size - 1) {
    nodes[node_index].end = edges.N - 1;
  }
  //node_lock.unlock_shared();
  return nodes[node_index].beginning + nodes[node_index].degree;
}


// Evenly redistribute elements in the ofm, given a range to look into
// index: starting position in ofm structure
// len: area to redistribute
// should already be locked
template <typename E>
void inline Block<E>::redistribute(uint_t index, uint64_t len) {
  //printf("len = %u\n", len);
 // assert(find_leaf(&edges, index) == index);
  
  //printf("REDISTRIBUTE START: index:%u, len %u, worker %lu\n", index, len, get_worker_num());
  //print_array(get_worker_num());
  // std::vector<edge_t> space(len); //
  //TODO if its small use the stack
  // for small cases put on the stack
  uint32_t *space_vals;
  uint32_t *space_dests;
  uint32_t * vals = (uint32_t *) edges.vals;
  uint32_t  * dests = (uint32_t *) edges.dests;
  uint_t j = 0;
  if (len == edges.logN) {
    return;
  } else {
    space_vals = (uint32_t *)malloc(len * sizeof(*(edges.vals)));
    if (space_vals == 0) {

      printf("bad malloc, len = %lu\n", len);
      while (1){}
    }
    space_dests = (uint32_t *)malloc(len * sizeof(*(edges.dests)));
  }

  // move all items in ofm in the range into
  // a temp array
  /*
  int i = index;
  while (i < index + len) {
    if (!is_null(edges.items[i])) {
      space[j] = edges.items[i];
      edges.items[i].value = 0;
      edges.items[i].dest = 0;
      i++;
      j++;
    } else {
      i = next_leaf(i, edges.logN);
    }
  }
  */
  //TODO could parralize if get_density_count gave us more data, but doesn't seem to be a bottle neck
  // could get better cache behavior if I go back and forth with reading and writing
 // assert(len >= 8);
  // AVX code seems to have a bug, but I can't find it s leaving it in the iffalse
#ifdef false & __AVX__
  for (uint_t i = index; i < index + len; i+=8) {
    __m256i dests_vec = _mm256_loadu_si256((__m256i *)& dests[i]);
    __m256i vals_vec = _mm256_loadu_si256((__m256i *)& vals[i]);
    _mm256_storeu_si256((__m256i *) &space_dests[j], dests_vec);
    _mm256_storeu_si256((__m256i *) &space_vals[j], vals_vec);
    __m256i b =  _mm256_set1_epi32(NULL_VAL);
    j += 8-__builtin_popcount(_mm256_movemask_ps((__m256)_mm256_cmpeq_epi32(dests_vec, b)));
    _mm256_storeu_si256((__m256i *)& dests[i], b);
    _mm256_storeu_si256((__m256i *)& vals[i], _mm256_setzero_si256());
  }
#else
  for (uint_t i = index; i < index + len; i+=8) {
    for (uint_t k = i; k < i+8; k++) {
      space_vals[j] = vals[k];
      space_dests[j] = dests[k];
      // counting non-null edges
      j += (space_dests[j]!=NULL_VAL);
      // setting section to null
      //vals[i] = 0;
      //dests[i] = NULL_VAL;
    }
    memset (__builtin_assume_aligned((void*)&vals[i], 32), 0, 8*sizeof(uint32_t));
    //setting by byte, but NULL_VAL is all ones so it is fine
    memset (__builtin_assume_aligned((void*)&dests[i], 32), NULL_VAL, 8*sizeof(uint32_t));
  }
#endif
  
  /*
  if (((double)j)/len > ((double)(edges.logN-1)/edges.logN)) {
    printf("too dense in redistribute, j = %u, len = %u, index = %u for worker %lu\n",j, len, index, get_worker_num() );
    print_array(get_worker_num());
  }*/
 // assert( ((double)j)/len <= ((double)(edges.logN-1)/edges.logN));

  uint_t num_leaves = len >> edges.loglogN;
  uint_t count_per_leaf = j / num_leaves;
  uint_t extra = j % num_leaves;
  __builtin_prefetch ((void *)&nodes, 0, 3);

  // parallizing does not make it faster
  uint_t end_sentinel = 0;
  for (uint_t i = 0; i < num_leaves; i++) {
    uint_t count_for_leaf = count_per_leaf + (i < extra);
    uint_t in = index + (edges.logN * (i));
    uint_t j2 = count_per_leaf*i + min(i,extra);
    //TODO could be parallized, but normally only up to size 32
    uint_t j3 = j2;
    memcpy(__builtin_assume_aligned((void*)&vals[in],16), (void*)&space_vals[j2], count_for_leaf*sizeof(uint32_t));
    /*
    for (uint32_t k = in; k < count_for_leaf+in; k++) {
      vals[k] = space_vals[j2];
      j2++;
    }
    */
    if (end_sentinel > in + count_for_leaf) {
      memcpy(__builtin_assume_aligned((void*)&dests[in], 16), (void*)&space_dests[j2], count_for_leaf*sizeof(uint32_t));
    } else { 
      for (uint_t k = in; k < count_for_leaf+in; k++) {
        dests[k] = space_dests[j3];
        if (dests[k]==SENT_VAL) {
          // fixing pointer of node that goes to this sentinel
          uint32_t node_index = vals[k];
          end_sentinel = fix_sentinel(node_index, k);
        }
        j3++;
      }
  }

  }
  free(space_dests);
  free(space_vals);
  /*
  if (!check_no_full_leaves(&edges, index, len)) {
    printf("some leaves are full, current density is %f, index = %u, len = %u\n", get_density(&edges, index, len), index, len);
    print_array(get_worker_num());
  }*/
 // assert(check_no_full_leaves(&edges, index, len));
  //printf("REDISTRIBUTE END: index:%u, len %u, worker %lu\n", index, len, get_worker_num());
}

template <typename E>
void inline Block<E>::redistribute_par(uint_t index, uint64_t len, std::vector<uint_t> &sub_counts, uint_t num_elements, bool for_double) {
 // assert(find_leaf(&edges, index) == index);
  //printf("par len = %u\n", len);

  uint32_t *space_vals = (uint32_t *)aligned_alloc(64, len * sizeof(*(edges.vals)));
  uint32_t *space_dests = (uint32_t *)aligned_alloc(64, len * sizeof(*(edges.dests)));
  uint_t j = 0;

  // move all items in ofm in the range into
  // a temp array


  //TODO parallel prefix sum
  for (size_t i = 1; i < sub_counts.size(); i++) {
    sub_counts[i] += sub_counts[i-1];
    //printf("sub_counts[%d] = %u\n", i, sub_counts[i]);
  }

  // could get better cache behavior if I go back and forth with reading and writing
  uint32_t volatile  * volatile vals = edges.vals;
  uint32_t volatile  * volatile dests = edges.dests;
 /* 
  for (uint32_t i = index; i < index + len; i++) {
    j += (dests[i]!=NULL_VAL);
    printf("start = %u, i = %u\n", j, i);
  }
  */
  j = num_elements;
  uint_t end = index+len;
  if (for_double) {
    end = end/2;
  }
  temp_pfor(uint_t k = index; k < end; k+=REDISTRIBUTE_PAR_SIZE) {
    //printf("index = %u, len = %u, k = %u REDISTRIBUTE_PAR_SIZE = %u\n", index, len, k , REDISTRIBUTE_PAR_SIZE);
      uint_t start;
      if (k == index) {
        start = 0;
      } else {
        start = sub_counts[(k-index)/REDISTRIBUTE_PAR_SIZE-1];
      }

      for (uint_t i = k; i < k+REDISTRIBUTE_PAR_SIZE; i+=8) {
        //printf("start = %u, i = %u\n", start, i);
        for (uint_t j = i; j < i+8; j++) {
          if (dests[j] != NULL_VAL) {
            space_vals[start] = vals[j];
            space_dests[start] = dests[j];
            start += 1;
          }
          //TODO use avx below when possible
          vals[i] = 0;
          dests[i] = NULL_VAL;
        }
        // setting section to null
        //_mm256_storeu_si256((__m256i *) (&edges.vals[i]), _mm256_setzero_si256());
        //_mm256_storeu_si256((__m256i *) (&edges.dests[i]), _mm256_set_epi32(NULL_VAL, NULL_VAL, NULL_VAL, NULL_VAL, NULL_VAL, NULL_VAL, NULL_VAL, NULL_VAL));  
    }

  }
/*  
  j = 0;
  for(uint32_t k = index; k < index+len; k+=REDISTRIBUTE_PAR_SIZE) {
    for (uint32_t i = k; i < k + REDISTRIBUTE_PAR_SIZE; i++) {
      space_vals[j] = vals[i];
      space_dests[j] = dests[i];
      // counting non-null edges
      j += (space_dests[j]!=NULL_VAL);
      // setting section to null
      vals[i] = 0;
      dests[i] = NULL_VAL;
    }
  }
*/
 // assert( ((double)j)/len <= ((double)(edges.logN-1)/edges.logN));

  uint_t num_leaves = len >> edges.loglogN;
  uint_t count_per_leaf = j / num_leaves;
  uint_t extra = j % num_leaves;
  __builtin_prefetch ((void *)&nodes, 0, 3);
  // parallizing does not make it faster
  temp_pfor (uint_t i = 0; i < num_leaves; i++) {
    uint_t count_for_leaf = count_per_leaf + (i < extra);
    uint_t in = index + ((i) << edges.loglogN);
    uint_t j2 = count_per_leaf*i + min(i,extra);
    //TODO could be parallized, but normally only up to size 32
    uint_t j3 = j2;
   // assert(j3 < len);
    
    for (uint_t k = in; k < count_for_leaf+in; k++) {
      vals[k] = space_vals[j2];
      j2++;
    }
    for (uint_t k = in; k < count_for_leaf+in; k++) {
      dests[k] = space_dests[j3];
      if (dests[k]==SENT_VAL) {
        // fixing pointer of node that goes to this sentinel
        uint32_t node_index = vals[k];
         
        fix_sentinel(node_index, k);
      }
      j3++;
     // assert(j3 < len);
    }

  }
  free(space_dests);
  free(space_vals);

 // assert(check_no_full_leaves(&edges, index, len));
}


//TODO pass in subcounts and do redistibute_par when big
template <typename E>
void inline Block<E>::double_list(uint64_t task_id, std::vector<uint_t> &sub_counts, uint_t num_elements) {
  //printf("doubling list by worker %lu\n", get_worker_num());
  grab_all_locks(task_id, true, DOUBLE);
  uint64_t new_N = edges.N * 2;
  edges.loglogN = bsr_word(bsr_word(edges.N) + 1);
  edges.logN = (1 << edges.loglogN);
  edges.mask_for_leaf = ~(edges.logN - 1);
 // assert(edges.logN > 0);
  edges.density_limit = ((double) edges.logN - 1)/edges.logN;
  edges.H = bsr_word(new_N / edges.logN);
  for (uint32_t i = 0; i <= edges.H; i++) {
    upper_density_bound[i] = density_bound(&edges, i).y;
    lower_density_bound[i] = density_bound(&edges, i).x;
  }

  edges.N = new_N;


  /* 
  uint32_t *new_dests = (uint32_t *)malloc(new_N * sizeof(*(edges.dests)));
  uint32_t *new_vals = (uint32_t *)malloc(new_N * sizeof(*(edges.vals)));
  temp_pfor (uint32_t i = 0; i < edges.N / 2; i++) {
    new_vals[i] = vals[i]; // setting second half to null
    new_dests[i] = dests[i]; // setting second half to null
  }
  edges.dests = new_dests;
  edges.vals = new_vals;
  vals = edges.vals;
  dests = edges.dests;
  */
  //edges.dests = (uint32_t *)realloc((void*)edges.dests, new_N * sizeof(*(edges.dests)));
  //edges.vals = (uint32_t *)realloc((void*)edges.vals, new_N * sizeof(*(edges.vals)));
  uint32_t *new_dests = (uint32_t *)aligned_alloc(32, new_N * sizeof(*(edges.dests)));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(32, new_N * sizeof(*(edges.vals)));
  uint32_t * vals = (uint32_t *)edges.vals;
  uint32_t * dests = (uint32_t *)edges.dests;
  temp_pfor (uint_t i = 0; i < new_N / 2; i++) {
    new_vals[i] = vals[i];
    new_dests[i] = dests[i];
  }
  temp_pfor (uint_t i = new_N / 2; i < new_N; i++) {
    new_vals[i] = 0; // setting second half to null
    new_dests[i] = NULL_VAL; // setting second half to null
  }
  free((void*)edges.vals);
  edges.vals = new_vals;
  free((void*)edges.dests);
  edges.dests = new_dests;

 // assert(edges.dests != NULL && edges.vals != NULL);
  //memset((void*)(edges.items+(new_N / 2)), 0, sizeof(edge_t) * (new_N / 2) );
  
  
  //printf("List doubled: N - %u, logN = %u, H = %u\n", edges.N, edges.logN, edges.H);
  if (sub_counts.size() == 0) {
    redistribute(0, edges.N);
  } else {
    redistribute_par(0, edges.N, sub_counts, num_elements, true);
  }
  release_all_locks(task_id, true, GENERAL);

}

template <typename E>
void inline Block<E>::half_list(uint64_t task_id, std::vector<uint_t> &sub_counts, uint_t num_elements) {
  //printf("doubling list by worker %lu\n", get_worker_num());
  grab_all_locks(task_id, true, DOUBLE);
  uint64_t new_N = edges.N / 2;
  edges.loglogN = bsr_word(bsr_word(edges.N) - 1);
  edges.logN = (1 << edges.loglogN);
  edges.mask_for_leaf = ~(edges.logN - 1);
 // assert(edges.logN > 0);
  edges.density_limit = ((double) edges.logN - 1)/edges.logN;
  edges.H = bsr_word(new_N / edges.logN);
  for (uint32_t i = 0; i <= edges.H; i++) {
    upper_density_bound[i] = density_bound(&edges, i).y;
    lower_density_bound[i] = density_bound(&edges, i).x;
  }

  //uint32_t *new_dests = (uint32_t *)malloc(new_N * sizeof(*(edges.dests)));
  //uint32_t *new_vals = (uint32_t *)malloc(new_N * sizeof(*(edges.vals)));
  uint32_t *new_dests = (uint32_t *)aligned_alloc(32, new_N * sizeof(*(edges.dests)));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(32, new_N * sizeof(*(edges.vals)));
	//memset(new_dests, 0, new_N * sizeof(*(edges.dests)));
	//memset(new_vals, 0, new_N * sizeof(*(edges.vals)));
  uint32_t * vals = (uint32_t *)edges.vals;
  uint32_t * dests = (uint32_t *)edges.dests;

 // assert(edges.dests != NULL && edges.vals != NULL);
  
  
  //printf("List doubled: N - %u, logN = %u, H = %u\n", edges.N, edges.logN, edges.H);
  if (sub_counts.size() == 0) {
    uint_t start = 0;
    for (uint_t i = 0; i < edges.N; i++) {
      if (dests[i] != NULL_VAL) {
        new_vals[start] = vals[i];
        new_dests[start] = dests[i];
        start += 1;
      }
    }
		for (uint_t i = start; i < new_N; i++) {
			new_vals[i] = 0; new_dests[i] = NULL_VAL;
		}
    free(vals);
    free(dests);
    edges.vals = new_vals;
    edges.dests = new_dests;
    edges.N = new_N;
    redistribute(0, new_N);
  } else {
    temp_pfor(size_t k = 0; k < sub_counts.size(); k+=1) {
      //printf("index = %u, len = %u, k = %u REDISTRIBUTE_PAR_SIZE = %u\n", index, len, k , REDISTRIBUTE_PAR_SIZE);
      uint_t start;
      if (k == 0) {
        start = 0;
      } else {
        start = sub_counts[k-1];
      }

      for (uint_t i = REDISTRIBUTE_PAR_SIZE*k; i < REDISTRIBUTE_PAR_SIZE*(k+1); i+=8) {
        //printf("start = %u, i = %u\n", start, i);
        for (uint_t j = i; j < i+8; j++) {
          if (dests[j] != NULL_VAL) {
            new_vals[start] = vals[j];
            new_dests[start] = dests[j];
            start += 1;
          }
        }
      }
    }
		for (uint_t i = sub_counts[sub_counts.size()-1]; i < new_N; i++) {
			new_vals[i] = 0; new_dests[i] = NULL_VAL;
		}
    free(vals);
    free(dests);
    edges.vals = new_vals;
    edges.dests = new_dests;
    edges.N = new_N;
    redistribute(0, new_N);
  }
  release_all_locks(task_id, true, GENERAL);
}


// index is the beginning of the sequence that you want to slide right.
// we wil always hold locks to the end of the leaf so we don't need to lock here
template <typename E>
void inline Block<E>::slide_right(uint_t index, uint32_t *vals, uint32_t *dests) {
  // edges.list_lock.lock_shared();
  uint32_t el_val = vals[index];
  uint32_t el_dest = dests[index];
  dests[index] = NULL_VAL;
  vals[index] = 0;
  // uint32_t original_index = index;
  //printf("start of slide right, original_index: %d, worker number: %lu, \n", original_index, get_worker_num());
  // edges.lock_array[current_lock].print();
  index++;
  // uint32_t leaf = find_leaf(&edges, index);
	//uint32_t cnt{0};
  while (index < edges.N && (dests[index]!=NULL_VAL)) {
    //// assert(find_leaf(&edges, index) == leaf);
    uint32_t temp_val = vals[index];
    uint32_t temp_dest = dests[index];
    vals[index] = el_val;
    dests[index] = el_dest;
    if (el_dest == SENT_VAL) {
      // fixing pointer of node that goes to this sentinel
      uint32_t node_index = el_val;
      fix_sentinel(node_index, index);
    }
    el_val = temp_val;
    el_dest = temp_dest;
    index++;
		//cnt++;
  }
	//std::cout << "right: " << cnt << '\n';
  if (el_dest == SENT_VAL) {
    // fixing pointer of node that goes to this sentinel
    uint32_t node_index = el_val;
    fix_sentinel(node_index, index);
  }
  //printf("middle of slide right, original_index: %d, worker number: %lu, current lock = %d\n", original_index, get_worker_num(), current_lock);

  // TODO There might be an issue with this going of the end sometimes
 // assert(index != edges.N);

  vals[index] = el_val;
  dests[index] = el_dest;
  //// assert(find_leaf(&edges, index) == leaf);
  //// assert(check_no_full_leaves(&edges, original_index, edges.logN));
}


// index is the beginning of the sequence that you want to slide left.
// the element we start at will be deleted
// we wil always hold locks to the end of the leaf so we don't need to lock here
template <typename E>
void inline Block<E>::slide_left(uint_t index, uint32_t *vals, uint32_t *dests) {
  // edges.list_lock.lock_shared();
  // uint32_t original_index = index;
  //printf("start of slide right, original_index: %d, worker number: %lu, \n", original_index, get_worker_num());
  // edges.lock_array[current_lock].print();
  // uint32_t leaf = find_leaf(&edges, index);
	//uint32_t cnt{0};
  while (index+1 < edges.N) {
		//cnt++;
    //// assert(find_leaf(&edges, index) == leaf);
    uint32_t temp_val = vals[index+1];
    uint32_t temp_dest = dests[index+1];
    vals[index] = temp_val;
    dests[index] = temp_dest;
    if (temp_dest == SENT_VAL) {
      // fixing pointer of node that goes to this sentinel
      uint32_t node_index = temp_val;
      fix_sentinel(node_index, index);
    }
    if (dests[index] == NULL_VAL) {
      break;
    }
    index++;
  }
	// std::cout << "left: " << cnt << '\n';

 // assert(index != edges.N);

  //// assert(find_leaf(&edges, index) == leaf);
  //// assert(check_no_full_leaves(&edges, original_index, edges.logN));
}

// important: make sure start, end don't include sentinels
// returns the index of the smallest element bigger than you in the range
// [start, end)
// if no such element is found, returns end (because insert shifts everything to
// the right)
// assumes we already hold the list_lock and the relevant lock_array locks
uint_t inline binary_search(const edge_list_t *list, uint32_t elem_dest, uint32_t elem_val, uint_t start,
                       uint_t end) {
 // assert(start <= end);
  uint32_t *dests = (uint32_t *) list->dests;

  uint_t mid = (start + end) / 2;
  // print_array(list);
  while (start + 1 < end) {
    
    __builtin_prefetch ((void *)&dests[(mid+end)/2], 0, 3);
    __builtin_prefetch ((void *)&dests[(start + mid)/2], 0, 3);
    // printf("start = %d, end = %d, dest = %d, mid = %d, val =%u\n", start, end, elem_dest, mid, elem_val);
    /*
    if (mid % list->logN > list->logN / 2) {
      // if beginning of next leaf is before end of binary search
      uint32_t temp = next_leaf(mid, list->loglogN);
      if(temp < end) {
        mid = temp;
      }
    }
    */
    uint32_t item_dest = dests[mid];

    //if is_null
    if (item_dest==NULL_VAL) {
      // first check the next leaf
      uint_t check = next_leaf(mid, list->loglogN);
      //TODO deal with check is null
      if (check > end) {
        end = mid;
        mid = (start + end) / 2;
        __builtin_prefetch ((void *)&dests[mid], 0, 3);
        continue;
      }
      // if is_null
      if (dests[check]==NULL_VAL) {
        uint_t early_check = find_prev_valid(dests, mid);
        // if we found the sentinel, go right after it
        if (dests[early_check] == SENT_VAL) {
          return early_check + 1;
        }
        if (early_check < start) {
          start = mid;
          mid = (start + end) / 2;
          __builtin_prefetch ((void *)&dests[mid], 0, 3);
          continue;
        }  
        check = early_check;
      } 
      // printf("check = %d\n", check);
      uint32_t dest = dests[check];
      if (elem_dest == dest) {
        // cleanup before return
        return check;
      } else if (elem_dest < dest) {
        end = find_prev_valid(dests, mid) + 1;

      } else {
        if (check == start) {
          start = check + 1;
        } else {
          start = check;
        }
        // otherwise, searched for item is more than current and we set start
      }
      mid = (start + end) / 2;
      __builtin_prefetch ((void *)&dests[mid], 0, 3);
      continue;
    }

    if (elem_dest < item_dest) {
      end = mid; // if the searched for item is less than current item, set end
      mid = (start + end) / 2;
    } else if (elem_dest > item_dest) {
      start = mid;
      mid = (start + end) / 2;
      // otherwise, sesarched for item is more than current and we set start
    } else if (elem_dest == item_dest) {  // if we found it, return
      // cleanup before return
      return mid;
    }
  }
  if (end < start) {
    start = end;
  }
 // assert(start >= 0);
  //tbassert(end < list->N, "end: %u, list->N: %u\n", end, list->N);

  //trying to encourage the packed left property so if they are both null go to the left
  if ((dests[start]==NULL_VAL) && (dests[end]==NULL_VAL)) {
    end = start;
  }

  // handling the case where there is one element left
  // if you are leq, return start (index where elt is)
  // otherwise, return end (no element greater than you in the range)
  // printf("start = %d, end = %d, n = %d\n", start,end, list->N);
  if (elem_dest <= dests[start] && (dests[start]!=NULL_VAL)) {
    end = start;
  }
  // cleanup before return

  return end;
}

template <typename E>
uint32_t inline Block<E>::find_value(uint32_t src, uint32_t dest) {

#if ENABLE_PMA_LOCK == 1
  uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2);
  node_lock.lock_shared(task_id);
#endif
  uint32_t e_value = 0;
  uint32_t e_dest = dest;
  //printf("src: %d, dest: %d\n", src, dest);
  //printf("beginning: %d, end:%d\n", nodes[src].beginning+1, nodes[src].end);

#if ENABLE_PMA_LOCK == 1
  //the lock has been deleted
  // not sure why this has to be exclusive
  if (!nodes[src].lock.lock(task_id, GENERAL)) {
    node_lock.unlock_shared(task_id);
    return find_value(src,dest);
  }
#endif
  uint_t loc =
      binary_search(&edges, e_dest, e_value, nodes[src].beginning + 1, nodes[src].end);
  //printf("loc = %d, looking for %u, %u, found %u, %u\n",loc, src, dest, edges.dests[loc], edges.vals[loc]);
  e_dest = edges.dests[loc];
  e_value = edges.vals[loc];
#if ENABLE_PMA_LOCK == 1
  nodes[src].lock.unlock(task_id, GENERAL);
  // edges.list_lock.unlock_shared();
  node_lock.unlock_shared(task_id);
#endif
  // print_array();
  // printf("loc: %d\n", loc);
  //TODO probably don't need the first check since we will never look for null
  if ((e_dest != NULL_VAL) && e_dest == dest) {
    return e_value;
  } else {
    return 0;
  }
}

//assumes node_lock is held
template <typename E>
uint32_t inline Block<E>::find_contaning_node(uint_t index) {
  uint32_t start = 0; 
  uint32_t end = nodes_size-1;
  while (end - start > 1) {
    uint32_t middle = (end + start) / 2;
    uint_t node_start = nodes[middle].beginning;
    uint_t node_end = nodes[middle].end;
    if ( index >= node_start && index < node_end){
      return middle;
    } else if (index < node_start) {
      end = middle;
    } else if (index >= node_end) {
      start = middle;
    } else {
      printf("should not happen\n");
     // assert(false);
    }
  }
  if ( index >= nodes[start].beginning && index < nodes[start].end){
    return start;
  } else if ( index >= nodes[end].beginning && index < nodes[end].end) {
    return end;
  } else if (index >= nodes[nodes_size - 1].end) {
      return nodes_size - 1;
  } else {
    //printf("no containing node trying again\n");
    return find_contaning_node(index);
  }
}

template <typename E>
pair_int inline Block<E>::which_locks_in_range(uint_t index, uint_t len, uint32_t guess) {
  uint32_t start;
which_locks_in_range_start:

  if (index >= nodes[guess].beginning && index < nodes[guess].end) {
      start = guess;
  } else {
    bool found = false;
    uint64_t range = 50;
    uint64_t st = (guess > range) ? guess - range : 0;
    uint64_t end = (guess + range < nodes_size) ? guess + range : nodes_size - 1;
    if (index >= nodes[st].beginning && index < nodes[end].end) {
      for (uint64_t est = st; est < end; est++) {
        if (index >= nodes[est].beginning && index < nodes[est].end) {
          start = est;
          found = true;
          break;
        }
      }
    }
    if (!found) {
      start = find_contaning_node(index);
    }
  }
  if (index < nodes[start].beginning) {
    if (start > 0) {
      start--;
    }
  }
  uint64_t end_index = index + len - 1;
  if (index + len > find_leaf(&edges, index + len)) {
    end_index = next_leaf(index + len, edges.loglogN) - 1;
  }
  // printf("end_index = %lu\n", end_index);
  uint32_t end;
  if (end_index < nodes[start].end) {
    end = start;
  } else {
    bool found = false;
    if (len <= 512) {
      uint64_t range = 200;
      uint64_t end_range = (start + range < nodes_size) ? start + range : nodes_size - 1;
      for (uint64_t est = start; est < end_range; est++) {
        if (end_index >= nodes[est].beginning && end_index < nodes[est].end) {
          end = est;
          found = true;
          break;
        }
      }
    }
    if (!found) {
      end = find_contaning_node(end_index);
    }
  }
  //printf("grabbing locks %d through %d, by %lu with reason %d\n", start, end, get_worker_num(), reason)
  if (end < start) {
    goto which_locks_in_range_start;
  }
  return {start, end};
}

template <typename E>
pair_int inline Block<E>::grab_locks_in_range_with_resets(uint64_t task_id, uint_t index, uint_t len, REASONS reason, uint32_t guess) {
  uint_t orig_n = edges.N;
#if ENABLE_PMA_LOCK == 1
  start_grab_locks_in_range_with_resets:
#endif
  if (orig_n != edges.N) {
    return {0xFFFFFFFF,0};
  }
  pair_int ends = which_locks_in_range(index, len, guess);
#if ENABLE_PMA_LOCK == 1
  //printf("grabbing locks %d through %d, by %lu with reason %d\n", ends.x, ends.y, get_worker_num(), reason);
  for (uint32_t i = ends.x; i <= ends.y; i++) {
    if (!nodes[i].lock.try_lock(task_id, reason)) {
      if ( i > 0) {
        release_locks_in_range(task_id, {ends.x, i - 1}, SAME);
      }
      //usleep(1);
      //return grab_locks_in_range_with_resets(task_id, index, len, reason);
      goto start_grab_locks_in_range_with_resets;
    }
  }
  //printf("grabed locks %d through %d, by %lu with reason %d\n", ends.x, ends.y, get_worker_num(), reason);
  // make sure nothing changed before we managed to grab the locks
  if (!((nodes[ends.x].beginning <= index) && ((index+len <= nodes[ends.y].end) || (ends.y == nodes_size -1)))) {
    release_locks_in_range(task_id, ends, SAME);
    goto start_grab_locks_in_range_with_resets;
  }
#endif
  return ends;
}

template <typename E>
void inline Block<E>::release_locks_in_range(uint64_t task_id, pair_int locks, REASONS reason) {
#if ENABLE_PMA_LOCK == 1
uint32_t start = locks.x;
  uint32_t end = locks.y;
  //printf("releasing locks %d through %d, by worker %lu with reason %d\n", start, end, get_worker_num(), reason);
  for (uint32_t i = start; i <= end; i++) {
    nodes[i].lock.unlock(task_id, reason);
  }
#endif
}

template <typename E>
pair_int inline Block<E>::which_locks_for_leaf(uint32_t src) {
  uint_t start_index = find_leaf(&edges, nodes[src].beginning);
  uint_t end_index = next_leaf(nodes[src].end, edges.loglogN);
  uint32_t first_node = src;
  while (nodes[first_node].beginning > start_index) {
    first_node--;
  }
  uint32_t last_node = src;
  while (nodes[last_node].end < end_index && last_node < nodes_size -1) {
    last_node++;
  }
  return {first_node, last_node};
}

template <typename E>
pair_int inline Block<E>::grab_locks_for_leaf_with_resets(uint64_t task_id, uint32_t src, REASONS reason) {
#if ENABLE_PMA_LOCK == 1
start_grab_locks_for_leaf_with_resets:
#endif
  pair_int ends = which_locks_for_leaf(src);
#if ENABLE_PMA_LOCK == 1
  //printf("grabbing locks %d through %d, by %lu with reason %d\n", ends.x, ends.y, get_worker_num(), reason);
  for (uint32_t i = ends.x; i <= ends.y; i++) {
    if (!nodes[i].lock.try_lock(task_id, reason)) {
      if ( i > 0) {
        release_locks_in_range(task_id, {ends.x, i - 1}, SAME);
      }
      usleep(1);
     //sched_yield();
      goto start_grab_locks_for_leaf_with_resets;
    }
  }
  //printf("grabed locks %d through %d, by %lu with reason %d\n", ends.x, ends.y, get_worker_num(), reason);
  pair_int ends_check = which_locks_for_leaf(src);
  if (ends.x != ends_check.x || ends.y != ends_check.y) {
    release_locks_in_range(task_id, ends);
    goto start_grab_locks_for_leaf_with_resets;
  }
#endif
  return ends;
}

template <typename E>
bool inline Block<E>::check_every_lock_in_leaf(uint64_t task_id, uint_t index) {
  uint_t start = find_leaf(&edges, index);
  uint_t end = next_leaf(index, edges.loglogN);
  for (uint_t i = start; i < end; i++) {
#if ENABLE_PMA_LOCK == 1
    uint32_t node = find_contaning_node(i);
   // assert(nodes[node].lock.i_own_lock(task_id));
    if (!nodes[node].lock.i_own_lock(task_id)) {
      return false;
    }
#endif
  }
  return true;
}

template <typename E>
bool inline Block<E>::check_every_lock_in_node(uint64_t task_id, uint_t index, uint_t len) {
#if ENABLE_PMA_LOCK == 1
  uint_t start = find_leaf(&edges, index);
  for (uint_t i = start; i < start + len; i++) {
    uint32_t node = find_contaning_node(i);
    if (!nodes[node].lock.i_own_lock(task_id)) {
      return false;
    }
   // assert(nodes[node].lock.i_own_lock(task_id));
  }
#endif
  return true;
}


// insert elem at index
// assumes the lock on index is held by the parent
// and releases it when it is done with it
template <typename E>
void inline Block<E>::insert(uint64_t task_id, uint_t index, uint32_t elem_dest, uint32_t elem_val, uint32_t src
  #if ENABLE_PMA_LOCK == 1
  , pair_int held_locks
  #endif
  ) {
  #if ENABLE_PMA_LOCK == 1
 // assert(check_every_lock_in_leaf(task_id, index));
  #endif
 // assert(check_no_full_leaves(&edges, find_leaf(&edges, index), edges.logN));
  
  /*
  if (index > 0 && edges.dests[index - 1] == NULL_VAL && find_leaf(&edges, index) != index) {
    printf("insert conditional || index = %d src = %u elem dest = %u, elem value = %u, next leaf: %d\n", index, src, elem_dest, elem_val, next_leaf(index, edges.loglogN));
    print_array(get_worker_num());
  }*/


  //printf("index = %d src = %u elem dest = %u, elem value = %u, worker %lu\n", index, src, elem.dest, elem.value, get_worker_num());
  //print_array(get_worker_num());
  uint_t orig_n = edges.N;
  
  if ((elem_dest != SENT_VAL) && (elem_val != 0)) {
    // -1 for the case that the location is the spot of the next sentinal
    //assert(src == find_contaning_node(index-1));
  }
  // edges.list_lock.lock_shared();
  #if ENABLE_PMA_LOCK == 1
 // assert(nodes[src].lock.i_own_lock(task_id));
  #endif
  int level = edges.H;
  uint_t len = edges.logN;

  uint32_t * vals = (uint32_t *) edges.vals;
  uint32_t * dests = (uint32_t *) edges.dests;
  // always deposit on the left
  if (dests[index]==NULL_VAL) {
    // printf("added to empty\n");
    vals[index] = elem_val;
    dests[index] = elem_dest;
    #if ENABLE_PMA_LOCK == 1
   // assert(check_every_lock_in_leaf(task_id, index));
    #endif

  } else {
   // assert(index < edges.N - 1);
    // if the edge already exists in the graph, update its value
    // do not make another edge
    if ((elem_dest != SENT_VAL) && dests[index] == elem_dest) {
      vals[index] = elem_val;
      #if ENABLE_PMA_LOCK == 1
     // assert(check_every_lock_in_leaf(task_id, index));
      #endif
      // edges.list_lock.unlock_shared();
     // assert(check_no_full_leaves(&edges, find_leaf(&edges, index), edges.logN));
      #if ENABLE_PMA_LOCK == 1
      release_locks_in_range(task_id, held_locks);
     // assert(check_no_node_locks_for_me(task_id));
      #endif
      return;
    } else {
      // slide right assumes we hold the lock till the end of the leaf
      #if ENABLE_PMA_LOCK == 1
     // assert(check_every_lock_in_leaf(task_id, index));
      #endif
      slide_right(index, vals, dests);
      // printf("after sliding, index = %d\n", index);
      // print_array();
      vals[index] = elem_val;
      dests[index] = elem_dest;
      #if ENABLE_PMA_LOCK == 1
     // assert(check_every_lock_in_leaf(task_id, index));
      #endif
      // print_array();
    }
  }
  
  //assert(vals[index]!=0);
  //print_array();
  uint_t node_index = find_leaf(&edges, index);
  double density = get_density(&edges, node_index, len);
  //printf("density = %f, %d\n", density, density == 1);

  // spill over into next level up, node is completely full.
  if (density == 1) {
    //printf("first rebalence\n");
    //TODO continue work here
    len*=2;
    level--;
    node_index = find_node(node_index, len);
  } else {
    redistribute(node_index, len);
  }
 // assert(edges.N == orig_n);
  #if ENABLE_PMA_LOCK == 1
 // assert(check_every_lock_in_leaf(task_id, index));
  // being fancy here since some of the locks are done with and others might be used for the rebalence
  pair_int locks_for_rebalance = which_locks_in_range(node_index, len, src);
  //printf("relasing locks %d through %d with reason %d\n", locks_for_leaf.x, locks_for_rebalance.x -1, GENERAL);
  //printf("before with worker %lu\n", get_worker_num());
  //printf("worker %lu unlocking %d through %d with GENERAL \n", get_worker_num(), locks_for_leaf.x, locks_for_rebalance.x);
  temp_pfor (uint32_t i = held_locks.x; i < locks_for_rebalance.x; i++) {
    nodes[i].lock.unlock(task_id);
  }
  //printf("worker %lu relasing locks %d through %d with reason REBALANCE\n",get_worker_num(), max(locks_for_rebalance.x, locks_for_leaf.x), locks_for_leaf.y);
  for (uint32_t i = max(locks_for_rebalance.x, held_locks.x) ; i <= min(held_locks.y, locks_for_rebalance.y); i++) {
    nodes[i].lock.unlock(task_id, REBALANCE);
  }
  //printf("worker %lu unlocking %d through %d with GENERAL \n", get_worker_num(), locks_for_rebalance.y +1,locks_for_leaf.y);

  for (uint32_t i = locks_for_rebalance.y +1; i <= held_locks.y; i++) {
    nodes[i].lock.unlock(task_id);
  }

  //printf("unlocking %d by worker %lu\n",src, get_worker_num());
  //printf("grabbing %d, %d\n", node_index, len);
  //printf("about to grab\n");
  pair_int lock_span = {max(locks_for_rebalance.x, held_locks.x),  max(locks_for_rebalance.y, held_locks.y)};
 // assert(check_no_node_locks_held_by_me(task_id));


  held_locks = grab_locks_in_range_with_resets(task_id, node_index, len, REBALANCE, src);
  lock_span.x = min(held_locks.x, lock_span.x);
  lock_span.y = max(held_locks.y, lock_span.y);
  #endif
  // if somebody doubled and we let them with a reset
  if (edges.N != orig_n) {
    #if ENABLE_PMA_LOCK == 1
    //printf("worker %lu: somebody else doubled on us so we assume it has been distributed properly 1\n", get_worker_num());
    //printf("worker %lu: edges.N = %u, orig_n = %u\n",get_worker_num(), edges.N, orig_n);

    release_locks_in_range(task_id, held_locks, GENERAL);
    for (uint32_t i = lock_span.x; i <= lock_span.y; i++) {
      if (i < held_locks.x || i > held_locks.y) {
        nodes[i].lock.lock(task_id, REBALANCE);
        nodes[i].lock.unlock(task_id);
      }
    }
   // assert(check_no_node_locks_for_me(task_id));
    #endif
    return;
  }
  // printf("node_index3 = %d\n", node_index);
  // print_array();

  // get density of the leaf you are in
  double density_b = upper_density_bound[level];
  uint_t density_count = get_density_count(&edges, node_index, len);
  density = ((double)density_count)/len;
  // printf("density %f, upperbound %f, len = %d, N = %d, logN = %d\n", density,
  // density_b.y, len, list->N, list->logN);

  // while density too high, go up the implicit tree
  // go up to the biggest node above the density bound
  //printf("node_index = %d, desnsity = %f, density bound = %f\n", node_index, density, density_b.y);
  std::vector<uint_t> sub_counts(0);
  // while (density >= density_b) {
  while(density >= density_b) {
  // density >= (((double) edges.logN - 1) / edges.logN)) {

    //printf("node_index = %d, desnsity = %f, density bound = %f, len = %d, worker = %lu\n", node_index, density, density_b.y, len, get_worker_num());
    len *= 2;
    if (len <= edges.N) {
      level--;
      uint_t new_node_index = find_node(node_index, len);
      #if ENABLE_PMA_LOCK == 1
      release_locks_in_range(task_id, held_locks, REBALANCE);

      held_locks = grab_locks_in_range_with_resets(task_id, new_node_index, len, REBALANCE, src);
      if (held_locks.x < lock_span.x) {
        lock_span.x = held_locks.x;
      }
      if (held_locks.y > lock_span.y) {
        lock_span.y = held_locks.y;
      }
      #endif
      if (edges.N != orig_n) {
        //printf("worker %lu: somebody else doubled on us so we assume it has been distributed properly 2\n", get_worker_num());
        //printf("worker %lu: edges.N = %u, orig_n = %u\n",get_worker_num(), edges.N, orig_n);
        #if ENABLE_PMA_LOCK == 1
        release_locks_in_range(task_id, held_locks, GENERAL);
        for (uint32_t i = lock_span.x; i <= lock_span.y; i++) {
          if (i < held_locks.x || i > held_locks.y) {
            nodes[i].lock.lock(task_id, REBALANCE);
            nodes[i].lock.unlock(task_id);
          }
        }
       // assert(check_no_node_locks_for_me(task_id));
        #endif
        return;
      }
      if (len <= REDISTRIBUTE_PAR_SIZE) {
        density_count = get_density_count(&edges, new_node_index, len);
      } else {
        sub_counts.resize(len/REDISTRIBUTE_PAR_SIZE);
        density_count = get_density_count_par(&edges, new_node_index, len, sub_counts);
      }
      // to help prevent double doubling by knowing how big it was on the last count
      orig_n = edges.N;
      node_index = new_node_index;
      density_b = upper_density_bound[level];
      density = ((double) density_count )/len;
    } else {
      // if you reach the root, double the list
      #if ENABLE_PMA_LOCK == 1
      release_locks_in_range(task_id, held_locks, DOUBLE);
      //if (edges.N == orig_n) {
        // for (int i = 0; i < lock_count; i++) {
        //  edges.list_lock.unlock_shared();
        //}
        //TODO don't double double
        //printf("second double due to worker %lu\n", get_worker_num());
        //print_array(get_worker_num());
       // assert(check_no_node_locks_held_by_me(task_id));
        #endif
        double_list(task_id, sub_counts, density_count);
        // -1 for the lock at the begining of the function
        // we want to leave with the same number as we entered with
        //for (int i = 0; i < lock_count-1; i++) {
        //  edges.list_lock.lock_shared();
        //}
     // }
        #if ENABLE_PMA_LOCK == 1
       // assert(check_no_node_locks_for_me(task_id));
        #endif
      return;
    }
    // printf("density %f, upperbound %f, len = %d, N = %d, logN = %d\n",
    // density, density_b.y, len, list->N, list->logN);
  }
 // assert(((double)get_density_count(&edges, node_index, len))/ len == density);
 // assert(density < density_b);
 // assert(density <= (((double) edges.logN - 1) / edges.logN));
  //print_array(get_worker_num());
  if(len > edges.logN) {
     if (len <= REDISTRIBUTE_PAR_SIZE) {
      redistribute(node_index, len);
     } else {
      redistribute_par(node_index, len, sub_counts, density_count);
     }
    
  }
  //printf("this relase? %d, %d\n", node_index, len);
 // assert(check_no_full_leaves(&edges, node_index, len));
  #if ENABLE_PMA_LOCK == 1
  release_locks_in_range(task_id, held_locks, GENERAL);

  for (uint32_t i = lock_span.x; i < held_locks.x; i++) {
    nodes[i].lock.lock(task_id, REBALANCE);
    nodes[i].lock.unlock(task_id);
  }
  for (uint32_t i = held_locks.y+1; i <= lock_span.y; i++) {
    nodes[i].lock.lock(task_id, REBALANCE);
    nodes[i].lock.unlock(task_id);
  }
  // printf("node_index5 = %d\n", node_index);
  // print_array();
  // edges.list_lock.unlock_shared();
   // assert(check_no_node_locks_for_me(task_id));
  #endif
  return;
}



// remove elem at index
// assumes the lock on index is held by the parent
// and releases it when it is done with it
template <typename E>
void inline Block<E>::remove(uint64_t task_id, uint_t index, uint32_t elem_dest, uint32_t src
  #if ENABLE_PMA_LOCK == 1
  , pair_int held_locks
  #endif
  ) {
  #if ENABLE_PMA_LOCK == 1
 // assert(check_every_lock_in_leaf(task_id, index));
 // assert(check_no_full_leaves(&edges, find_leaf(&edges, index), edges.logN));
  #endif
  
  /*
  if (index > 0 && edges.dests[index - 1] == NULL_VAL && find_leaf(&edges, index) != index) {
    printf("insert conditional || index = %d src = %u elem dest = %u, elem value = %u, next leaf: %d\n", index, src, elem_dest, elem_val, next_leaf(index, edges.loglogN));
    print_array(get_worker_num());
  }*/


  //printf("reoving: index = %d src = %u elem dest = %u\n", index, src, elem_dest);
  //print_array(get_worker_num());
  uint_t orig_n = edges.N;
  
  if ((elem_dest != SENT_VAL) ) {
    // -1 for the case that the location is the spot of the next sentinal
   // assert(src == find_contaning_node(index-1));
  }
  // edges.list_lock.lock_shared();
  #if ENABLE_PMA_LOCK == 1
 // assert(nodes[src].lock.i_own_lock(task_id));
  #endif
  int level = edges.H;
  uint_t len = edges.logN;

  uint32_t * vals = (uint32_t *) edges.vals;
  uint32_t * dests = (uint32_t *) edges.dests;
  // always deposit on the left
 // assert(index < edges.N - 1);
  // if the edge already exists in the graph, update its value
  // do not make another edge
  // slide right assumes we hold the lock till the end of the leaf
  #if ENABLE_PMA_LOCK == 1
 // assert(check_every_lock_in_leaf(task_id, index));
  #endif
  //printf("before sliding, index = %d\n", index);
  //print_array();
  slide_left(index, vals, dests);
  //printf("after sliding, index = %d\n", index);
  //print_array();

  
  //assert(vals[index]!=0);
  //print_array();
  uint_t node_index = find_leaf(&edges, index);
  double density = get_density(&edges, node_index, len);
  //printf("density = %f, %d\n", density, density == 1);

  // spill over into next level up, node is completely full.
  if (density == 0) {
    //printf("first rebalence\n");
    len*=2;
    level--;
    node_index = find_node(node_index, len);
  } else {
    redistribute(node_index, len);
  }
 // assert(edges.N == orig_n);
  #if ENABLE_PMA_LOCK == 1
 // assert(check_every_lock_in_leaf(task_id, index));
  // being fancy here since some of the locks are done with and others might be used for the rebalence
  pair_int locks_for_rebalance = which_locks_in_range(node_index, len, src);
  //printf("relasing locks %d through %d with reason %d\n", locks_for_leaf.x, locks_for_rebalance.x -1, GENERAL);
  //printf("before with worker %lu\n", get_worker_num());
  //printf("worker %lu unlocking %d through %d with GENERAL \n", get_worker_num(), locks_for_leaf.x, locks_for_rebalance.x);
  temp_pfor (uint32_t i = held_locks.x; i < locks_for_rebalance.x; i++) {
    nodes[i].lock.unlock(task_id);
  }
  //printf("worker %lu relasing locks %d through %d with reason REBALANCE\n",get_worker_num(), max(locks_for_rebalance.x, locks_for_leaf.x), locks_for_leaf.y);
  for (uint32_t i = max(locks_for_rebalance.x, held_locks.x) ; i <= min(held_locks.y, locks_for_rebalance.y); i++) {
    nodes[i].lock.unlock(task_id, REBALANCE);
  }
  //printf("worker %lu unlocking %d through %d with GENERAL \n", get_worker_num(), locks_for_rebalance.y +1,locks_for_leaf.y);

  for (uint32_t i = locks_for_rebalance.y +1; i <= held_locks.y; i++) {
    nodes[i].lock.unlock(task_id);
  }

  //printf("unlocking %d by worker %lu\n",src, get_worker_num());
  //printf("grabbing %d, %d\n", node_index, len);
  //printf("about to grab\n");
  pair_int lock_span = {max(locks_for_rebalance.x, held_locks.x),  max(locks_for_rebalance.y, held_locks.y)};
 // assert(check_no_node_locks_held_by_me(task_id));

  held_locks = grab_locks_in_range_with_resets(task_id, node_index, len, REBALANCE, src);
  lock_span.x = min(held_locks.x, lock_span.x);
  lock_span.y = max(held_locks.y, lock_span.y);
  #endif

  // if somebody doubled and we let them with a reset
  if (edges.N != orig_n) {
    //printf("worker %lu: somebody else doubled on us so we assume it has been distributed properly 1\n", get_worker_num());
    //printf("worker %lu: edges.N = %u, orig_n = %u\n",get_worker_num(), edges.N, orig_n);
    #if ENABLE_PMA_LOCK == 1
    release_locks_in_range(task_id, held_locks, GENERAL);
    for (uint32_t i = lock_span.x; i <= lock_span.y; i++) {
      if (i < held_locks.x || i > held_locks.y) {
        nodes[i].lock.lock(task_id, REBALANCE);
        nodes[i].lock.unlock(task_id);
      }
    }
   // assert(check_no_node_locks_for_me(task_id));
    #endif
    return;
  }
  // printf("node_index3 = %d\n", node_index);
  // print_array();

  // get density of the leaf you are in
  double density_b = lower_density_bound[level];
  uint_t density_count = get_density_count(&edges, node_index, len);
  density = ((double)density_count)/len;
  // printf("density %f, upperbound %f, len = %d, N = %d, logN = %d\n", density,
  // density_b.y, len, list->N, list->logN);

  // while density too high, go up the implicit tree
  // go up to the biggest node above the density bound
  //printf("node_index = %d, desnsity = %f, density bound = %f\n", node_index, density, density_b.y);
  std::vector<uint_t> sub_counts(0);
  while (density <= density_b) {
    //printf("node_index = %d, desnsity = %f, density bound = %f, len = %d, worker = %lu\n", node_index, density, density_b.y, len, get_worker_num());
    len *= 2;
    if (len <= edges.N) {
      level--;
      uint_t new_node_index = find_node(node_index, len);
      
      
      #if ENABLE_PMA_LOCK == 1
      release_locks_in_range(task_id, held_locks, REBALANCE);
      held_locks = grab_locks_in_range_with_resets(task_id, new_node_index, len, REBALANCE, src);
      if (held_locks.x < lock_span.x) {
        lock_span.x = held_locks.x;
      }
      if (held_locks.y > lock_span.y) {
        lock_span.y = held_locks.y;
      }
      #endif
      if (edges.N != orig_n) {
        #if ENABLE_PMA_LOCK == 1
        //printf("worker %lu: somebody else doubled on us so we assume it has been distributed properly 2\n", get_worker_num());
        //printf("worker %lu: edges.N = %u, orig_n = %u\n",get_worker_num(), edges.N, orig_n);
        release_locks_in_range(task_id, held_locks, GENERAL);
        for (uint32_t i = lock_span.x; i <= lock_span.y; i++) {
          if (i < held_locks.x || i > held_locks.y) {
            nodes[i].lock.lock(task_id, REBALANCE);
            nodes[i].lock.unlock(task_id);
          }
        }
       // assert(check_no_node_locks_for_me(task_id));
        #endif
        return;
      }
      if (len <= REDISTRIBUTE_PAR_SIZE) {
        density_count = get_density_count(&edges, new_node_index, len);
      } else {
        sub_counts.resize(len/REDISTRIBUTE_PAR_SIZE);
        density_count = get_density_count_par(&edges, new_node_index, len, sub_counts);
      }
      // to help prevent double doubling by knowing how big it was on the last count
      orig_n = edges.N;
      node_index = new_node_index;
      density_b = lower_density_bound[level];
      density = ((double) density_count )/len;
    } else {
      // if you reach the root, double the list
      #if ENABLE_PMA_LOCK == 1
      release_locks_in_range(task_id, held_locks, DOUBLE);
      #endif
      //if (edges.N == orig_n) {
        // for (int i = 0; i < lock_count; i++) {
        //  edges.list_lock.unlock_shared();
        //}
        //TODO don't double double
        //printf("second double due to worker %lu\n", get_worker_num());
        //print_array(get_worker_num());
       // assert(check_no_node_locks_held_by_me(task_id));
        half_list(task_id, sub_counts, density_count);
        // -1 for the lock at the begining of the function
        // we want to leave with the same number as we entered with
        //for (int i = 0; i < lock_count-1; i++) {
        //  edges.list_lock.lock_shared();
        //}
     // }
       // assert(check_no_node_locks_for_me(task_id));
      return;
    }
    // printf("density %f, upperbound %f, len = %d, N = %d, logN = %d\n",
    // density, density_b.y, len, list->N, list->logN);
  }
 // assert(((double)get_density_count(&edges, node_index, len))/ len == density);
 // assert(density > density_b);
  //print_array(get_worker_num());
  if(len > edges.logN) {
     if (len <= REDISTRIBUTE_PAR_SIZE) {
      redistribute(node_index, len);
     } else {
      redistribute_par(node_index, len, sub_counts, density_count);
     }
    
  }
  //printf("this relase? %d, %d\n", node_index, len);
 // assert(check_no_full_leaves(&edges, node_index, len));
  #if ENABLE_PMA_LOCK == 1
  release_locks_in_range(task_id, held_locks, GENERAL);

  for (uint32_t i = lock_span.x; i < held_locks.x; i++) {
    nodes[i].lock.lock(task_id, REBALANCE);
    nodes[i].lock.unlock(task_id);
  }
  for (uint32_t i = held_locks.y+1; i <= lock_span.y; i++) {
    nodes[i].lock.lock(task_id, REBALANCE);
    nodes[i].lock.unlock(task_id);
  }
  // printf("node_index5 = %d\n", node_index);
  // print_array();
  // edges.list_lock.unlock_shared();
   // assert(check_no_node_locks_for_me(task_id));
    #endif
  return;
}

template<class T> inline void Log(const __m256i & value) {
    const size_t n = sizeof(__m256i) / sizeof(T);
    T buffer[n];
    _mm256_storeu_si256((__m256i*)buffer, value);
    for (int i = 0; i < n; i++)
        std::cout << buffer[i] << " ";
    printf("\n");
}


/*
//I don't think this is quite correct, but it did work at some point
std::vector<uint32_t>
Block<E>::sparse_matrix_vector_multiplication(std::vector<uint32_t> const &v) {
  std::vector<uint32_t> result(nodes_size, 0);

  uint32_t num_vertices = nodes_size;
  
  bool vector = true;

  temp_pfor (uint32_t i = 0; i < num_vertices; i++) {
    nodes[i].lock.lock_shared();
    // printf("i: %d\n", i);
    // +1 to avoid sentinel
    uint32_t j = nodes[i].beginning + 1;
    __m256i temp_sum = _mm256_setzero_si256();
    while (j < nodes[i].end) {
       if (!vector || (nodes[i].end - j < 4 || j >= next_leaf(j, edges.logN)-4)) { 
        if (!is_null(edges.items[j].e)) {
          result[i] += edges.items[j].e.value * v[edges.items[j].e.dest];
          j++;
        } else {
          j = next_leaf(j, edges.logN);
        }
      
      } else {
        __m256i edgegroup = _mm256_loadu_si256((__m256i*) &edges.items[j]);
        __m256i values_group = _mm256_srli_epi64(edgegroup, 32);
        __m256i mask = _mm256_setr_epi64x(0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF);
        __m256i dest_group_targets = _mm256_and_si256(edgegroup, mask);
        __m256i dest_group = _mm256_i32gather_epi32((int*)v.data(), dest_group_targets, sizeof(v[0]));
        __m256i partial_sums = _mm256_mul_epi32(dest_group, values_group);
        temp_sum = _mm256_add_epi64(temp_sum, partial_sums);
        //temp_sums = _mm256_and_si256(temp_sums, mask);    


        __m256i mask2 = _mm256_setr_epi64x(0xFFFFFFFFFFFFFFFFUL, 0xFFFFFFFFFFFFFFFFUL, 0xFFFFFFFFFFFFFFFFUL, 0xFFFFFFFF00000000UL);
        if (_mm256_testc_si256(mask2, edgegroup)) {
          j = next_leaf(j, edges.logN);
        } else {
          j+=4;
        }
      }
    }
    if (vector) {
      result[i] += _mm256_extract_epi32(temp_sum, 0);
      result[i] += _mm256_extract_epi32(temp_sum, 2);
      result[i] += _mm256_extract_epi32(temp_sum, 4);
      result[i] += _mm256_extract_epi32(temp_sum, 6);
    } 
  } 
  return result;
}
*/
template <typename E>
void inline Block<E>::print_graph() {
  uint32_t num_vertices = nodes_size;
  for (uint32_t i = 0; i < num_vertices; i++) {
    // printf("i: %d\n", i);
    // +1 to avoid sentinel
    uint32_t matrix_index = 0;

    for (uint_t j = nodes[i].beginning + 1; j < nodes[i].end; j++) {
      if (edges.dests[j]!=NULL_VAL) {
        while (matrix_index < edges.dests[j]) {
          printf("000 ");
          matrix_index++;
        }
        printf("%03d ", edges.vals[j]);
        matrix_index++;
      }
    }
    for (uint32_t j = matrix_index; j < num_vertices; j++) {
      printf("000 ");
    }
    printf("\n");
  }
}

// add a node to the graph
// TODO: intialize the node with hash tabel
template <typename E>
void inline Block<E>::add_node() {
  uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2);
#if ENABLE_PMA_LOCK == 1
  node_lock.lock(task_id);
#endif
  BlockState<E> node;
  uint32_t len = nodes_size;
  edge_t sentinel;
  sentinel.dest = SENT_VAL; // placeholder
  sentinel.value = len;       // back pointer

  if (len > 0) {
    node.beginning = nodes[len - 1].end;
    if(node.beginning == edges.N - 1) {
      uint32_t volatile  * volatile dests = edges.dests;
      uint_t leaf = find_leaf(&edges, node.beginning);
      // moving the beginning of the node you are inserting left
      //TODO jump back to the last leaf and look forward from there
      if (nodes[len-1].degree == 0) {
        node.beginning = nodes[len - 1].beginning + 1;
      } else {
        while(dests[node.beginning - 1] == NULL_VAL && node.beginning != leaf /* && next_leaf(node.beginning, edges.loglogN) != node.beginning*/) {
          node.beginning -= 1;
        }
      }
    }
    node.end = node.beginning + 1;
    // fix previous node to set its end to your beginning
    nodes[len - 1].end = node.beginning;
  } else {
    node.beginning = 0;
    node.end = 1;
    // be special to the first one since we know it never moves do it doesn't need to look like a sentinal since it doesn't have to be fixed ever
    sentinel.value = NULL_VAL;
    sentinel.dest = 0;
  }
  // initialize the hash table
  node.entries = nullptr;
  node.htab = nullptr;
  node.bsize = 0;
  node.degree = 0;
#if ENABLE_PMA_LOCK == 1
  node.lock.name("nodeLock");
  node.lock.number(nodes_size);
#endif
  nodes[nodes_size] = node;
  nodes_size++;
  #if ENABLE_PMA_LOCK == 1
  pair_int held_locks = grab_locks_for_leaf_with_resets(task_id, nodes_size - 1);
  // edges.list_lock.lock_shared();
  node_lock.make_shared(task_id);
  #endif
  uint_t loc = node.beginning;
  //tbassert(loc < edges.N, "loc: %d, edges.N: %d\n", loc, edges.N);
  insert(task_id, loc, sentinel.dest, sentinel.value, nodes_size - 1
  #if ENABLE_PMA_LOCK == 1
    , held_locks
  #endif
  );
  // printf("end of insert reason: %d\n", edges.lock_array[find_lock_index(&edges, loc)].reason);
  // edges.list_lock.unlock_shared();
#if ENABLE_PMA_LOCK == 1
  node_lock.unlock_shared(task_id);
#endif
  // print_array(len);
}

//TODO deal with the case that multiple threads do the binary search and try and make the same region exclusive
template <typename E>
void inline Block<E>::add_edge(uint32_t src, uint32_t dest, uint32_t value) {
  // printf("src = %d, dest = %d, val = %d\n", src,dest,value);
  if (value != 0) {
    uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2);
    #if ENABLE_PMA_LOCK == 1
   // assert(check_no_locks_for_me(task_id));
    node_lock.lock_shared(task_id);
    pair_int held_locks = grab_locks_for_leaf_with_resets(task_id, src);
   // assert(nodes[src].lock.i_own_lock(task_id));
    #endif
    BlockState<E> node = move(nodes[src]);


    edge_t e;
    e.dest = dest;
    e.value = value;
    
    // edges.list_lock.lock_shared();
    //uint32_t node_begin = node.beginning;
    //uint32_t node_end = node.end;
    __sync_fetch_and_add(&nodes[src].degree,1);
    // printf("looking in region %u, %u by worker %lu\n", node.beginning + 1, node.end, get_worker_num());
    uint_t loc_to_add =
        binary_search(&edges, e.dest, e.value, node.beginning + 1, node.end);
    __builtin_prefetch ((void *)&edges.vals[loc_to_add], 1, 3);
#if ENABLE_PMA_LOCK == 1
    pair_int needed_locks = which_locks_in_range(find_leaf(&edges, loc_to_add), edges.logN, src);
    for (uint32_t i = held_locks.x; i < needed_locks.x; i++) {
      nodes[i].lock.unlock(task_id, GENERAL);
      held_locks.x = i+1;
    }
    for (uint32_t i = needed_locks.y+1; i <= held_locks.y; i++) {
      nodes[i].lock.unlock(task_id, GENERAL);
      
    }
    if (needed_locks.y+1 <= held_locks.y) {
      held_locks.y = needed_locks.y;
    }
    // print_array();
    //printf("loc_to_add: %u by worker %lu\n", loc_to_add, get_worker_num());
    // printf("src: %d, dest: %d by worker %lu\n", src, dest, get_worker_num());
    // print_array();

    
   // assert(nodes[src].lock.i_own_lock(task_id));
   // assert(check_every_lock_in_leaf(task_id, loc_to_add));
    /*
    if (!check_no_full_leaves(&edges, find_leaf(&edges, loc_to_add), edges.logN)) {
      printf("worker %lu is trying to insert into a full leaf\n", get_worker_num());
      print_array(get_worker_num());
    }
    */
#endif
   // assert(check_no_full_leaves(&edges, find_leaf(&edges, loc_to_add), edges.logN));
    insert(task_id, loc_to_add, e.dest, e.value, src
      #if ENABLE_PMA_LOCK == 1
      , held_locks
      #endif
     );
    //printf("worker %lu done\n", get_worker_num());
    // edges.list_lock.unlock_shared();
    //print_array();
    #if ENABLE_PMA_LOCK == 1
    node_lock.unlock_shared(task_id);
   // assert(check_no_locks_for_me(task_id));
    #endif
  }
}

template <typename E>
bool inline Block<E>::add_edge_update(uint32_t src, uint32_t dest, uint32_t value) {
  if (value != 0) {
#if ENABLE_PMA_LOCK == 1
    //cout << "here0 " << endl;
    uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2);
    node_lock.lock_shared(task_id);
    //cout << "here1 " << endl;
    //printf("Before grabbing locks for src: %u, task_id: %lu\n", src, task_id);
    pair_int held_locks = grab_locks_for_leaf_with_resets(task_id, src);
    //printf("After grabbing locks: (%d, %d)\n", held_locks.x, held_locks.y);
    //cout << "here11 " << endl;
   // assert(nodes[src].lock.i_own_lock(task_id));
#else
    uint64_t task_id = next_task_id;
    next_task_id += 2;
#endif
    BlockState<E> node = move(nodes[src]);


    edge_t e;
    e.dest = dest;
    e.value = value;
    
    // edges.list_lock.lock_shared();
    //uint32_t node_begin = node.beginning;
    //uint32_t node_end = node.end;
    // printf("looking in region %u, %u by worker %lu\n", node.beginning + 1, node.end, get_worker_num());
    //cout << "here2 " << endl;
    uint_t loc_to_add =
        binary_search(&edges, e.dest, e.value, node.beginning + 1, node.end);
    //__builtin_prefetch ((void *)&edges.vals[loc_to_add], 1, 3);

    //cout << "here3 " << endl;
    if (edges.dests[loc_to_add] == dest) {
      edges.vals[loc_to_add] = value;
      #if ENABLE_PMA_LOCK == 1
      release_locks_in_range(task_id, held_locks);
      node_lock.unlock_shared(task_id);
      #endif
      return false;
    }
    #if ENABLE_PMA_LOCK == 1
    pair_int needed_locks = which_locks_in_range(find_leaf(&edges, loc_to_add), edges.logN, src);
    for (uint32_t i = held_locks.x; i < needed_locks.x; i++) {
      nodes[i].lock.unlock(task_id, GENERAL);
      held_locks.x = i+1;
    }
    for (uint32_t i = needed_locks.y+1; i <= held_locks.y; i++) {
      nodes[i].lock.unlock(task_id, GENERAL);
      
    }
    if (needed_locks.y+1 <= held_locks.y) {
      held_locks.y = needed_locks.y;
    }
    #endif
    // printf("loc_to_add: %d\n", loc_to_add);
    // printf("src: %d, dest: %d\n", src, dest);
#if ENABLE_PMA_LOCK == 1
    __sync_fetch_and_add(&nodes[src].degree,1);
#else
    nodes[src].degree += 1;
#endif
    //cout << "here4 " << endl;
    insert(task_id, loc_to_add, e.dest, e.value, src
      #if ENABLE_PMA_LOCK == 1
      , held_locks
      #endif 
      );
    // edges.list_lock.unlock_shared();
    //cout << "here5 " << endl;
#if ENABLE_PMA_LOCK == 1
    node_lock.unlock_shared(task_id);
#endif
    //assert(check_no_locks_for_me(task_id));
    return true;
  }
  // if the value was 0
  return false;
}

// bool __attribute__ ((noinline)) Block<E>::add_edge_update_fast(uint32_t src, uint32_t dest, uint32_t value, uint64_t task_id) {
template <typename E>
bool inline Block<E>::add_edge_update_fast(uint32_t src, uint32_t dest, uint32_t value, uint64_t task_id) {
    // printf("add edge update fast: src %u, dest %u, val %u, task id %u\n", src, dest, value, task_id);
    __builtin_prefetch(&nodes[src]);
    __builtin_prefetch(&edges);
    if (value != 0) {
     // assert(check_no_locks_for_me(task_id));
      pair_int held_locks = grab_locks_for_leaf_with_resets(task_id, src);
     // assert(src >= held_locks.x);
     // assert(src <= held_locks.y);
      //assert(nodes[src].lock.i_own_lock(task_id));
      BlockState<E> node = move(nodes[src]);


      edge_t e;
      e.dest = dest;
      e.value = value;
      
      // edges.list_lock.lock_shared();
      //uint32_t node_begin = node.beginning;
      //uint32_t node_end = node.end;
      // printf("looking in region %u, %u by worker %lu\n", node.beginning + 1, node.end, get_worker_num());
      uint_t loc_to_add =
          binary_search(&edges, e.dest, e.value, node.beginning + 1, node.end);
      __builtin_prefetch ((void *)&edges.vals[loc_to_add], 1, 3);


      if (edges.dests[loc_to_add] == dest) {
        edges.vals[loc_to_add] = value;
        release_locks_in_range(task_id, held_locks);
        return false;
      }
#if ENABLE_PMA_LOCK == 1
      pair_int needed_locks = which_locks_in_range(find_leaf(&edges, loc_to_add), edges.logN, src);
      if (src < needed_locks.x) {
        needed_locks.x = src;
      }
     // assert(needed_locks.x >= held_locks.x);
     // assert(needed_locks.y <= held_locks.y);
      for (uint32_t i = held_locks.x; i < needed_locks.x; i++) {
        nodes[i].lock.unlock(task_id, GENERAL);
        held_locks.x = i+1;
      }
      for (uint32_t i = needed_locks.y+1; i <= held_locks.y; i++) {
        nodes[i].lock.unlock(task_id, GENERAL);
        
      }
      if (needed_locks.y+1 <= held_locks.y) {
        held_locks.y = needed_locks.y;
      }
#endif
      // printf("loc_to_add: %d\n", loc_to_add);
      // printf("src: %d, dest: %d\n", src, dest);
      __sync_fetch_and_add(&nodes[src].degree,1);
      // print_array();
      insert(task_id, loc_to_add, e.dest, e.value, src
        #if ENABLE_PMA_LOCK == 1
        , held_locks
        #endif
        );
      // printf("\tinserted (%u, %u)\n", src, dest);
      // edges.list_lock.unlock_shared();
      // print_array();
     // assert(check_no_locks_for_me(task_id));
      return true;
    }
  // if the value was 0
  return false;
}

template <typename E>
void inline Block<E>::add_edge_batch_update_no_val(uint32_t *srcs, uint32_t *dests, uint_t edge_count) {
  uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2*edge_count);
#if ENABLE_PMA_LOCK == 1
  node_lock.lock_shared(0);
  temp_pfor (uint_t i = 0; i < edge_count; i++) {
#else
  for (uint_t i = 0; i < edge_count; i++) {
#endif
    uint32_t src = srcs[i];
    uint32_t dest = dests[i];
    add_edge_update_fast(src,dest,1,task_id+2*i);
  }
#if ENABLE_PMA_LOCK == 1
  node_lock.unlock_shared(0);
#endif
}

template <typename E>
void inline Block<E>::add_edge_batch_update(uint32_t *srcs, uint32_t *dests, uint32_t *values, uint_t edge_count) {
  uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2*edge_count);
#if ENABLE_PMA_LOCK == 1
  node_lock.lock_shared(0);
  temp_pfor (uint_t i = 0; i < edge_count; i++) {
#else
  for (uint_t i = 0; i < edge_count; i++) {
#endif
    uint32_t src = srcs[i];
    uint32_t dest = dests[i];
    uint32_t value = values[i];
    add_edge_update_fast(src,dest,value,task_id+2*i);
  }
#if ENABLE_PMA_LOCK == 1
  node_lock.unlock_shared(0);
#endif
}

// merge a dense batch with PMA into a specified region of the giant output
// array
// return nnz in the range of the merge
uint64_t inline do_merge(uint32_t* new_dests, uint32_t* new_vals, uint64_t
output_start, pair_uint *es, uint64_t batch_start, uint64_t batch_end,
uint32_t* dests, uint32_t* vals, uint64_t pma_start, uint64_t pma_end, uint32_t loglogN)
{
  // dests = pma_dests, vals = pma_vals

  uint64_t es_idx = batch_start;
  uint64_t pma_idx = pma_start;
  uint64_t result_idx = output_start;
  // TODO: look around (could be a binary search if its too slow)
  uint32_t current_src_pma = 0;
  while(pma_idx > 0 && dests[pma_idx] != SENT_VAL) {
    pma_idx--;
  }
  if (pma_idx != 0) {
    current_src_pma = vals[pma_idx];
  }

  pma_idx = pma_start;
  if (pma_idx == 0) {
    new_dests[0] = dests[0];
    new_vals[0] = vals[0];
    result_idx++;
    pma_idx++;
  }

  // merge
  // printf("edges.N %lu, edge_count %u, max_elts %lu, new_size %lu, nnzs %lu\n", edges.N, edge_count, m
  while(es_idx < batch_end || pma_idx < pma_end) {
    // merge the rest of the PMA in
    if (es_idx == batch_end) {
      while(pma_idx < pma_end) {
        new_dests[result_idx] = dests[pma_idx];
        new_vals[result_idx] = vals[pma_idx];
        //printf("end, %u, %u\n", new_dests[result_idx], new_vals[result_idx]);
        result_idx+=(dests[pma_idx] != NULL_VAL);
        pma_idx++;
      }
      break;
    }

    uint32_t current_src_batch = es[es_idx].x;
    uint32_t current_dest_batch = es[es_idx].y;
    // skip over duplicates
    while(es_idx < batch_end && current_src_batch == es[es_idx+1].x && current_dest_batch == es[es_idx+1].y) {
      es_idx++;
    }
   // assert(es_idx < batch_end);
    uint32_t current_val_batch = 1;

   // assert(pma_idx < pma_end);

    // TODO: skip to next leaf if there is a performance issue
    while (pma_idx < pma_end && dests[pma_idx] == NULL_VAL) {
      pma_idx = next_leaf(pma_idx, loglogN);
      /*
      uint32_t logN = 1 << loglogN;
      if (current_src_pma < num_nodes) {
        while (dests[pma_idx] == NULL_VAL) {
          pma_idx += logN;
        }
      } else {
        while (pma_idx < pma_end && dests[pma_idx] == NULL_VAL) {
          pma_idx += logN;
        }
      }
      */
    }
    // at the last node
    if (pma_idx == pma_end) {
      // merge the rest of the batch in
      for(;es_idx < batch_end; es_idx++) {
        // TODO: remove later after correctness
        /*if (es[es_idx].x != current_src_pma) {
          printf("something is wrong\n");
        }*/
        // TODO: if you make edges SoA, you can do a memcpy here
        new_dests[result_idx] = es[es_idx].y;
        new_vals[result_idx] = current_val_batch;
        result_idx++;
      }
      break;
    }
    uint32_t current_dest_pma = dests[pma_idx];
   // assert(current_dest_pma != NULL_VAL);
    // check if pma elt is a sentinel
    if (current_dest_pma == SENT_VAL) {
      // TODO: remove after correctness tests
      /*if (!(current_src_pma == 0 || current_src_pma == vals[pma_idx] - 1 || current_src_pma == vals[pm
        printf("something wrong with pma sentinals giving us a bad pma source, %u, %u\n", current_src_pm
      }*/
      current_src_pma = vals[pma_idx];
    }
    if (current_src_pma < current_src_batch) {
      //printf("1. %u, %u\n", current_src_pma, dests[pma_idx]);
      new_dests[result_idx] = dests[pma_idx];
      new_vals[result_idx] = vals[pma_idx];
      pma_idx++;
    } else if (current_src_pma == current_src_batch) {
      if (current_dest_pma < current_dest_batch || current_dest_pma == SENT_VAL) {
        //printf("2. %u, %u\n", current_src_pma, dests[pma_idx]);
        new_dests[result_idx] = dests[pma_idx];
        new_vals[result_idx] = vals[pma_idx];
        pma_idx++;
      } else if (current_dest_pma == current_dest_batch) {
        //printf("3. %u, %u\n", current_src_pma, current_dest_batch);
        new_dests[result_idx] = current_dest_batch;
        new_vals[result_idx] = current_val_batch;
        pma_idx++;
        es_idx++;
      } else {
        //printf("4. %u, %u\n", current_src_batch, current_dest_batch);
        new_dests[result_idx] = current_dest_batch;
        new_vals[result_idx] = current_val_batch;
        es_idx++;
      }
    } else { // current_src_pma > current_src_batch
      //printf("5. %u, %u\n", current_src_batch, current_dest_batch);
      new_dests[result_idx] = current_dest_batch;
      new_vals[result_idx] = current_val_batch;
      es_idx++;
    }
    result_idx++;
  }
  return result_idx - output_start;
}

// large merge
template <typename E>
void inline Block<E>::add_edge_batch_update_no_val_parallel(pair_uint *es, uint64_t edge_count) {
  //printf("starting add_edge_batch_update_no_val_parallel\n");
  printf("*** BATCH NO VAL PARALLEL NOT CURRENTLY WORKING ***\n");
  return;

  uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2*edge_count);
  // node_lock.lock_shared(0);

  //printf("\nlarge merge in batch\n");
  grab_all_locks(task_id, true, GENERAL);
  //std::sort(es, es + edge_count, sort_helper_x);
  //printf("starting sort\n");
  // TODO: if you need this to work, you need th sorts
  // rm for now to get it compiling
  // integerSort_y((pair_els*)es, edge_count, get_n());
  // integerSort_x((pair_els*)es, edge_count, get_n());
  //printf("finished sort\n");
  //for (int i = 0; i < edge_count; i++) {
  //  printf("%u, %u\n", es[i].x, es[i].y);
  //}

  uint32_t num_workers = ParallelTools::getWorkers()*5;
  //printf("edges.N = %lu, edge_count = %lu\n",edges.N, edge_count);
  uint64_t max_elts = edges.N + edge_count;
  //uint64_t new_size = 1 << bsr_word(max_elts);
  uint64_t new_size = max_elts - 1;
  new_size |= new_size >> 1;
  new_size |= new_size >> 2;
  new_size |= new_size >> 4;
  new_size |= new_size >> 8;
  new_size |= new_size >> 16;
  new_size |= new_size >> 32;
  new_size+=1;
  if (new_size < max_elts) { new_size *= 2; }

  uint32_t* dests = (uint32_t*) edges.dests;
  uint32_t* vals = (uint32_t*) edges.vals;
  uint32_t* new_vals = (uint32_t*) malloc(new_size * sizeof(uint32_t));
  if (new_vals == NULL) {
    printf("bad alloc for new_vals, trying to alloc something of size %lu\n", new_size);
    exit(-1);
  }
  uint32_t* new_dests = (uint32_t*) malloc(new_size * sizeof(uint32_t));
  if (new_dests == NULL) {
    printf("bad alloc for new_dests, trying to alloc something of size %lu\n", new_size);
    exit(-1);
  }

  std::vector<uint64_t> counts(num_workers+1);
  counts[0] = 0;
  std::vector<uint64_t> output_starts(num_workers);
  uint32_t increment_batch = edge_count / num_workers;
  //printf("starting merge\n");
  temp_pfor(uint32_t i = 0; i < num_workers; i++) {

    uint64_t batch_start = increment_batch * i;
    uint64_t batch_end = std::min(batch_start + increment_batch, (uint64_t) edge_count);
    if (i == num_workers-1) {
      batch_end = edge_count;
    }

    uint64_t pma_start = 0;
    if (i > 0) {
      pma_start = binary_search(&edges, es[batch_start].y, 0, nodes[es[batch_start].x].beginning + 1,  nodes[es[batch_start].x].end);
    }
    uint64_t pma_end = edges.N;
    if (i < num_workers - 1) {
      pma_end = binary_search(&edges, es[batch_end].y, 0, nodes[es[batch_end].x].beginning + 1, nodes[es[batch_end].x].end);
    }

    uint64_t output_start = batch_start + pma_start;
    output_starts[i] = output_start;
    counts[i+1] = do_merge(new_dests, new_vals, output_start, es, batch_start, batch_end, dests, vals,  pma_start, pma_end, edges.loglogN);
  }

  // prefix sum
  for(uint32_t i = 1; i < num_workers + 1; i++) {
    counts[i] += counts[i-1];
  }

  // should be nnz
  uint64_t result_idx = counts[num_workers];

  uint64_t final_size = new_size;
  double cur_density = (double) result_idx / final_size;
  while (cur_density < .25) {
    final_size /= 2;
    cur_density = (double) result_idx / final_size;
  }
  while (cur_density > .75) {
    final_size *= 2;
    cur_density = (double) result_idx / final_size;
  }
 // assert(cur_density >= .25 && cur_density <= .75);
  // printf("new size %lu, final_size %lu, nnz %lu\n", new_size, final_size, result_idx);
  edges.N = final_size;
  edges.loglogN = bsr_word(bsr_word(final_size) + 1);
  edges.logN = 1 << edges.loglogN;
  edges.mask_for_leaf = ~ (edges.logN - 1);
  edges.density_limit = ((double) edges.logN - 1) / edges.logN;
  edges.H = bsr_word(new_size / edges.logN);
  for(unsigned int i = 0; i <= edges.H; i++) {
    lower_density_bound[i] = density_bound(&edges, i).x;
    upper_density_bound[i] = density_bound(&edges, i).y;
  }

  // allocate space for dense
  free((void*)edges.dests);
  free((void*)edges.vals);
  uint32_t* dense_vals = (uint32_t*) malloc(result_idx * sizeof(uint32_t));

  if (dense_vals == NULL) {
    printf("bad alloc for dense_vals\n");
    exit(-1);
  }

  uint32_t* dense_dests = (uint32_t*) malloc(result_idx * sizeof(uint32_t));
  if (dense_dests == NULL) {
    printf("bad alloc for dense_dests\n");
    exit(-1);
  }

  // copy into dense array
  //printf("starting make dense\n");
  temp_pfor(uint32_t i = 0; i < num_workers; i++) {
    uint32_t start_output_idx = counts[i];
    uint32_t start_input_idx = output_starts[i];
    uint32_t end_input_idx = start_input_idx + (counts[i+1] - counts[i]);
    for(uint32_t j = start_input_idx; j < end_input_idx; j++) {
      if (new_dests[j] != NULL_VAL) {
        dense_vals[start_output_idx] = new_vals[j];
        dense_dests[start_output_idx] = new_dests[j];
        start_output_idx++;
      }
    }
  }

  free((void*)new_dests);
  free((void*)new_vals);

  uint32_t* final_vals = (uint32_t*) malloc(final_size * sizeof(uint32_t));
  uint32_t* final_dests = (uint32_t*) malloc(final_size * sizeof(uint32_t));

  edges.dests = final_dests;
  edges.vals = final_vals;
  uint64_t num_leaves = final_size >> edges.loglogN;
  uint64_t count_per_leaf = result_idx / num_leaves;
  uint64_t extra = result_idx % num_leaves;
  //printf("num_leaves = %lu, count_per_leaf = %lu, extra = %lu\n", num_leaves, count_per_leaf, extra);
  //printf("starting redistribute\n");
  temp_pfor(uint64_t i = 0; i < num_leaves; i++) {
    uint64_t count_for_leaf = count_per_leaf + (i < extra);
    uint64_t out_idx_start = i << edges.loglogN;
    uint64_t in_idx_start = count_per_leaf * i + min(i, extra);
    uint64_t out_idx = out_idx_start;
    //printf("%lu, %lu, %lu, %lu\n", count_for_leaf, out_idx_start, in_idx_start, out_idx);
    for(uint64_t j = in_idx_start; j < in_idx_start + count_for_leaf; j++) {
      if (j > 0) {
        if (dense_vals[j] == dense_vals[j-1] && dense_dests[j] == dense_dests[j-1]) {
          //printf("skipping duplicate edge %u, %u\n", dense_vals[j], dense_dests[j]);
          continue;
        }
      }
      final_vals[out_idx] = dense_vals[j];
      final_dests[out_idx] = dense_dests[j];
      if (final_dests[out_idx] == SENT_VAL) {
        uint64_t node_idx = final_vals[out_idx];
        fix_sentinel(node_idx, out_idx);
      }
      out_idx++;
    }
    for (uint64_t j = out_idx; j < (i+1) << edges.loglogN; j++) {
      final_vals[j] = 0;
    }
    for (uint64_t j = out_idx; j < (i+1) << edges.loglogN; j++) {
      final_dests[j] = NULL_VAL;
    }
  }
  //printf("finished redistribute\n");

  free((void*)dense_dests);
  free((void*)dense_vals);
  //print_array(1);
  //check_sentinals();
  release_all_locks(task_id, true, GENERAL);
  //node_lock.unlock_shared(0);
  //printf("after batch insert\n");
  //print_array(0);
  //printf("finished add_edge_batch_update_no_val_parallel");
}

// batch delete exclude merge
uint64_t inline do_exclude(uint32_t* new_dests, uint32_t* new_vals, uint64_t
output_start, pair_uint *es, uint64_t batch_start, uint64_t batch_end,
uint32_t* dests, uint32_t* vals, uint64_t pma_start, uint64_t pma_end, uint32_t
loglogN, uint64_t num_nodes)
{
  // dests = pma_dests, vals = pma_vals

  uint64_t es_idx = batch_start;
  uint64_t pma_idx = pma_start;
  uint64_t result_idx = output_start;
  // TODO: look around (could be a binary search if its too slow)
  uint32_t current_src_pma = 0;
  while(pma_idx > 0 && dests[pma_idx] != SENT_VAL) {
    pma_idx--;
  }
  if (pma_idx != 0) {
    current_src_pma = vals[pma_idx];
  }

  pma_idx = pma_start;
  if (pma_idx == 0) {
    new_dests[0] = dests[0];
    new_vals[0] = vals[0];
    result_idx++;
    pma_idx++;
  }

  // merge
  while(es_idx < batch_end || pma_idx < pma_end) {
    // merge the rest of the PMA in
    if (es_idx == batch_end) {
      while(pma_idx < pma_end) {
        new_dests[result_idx] = dests[pma_idx];
        new_vals[result_idx] = vals[pma_idx];
        result_idx+=(dests[pma_idx] != NULL_VAL);
        pma_idx++;
      }
      break;
    }

    uint32_t current_src_batch = es[es_idx].x;
    uint32_t current_dest_batch = es[es_idx].y;
    // skip over duplicates
    while(es_idx < batch_end && current_src_batch == es[es_idx+1].x && current_dest_batch == es[es_idx+1].y) {
      es_idx++;
    }
   // assert(es_idx < batch_end);
   // assert(pma_idx < pma_end);

    if (pma_idx < pma_end && dests[pma_idx] == NULL_VAL) {
      pma_idx = next_leaf(pma_idx, loglogN);
      uint32_t logN = 1 << loglogN;
      if (current_src_pma < num_nodes) {
        while (dests[pma_idx] == NULL_VAL) {
          pma_idx += logN;
        }
      } else {
        while (pma_idx < pma_end && dests[pma_idx] == NULL_VAL) {
          pma_idx += logN;
        }
      }
    }
    // at the last node
    if (pma_idx == pma_end) {
      break;
    }

    uint32_t current_dest_pma = dests[pma_idx];
   // assert(current_dest_pma != NULL_VAL);
    // check if pma elt is a sentinel
    if (current_dest_pma == SENT_VAL) {
      // TODO: remove after correctness tests
      /*if (!(current_src_pma == 0 || current_src_pma == vals[pma_idx] - 1 || current_src_pma == vals[pm
        printf("something wrong with pma sentinals giving us a bad pma source, %u, %u\n", current_src_pm
      }*/
      current_src_pma = vals[pma_idx];
    }
    if (current_src_pma < current_src_batch) {
      new_dests[result_idx] = dests[pma_idx];
      new_vals[result_idx] = vals[pma_idx];
      pma_idx++;
      result_idx++;
    } else if (current_src_pma == current_src_batch) {
      if (current_dest_pma < current_dest_batch || current_dest_pma == SENT_VAL) {
        new_dests[result_idx] = dests[pma_idx];
        new_vals[result_idx] = vals[pma_idx];
        pma_idx++;
        result_idx++;
      } else if (current_dest_pma == current_dest_batch) {
        pma_idx++;
        es_idx++;
      } else {
        es_idx++;
      }
    } else { // current_src_pma > current_src_batch
      es_idx++;
    }
  }
  return result_idx - output_start;
}

template <typename E>
void inline Block<E>::build_from_edges(uint32_t *srcs, uint32_t *dests, uint8_t * pma_edges, uint64_t vertex_count, uint64_t edge_count, uint32_t* additional_degrees) {
  // step 1 : build a CSR
  uint_t* vertex_array = (uint_t*)calloc(vertex_count, sizeof(uint_t)); 
  uint64_t edges_for_pma = 0;
  for(uint64_t i = 0; i < edge_count; i++) {
    if(pma_edges[i]) {
      uint32_t s = srcs[i];
      additional_degrees[s]++;
      vertex_array[s]++;
      edges_for_pma++;
    }
  }

  printf("build from edges: edges for pma = %u\n", edges_for_pma);
  nodes[0].degree = additional_degrees[0];

  // do prefix sum to get top level of CSR into vertex_array
  for(uint32_t i = 1; i < vertex_count; i++) {
    vertex_array[i] += vertex_array[i-1];
    nodes[i].degree = additional_degrees[i];
  }

  // and get CSR edge array into pma_edge_array
  uint32_t* pma_edge_array = (uint32_t*)malloc(edges_for_pma * sizeof(uint32_t));
  uint64_t pma_edges_so_far = 0;
  for(uint64_t i = 0; i < edge_count; i++) {
    if(pma_edges[i]) {
      pma_edge_array[pma_edges_so_far] = dests[i];
      pma_edges_so_far++;
    }
  } 
  
  uint64_t pma_size = vertex_count + pma_edges_so_far;
  uint64_t new_N = 1;
  while (new_N < pma_size) { new_N *= 2; }

  // from double_list
  edges.N = new_N;
  edges.loglogN = bsr_word(bsr_word(edges.N) + 1);
  edges.logN = (1 << edges.loglogN);
  edges.mask_for_leaf = ~(edges.logN - 1);
 // assert(edges.logN > 0);
  edges.density_limit = ((double) edges.logN - 1)/edges.logN;
  edges.H = bsr_word(new_N / edges.logN);
  for (uint32_t i = 0; i <= edges.H; i++) {
    upper_density_bound[i] = density_bound(&edges, i).y;
    lower_density_bound[i] = density_bound(&edges, i).x;
  }

  uint_t num_elts = vertex_count + pma_edges_so_far;
  uint32_t *space_vals = (uint32_t *)aligned_alloc(64, num_elts * sizeof(*(edges.vals)));
  uint32_t *space_dests = (uint32_t *)aligned_alloc(64, num_elts * sizeof(*(edges.dests)));

  // step 2: write the PMA at the front of the new array
  // TODO: can also make this parallel
  uint64_t position_so_far = 0;
  for(uint64_t i = 0; i < vertex_count; i++) {
    // first, write the sentinel
    if (i == 0) {
      space_dests[position_so_far] = 0;
      space_vals[position_so_far] = NULL_VAL;
    } else {
      space_dests[position_so_far] = SENT_VAL;
      space_vals[position_so_far] = i;
    }
    position_so_far++;
    // then write the edges
    // printf("pma degree of vertex %u = %u\n", i, additional_degrees[i]);
    for(uint64_t j = 0; j < additional_degrees[i]; j++) {
      if (i == 0) {
        space_dests[position_so_far] = pma_edge_array[j];
      } else {
        space_dests[position_so_far] = pma_edge_array[vertex_array[i - 1] + j];
      }
      
      //if (i == 1) {
        // printf("\tspace dests %u = %u, pma edge idx %u\n", position_so_far, pma_edge_array[vertex_array[i] + j], vertex_array[i] + j);
      // }
      space_vals[position_so_far] = 1;
      position_so_far++;
    }
  }
 // assert(num_elts == position_so_far);

  printf("starting copy into PMA\n");
  // step 3: redistribute
  uint_t num_leaves = new_N >> edges.loglogN;
  uint_t count_per_leaf = num_elts / num_leaves;
  uint_t extra = num_elts % num_leaves;

  uint32_t *new_dests = (uint32_t *)aligned_alloc(32, new_N * sizeof(*(edges.dests)));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(32, new_N * sizeof(*(edges.vals)));
  parlay::parallel_for (0, new_N, [&](uint64_t i) {
  //for (uint32_t i = 0; i < new_N; i++) {
    new_vals[i] = 0; // setting to null
    new_dests[i] = NULL_VAL; // setting to null
  });

  parlay::parallel_for(0, num_leaves, [&](uint64_t i) {
  // for(uint_t i = 0; i < num_leaves; i++) {
    // how many are going to this leaf
    uint_t count_for_leaf = count_per_leaf + (i < extra);
    // start of leaf in output
    uint_t in = ((i) << edges.loglogN);
    // start in input
    uint_t j2 = count_per_leaf*i +min(i,extra);
    uint_t j3 = j2;
    for(uint_t k = in; k < count_for_leaf+in; k++) {
     // assert(j2 < num_elts);
      new_vals[k] = space_vals[j2];
      j2++;
    }
    for (uint_t k = in; k < count_for_leaf+in; k++) {
      new_dests[k] = space_dests[j3];
      if (new_dests[k]==SENT_VAL) {
        // fixing pointer of node that goes to this sentinel
        uint32_t node_index = space_vals[j3];

        // printf("fixing sentinel of node %u at position %u\n", node_index, k);
        fix_sentinel(node_index, k);
      }
      j3++;
    } 
  });

  /*
  uint_t num_pma_edges = 0;
  for(uint_t i = 1; i < edges.N; i++) {
    if (new_dests[i] != SENT_VAL && new_dests[i] != NULL_VAL) {
      num_pma_edges++;
    }
  }
  printf("num edges in pma = %u\n", num_pma_edges);
  */

  free(space_dests);
  free(space_vals);
  free(vertex_array);

  free((void*)edges.vals);
  edges.vals = new_vals;
  free((void*)edges.dests);
  edges.dests = new_dests;
}

// do merge or not based on size of batch
template <typename E>
void inline Block<E>::add_edge_batch_wrapper(pair_uint *es, uint64_t edge_count, int64_t threshold) {
  // default
  if (threshold < 0) {
    if (edges.N > UINT32_MAX) {
      uint64_t top = (uint64_t)edges.N >> 32;
      threshold = edges.N / (32+bsr_word(top));
    } else if (edges.N == UINT32_MAX) {
      threshold = edges.N / 32;
    } else {
      threshold = edges.N / bsr_word(edges.N);
    }
  }
  // edge_count < num_cells / log(num_cells)
  //printf("threshold %lu, batch size %lu\n", threshold, edge_count);

  // actual inserts into PMA
  if (true || edge_count < (uint64_t) threshold*2) {
    node_lock.lock_shared(0);
    uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2*edge_count);
    parlay::parallel_for (0, edge_count, [&](uint64_t i) {
    // temp_pfor (uint32_t i = 0; i < edge_count; i++) {
      uint32_t src = es[i].x;
      uint32_t dest = es[i].y;
      add_edge_update_fast(src,dest,1,task_id+2*i);
    });
#if ENABLE_PMA_LOCK
    node_lock.unlock_shared(0);
#endif
  } else { // large merge
    printf("using large merge\n");
    add_edge_batch_update_no_val_parallel(es, edge_count);
  }
}

// large merge
template <typename E>
void inline Block<E>::remove_edge_batch_update_no_val_parallel(pair_uint *es, uint64_t edge_count) {
  printf(" RM BATCH NOT WORKING FOR NOW \n");
  return;

  uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2*edge_count);
  // node_lock.lock_shared(0);

  //printf("\nlarge merge in batch\n");
  grab_all_locks(task_id, true, GENERAL);
  //std::sort(es, es + edge_count, sort_helper_x);
  //printf("starting sort\n");
  // integerSort_y((pair_els*)es, edge_count, get_n());
  // integerSort_x((pair_els*)es, edge_count, get_n());
  //printf("finished sort\n");
  //for (int i = 0; i < edge_count; i++) {
  //  printf("%u, %u\n", es[i].x, es[i].y);
  //}

  uint32_t num_workers = ParallelTools::getWorkers()*5;
  uint64_t new_size = edges.N;

  uint32_t* dests = (uint32_t*) edges.dests;
  uint32_t* vals = (uint32_t*) edges.vals;
  uint32_t* new_vals = (uint32_t*) malloc(new_size * sizeof(uint32_t));
  if (new_vals == NULL) {
    printf("bad alloc for new_vals\n");
    exit(-1);
  }
  uint32_t* new_dests = (uint32_t*) malloc(new_size * sizeof(uint32_t));
  if (new_dests == NULL) {
    printf("bad alloc for new_dests\n");
    exit(-1);
  }
  std::vector<uint64_t> counts(num_workers+1);
  counts[0] = 0;
  std::vector<uint64_t> output_starts(num_workers);
  uint32_t increment_batch = edge_count / num_workers;
  //printf("starting merge\n");
  temp_pfor(uint32_t i = 0; i < num_workers; i++) {

    uint64_t batch_start = increment_batch * i;
    uint64_t batch_end = std::min(batch_start + increment_batch, (uint64_t) edge_count);
    if (i == num_workers-1) {
      batch_end = edge_count;
    }

    uint64_t pma_start = 0;
    if (i > 0) {
      pma_start = binary_search(&edges, es[batch_start].y, 0, nodes[es[batch_start].x].beginning + 1, nodes[es[batch_start].x].end);
    }
    uint64_t pma_end = edges.N;
    if (i < num_workers - 1) {
      pma_end = binary_search(&edges, es[batch_end].y, 0, nodes[es[batch_end].x].beginning + 1, nodes[es[batch_end].x].end);
    }

    uint64_t output_start = pma_start;
    output_starts[i] = output_start;
    counts[i+1] = do_exclude(new_dests, new_vals, output_start, es, batch_start, batch_end, dests, vals, pma_start, pma_end, edges.loglogN, get_n());
  }
  //printf("finished merge\n");
  // print_array(0);
  // for (auto it : output_starts) {
  //   printf("%lu\n", it);
  // }

  // prefix sum
  for(uint32_t i = 1; i < num_workers + 1; i++) {
    counts[i] += counts[i-1];
  }

  // should be nnz
  uint64_t result_idx = counts[num_workers];

  uint64_t final_size = new_size;
  double cur_density = (double) result_idx / final_size;
  while (cur_density < .25) {
    final_size /= 2;
    cur_density = (double) result_idx / final_size;
  }
  while (cur_density > .75) {
    final_size *= 2;
    cur_density = (double) result_idx / final_size;
  }
 // assert(cur_density >= .25 && cur_density <= .75);
  // printf("new size %lu, final_size %lu, nnz %lu\n", new_size, final_size, result_idx);
  edges.N = final_size;
  edges.loglogN = bsr_word(bsr_word(final_size) + 1);
  edges.logN = 1 << edges.loglogN;
  edges.mask_for_leaf = ~ (edges.logN - 1);
  edges.density_limit = ((double) edges.logN - 1) / edges.logN;
  edges.H = bsr_word(new_size / edges.logN);
  for(unsigned int i = 0; i <= edges.H; i++) {
    lower_density_bound[i] = density_bound(&edges, i).x;
    upper_density_bound[i] = density_bound(&edges, i).y;
  }
  // allocate space for dense
  free((void*)edges.dests);
  free((void*)edges.vals);
  uint32_t* dense_vals = (uint32_t*) malloc(result_idx * sizeof(uint32_t));

  if (dense_vals == NULL) {
    printf("bad alloc for dense_vals\n");
    exit(-1);
  }

  uint32_t* dense_dests = (uint32_t*) malloc(result_idx * sizeof(uint32_t));
  if (dense_dests == NULL) {
    printf("bad alloc for dense_dests\n");
    exit(-1);
  }

  // copy into dense array
  //printf("starting make dense\n");
  temp_pfor(uint32_t i = 0; i < num_workers; i++) {
    uint32_t start_output_idx = counts[i];
    uint32_t start_input_idx = output_starts[i];
    uint32_t end_input_idx = start_input_idx + (counts[i+1] - counts[i]);
    for(uint32_t j = start_input_idx; j < end_input_idx; j++) {
      if (new_dests[j] != NULL_VAL) {
        dense_vals[start_output_idx] = new_vals[j];
        dense_dests[start_output_idx] = new_dests[j];
        start_output_idx++;
      }
    }
  }

  free((void*)new_dests);
  free((void*)new_vals);

  uint32_t* final_vals = (uint32_t*) malloc(final_size * sizeof(uint32_t));
  uint32_t* final_dests = (uint32_t*) malloc(final_size * sizeof(uint32_t));

  edges.dests = final_dests;
  edges.vals = final_vals;
  uint64_t num_leaves = final_size >> edges.loglogN;
  uint64_t count_per_leaf = result_idx / num_leaves;
  uint64_t extra = result_idx % num_leaves;
  //printf("num_leaves = %lu, count_per_leaf = %lu, extra = %lu\n", num_leaves, count_per_leaf, extra);
  //printf("starting redistribute\n");
  temp_pfor(uint64_t i = 0; i < num_leaves; i++) {
    uint64_t count_for_leaf = count_per_leaf + (i < extra);
    uint64_t out_idx_start = i << edges.loglogN;
    uint64_t in_idx_start = count_per_leaf * i + min(i, extra);
    uint64_t out_idx = out_idx_start;
    //printf("%lu, %lu, %lu, %lu\n", count_for_leaf, out_idx_start, in_idx_start, out_idx);
    for(uint64_t j = in_idx_start; j < in_idx_start + count_for_leaf; j++) {
      final_vals[out_idx_start] = dense_vals[j];
      out_idx_start++;
    }
    for (uint64_t j = out_idx_start; j < (i+1) << edges.loglogN; j++) {
      final_vals[j] = 0;
    }
    for(uint64_t j = in_idx_start; j < in_idx_start + count_for_leaf; j++) {
      final_dests[out_idx] = dense_dests[j];
      if (final_dests[out_idx] == SENT_VAL) {
        uint64_t node_idx = final_vals[out_idx];
        fix_sentinel(node_idx, out_idx);
      }
      out_idx++;
    }
    for (uint64_t j = out_idx; j < (i+1) << edges.loglogN; j++) {
      final_dests[j] = NULL_VAL;
    }
  }

  free((void*)dense_dests);
  free((void*)dense_vals);
  //print_array(1);
  //check_sentinals();
  release_all_locks(task_id, true, GENERAL);
  // node_lock.unlock_shared(0);
  //printf("after batch insert\n");
  //print_array(0);
}

// do merge or not based on size of batch
template <typename E>
void inline Block<E>::remove_edge_batch_wrapper(pair_uint *es, uint64_t edge_count, int64_t threshold) {
  // default
  if (threshold < 0) {
    if (edges.N > UINT32_MAX) {
      uint64_t top = (uint64_t)edges.N >> 32;
      threshold = edges.N / (32+bsr_word(top));
    } else if (edges.N == UINT32_MAX) {
      threshold = edges.N / 32;
    } else {
      threshold = edges.N / bsr_word(edges.N);
    }
  }

  //printf("threshold%lu, batch size %lu\n", threshold, edge_count);

  // actual inserts into PMA
  if (true || edge_count < (uint64_t) threshold*2) {
  #if ENABLE_PMA_LOCK
    node_lock.lock_shared(0);
  #endif
    uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2*edge_count);
    // temp_pfor (uint32_t i = 0; i < edge_count; i++) {
    parlay::parallel_for (0, edge_count, [&](uint64_t i) {
      uint32_t src = es[i].x;
      uint32_t dest = es[i].y;
      remove_edge_fast(src,dest,task_id+2*i);
    });
#if ENABLE_PMA_LOCK
    node_lock.unlock_shared(0);
#endif
  } else { // large merge
    printf("using large merge\n");
    remove_edge_batch_update_no_val_parallel(es, edge_count);
  }
}

template <typename E>
bool inline Block<E>::remove_edge(uint32_t src, uint32_t dest) {
  //printf(" trying to remove src = %d, dest = %d\n", src,dest);
  uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2);
  #if ENABLE_PMA_LOCK == 1
 // assert(check_no_locks_for_me(task_id));

  node_lock.lock_shared(task_id);
  pair_int held_locks = grab_locks_for_leaf_with_resets(task_id, src);
 // assert(nodes[src].lock.i_own_lock(task_id));
  #endif
  BlockState<E> node = move(nodes[src]);

  
  // edges.list_lock.lock_shared();
  //uint32_t node_begin = node.beginning;
  //uint32_t node_end = node.end;
  // printf("looking in region %u, %u by worker %lu\n", node.beginning + 1, node.end, get_worker_num());
  uint_t loc_to_remove =
      binary_search(&edges, dest, 0, node.beginning + 1, node.end);
  if (edges.dests[loc_to_remove] != dest) {
    //if the edge isn't there
    //printf("not removed\n");
    #if ENABLE_PMA_LOCK == 1
    release_locks_in_range(task_id, held_locks);
    node_lock.unlock_shared(task_id);
    #endif
    return false;
  }
  //printf("removed\n");
  __sync_fetch_and_add(&nodes[src].degree,-1);
  #if ENABLE_PMA_LOCK == 1
  pair_int needed_locks = which_locks_in_range(find_leaf(&edges, loc_to_remove), edges.logN, src);
  for (uint32_t i = held_locks.x; i < needed_locks.x; i++) {
    nodes[i].lock.unlock(task_id, GENERAL);
    held_locks.x = i+1;
  }
  for (uint32_t i = needed_locks.y+1; i <= held_locks.y; i++) {
    nodes[i].lock.unlock(task_id, GENERAL);
    
  }
  if (needed_locks.y+1 <= held_locks.y) {
    held_locks.y = needed_locks.y;
  }
  // print_array();
  //printf("loc_to_add: %u by worker %lu\n", loc_to_add, get_worker_num());
  // printf("src: %d, dest: %d by worker %lu\n", src, dest, get_worker_num());
  // print_array();

  
 // assert(nodes[src].lock.i_own_lock(task_id));
 // assert(check_every_lock_in_leaf(task_id, loc_to_remove));
  /*
  if (!check_no_full_leaves(&edges, find_leaf(&edges, loc_to_add), edges.logN)) {
    printf("worker %lu is trying to insert into a full leaf\n", get_worker_num());
    print_array(get_worker_num());
  }
  */
 // assert(check_no_full_leaves(&edges, find_leaf(&edges, loc_to_remove), edges.logN));
  #endif

  remove(task_id, loc_to_remove, dest, src
    #if ENABLE_PMA_LOCK == 1
    , held_locks
    #endif
    );
  //printf("worker %lu done\n", get_worker_num());
  // edges.list_lock.unlock_shared();
  //print_array();
  #if ENABLE_PMA_LOCK == 1
  node_lock.unlock_shared(task_id);
 // assert(check_no_locks_for_me(task_id));
  #endif
  return true;
}

template <typename E>
void inline Block<E>::remove_edge_fast(uint32_t src, uint32_t dest, uint64_t task_id) {
  //printf(" trying to remove src = %d, dest = %d\n", src,dest);
  #if ENABLE_PMA_LOCK == 1
  pair_int held_locks = grab_locks_for_leaf_with_resets(task_id, src);
  #endif
  BlockState<E> node = move(nodes[src]);

  
  // edges.list_lock.lock_shared();
  //uint32_t node_begin = node.beginning;
  //uint32_t node_end = node.end;
  // printf("looking in region %u, %u by worker %lu\n", node.beginning + 1, node.end, get_worker_num());
  uint_t loc_to_remove =
      binary_search(&edges, dest, 0, node.beginning + 1, node.end);
  if (edges.dests[loc_to_remove] != dest) {
    //if the edge isn't there
    //printf("not removed\n");
    #if ENABLE_PMA_LOCK == 1
    release_locks_in_range(task_id, held_locks);
    #endif
    return;
  }
  //printf("removed\n");
  __sync_fetch_and_add(&nodes[src].degree,-1);
  #if ENABLE_PMA_LOCK == 1
  pair_int needed_locks = which_locks_in_range(find_leaf(&edges, loc_to_remove), edges.logN, src);
  for (uint32_t i = held_locks.x; i < needed_locks.x; i++) {
    nodes[i].lock.unlock(task_id, GENERAL);
    held_locks.x = i+1;
  }
  for (uint32_t i = needed_locks.y+1; i <= held_locks.y; i++) {
    nodes[i].lock.unlock(task_id, GENERAL);
    
  }
  if (needed_locks.y+1 <= held_locks.y) {
    held_locks.y = needed_locks.y;
  }
  // print_array();
  //printf("loc_to_add: %u by worker %lu\n", loc_to_add, get_worker_num());
  // printf("src: %d, dest: %d by worker %lu\n", src, dest, get_worker_num());
  // print_array();

  
 // assert(nodes[src].lock.i_own_lock(task_id));
  /*
  if (!check_no_full_leaves(&edges, find_leaf(&edges, loc_to_add), edges.logN)) {
    printf("worker %lu is trying to insert into a full leaf\n", get_worker_num());
    print_array(get_worker_num());
  }
  */
  #endif
 // assert(check_no_full_leaves(&edges, find_leaf(&edges, loc_to_remove), edges.logN));
  remove(task_id, loc_to_remove, dest, src
   #if ENABLE_PMA_LOCK == 1
    , held_locks
    #endif
    );
  //printf("worker %lu done\n", get_worker_num());
  // edges.list_lock.unlock_shared();
  //print_array();
}

template <typename E>
void inline Block<E>::remove_edge_batch(uint32_t *srcs, uint32_t *dests, uint_t edge_count) {
  uint64_t task_id = __sync_fetch_and_add(&next_task_id, 2*edge_count);
#if ENABLE_PMA_LOCK == 1
  node_lock.lock_shared(0);
  temp_pfor (uint_t i = 0; i < edge_count; i++) {
#else
  for (uint_t i = 0; i < edge_count; i++) {
#endif
    uint32_t src = srcs[i];
    uint32_t dest = dests[i];
    remove_edge_fast(src,dest,task_id+2*i);
  }
#if ENABLE_PMA_LOCK == 1
  node_lock.unlock_shared(0);
#endif
}


template <typename E>
inline Block<E>::Block(uint32_t init_n) {
  next_task_id = 1;
  max_pma.v_id = 0;
  max_pma.v_degree = 0; // TODO
  nodes_size = 0;
  //making sure logN is at least 4
  edges.N = max(2UL << bsr_word(init_n*2), 16UL);
  // printf("%d\n", bsf_word(list->N));
  edges.loglogN = bsr_word(bsr_word(edges.N) + 1);
  edges.logN = (1 << edges.loglogN);
  edges.mask_for_leaf = ~(edges.logN - 1);
 // assert(edges.logN > 0);
  edges.density_limit = ((double) edges.logN - 1)/edges.logN;
  edges.H = bsr_word(edges.N / edges.logN);
  for (uint32_t i = 0; i <= edges.H; i++) {
    upper_density_bound[i] = density_bound(&edges, i).y;
    lower_density_bound[i] = density_bound(&edges, i).x;
  }

  // printf("N = %d, logN = %d, loglogN = %d, H = %d\n", list->N, list->logN,
  // list->loglogN, list->H);
  
  // edges.list_lock.name("listLock");
#if ENABLE_PMA_LOCK == 1
  node_lock.name("nodeLock");  
#endif
  //edges.vals = (uint32_t *)malloc(edges.N * sizeof(*(edges.vals)));
  //edges.dests = (uint32_t *)malloc(edges.N * sizeof(*(edges.dests)));
  edges.vals = (uint32_t *)aligned_alloc(32, edges.N * sizeof(*(edges.vals)));
  edges.dests = (uint32_t *)aligned_alloc(32, edges.N * sizeof(*(edges.dests)));
  temp_pfor (uint_t i = 0; i < edges.N; i++) {
    edges.vals[i] = 0;
    edges.dests[i] = NULL_VAL;
  }
  //TODO might be an issue if we grow it one at a time and let nodes be moved during operation
  // nodes.reserve(init_n);
  for (uint32_t i = 0; i < init_n; i++) {
    add_node();
  }
}

template <typename E>
inline Block<E>::Block(const Block &other) {
  // nodes = other.nodes;
  // nodes = std::vector<BlockState<E>>(other.nodes.begin(), other.nodes.end());
  for (size_t i = 0; i < other.nodes_size; ++i) {
    nodes[i] = other.nodes[i];
  }
  nodes_size = other.nodes_size;
  next_task_id = 1;
  max_pma = other.max_pma;
  edges.N = other.edges.N;
  edges.loglogN = other.edges.loglogN;
  edges.logN = other.edges.logN;
  edges.mask_for_leaf = other.edges.mask_for_leaf;
  edges.density_limit = other.edges.density_limit;
  edges.H = other.edges.H;
  for (uint32_t i = 0; i <= edges.H; i++) {
    upper_density_bound[i] = other.upper_density_bound[i];
    lower_density_bound[i] = other.lower_density_bound[i];

  }
#if ENABLE_PMA_LOCK == 1
  node_lock.name("nodeLock");
#endif
  //edges.vals = (uint32_t *)malloc(edges.N * sizeof(*(edges.vals)));
  edges.vals = (uint32_t *)aligned_alloc(32, edges.N * sizeof(*(edges.vals)));
  memcpy(__builtin_assume_aligned((void *)edges.vals,32), __builtin_assume_aligned((void *)other.edges.vals, 32), edges.N * sizeof(*(edges.vals)));
  //edges.dests = (uint32_t *)malloc(edges.N * sizeof(*(edges.dests)));
  edges.dests = (uint32_t *)aligned_alloc(32, edges.N * sizeof(*(edges.dests)));
  memcpy(__builtin_assume_aligned((void *)edges.dests, 32), __builtin_assume_aligned((void *)other.edges.dests, 32), edges.N * sizeof(*(edges.dests)));
}

//TODO free lock array
template <typename E>
inline Block<E>::~Block() { 
  free((void*)edges.vals);
  edges.vals = nullptr; // 防止重复释放
  free((void*)edges.dests);
  edges.dests = nullptr; // 防止重复释放
}
} // namespace dcsr