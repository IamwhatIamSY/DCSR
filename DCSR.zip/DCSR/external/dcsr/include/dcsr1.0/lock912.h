#include <atomic>
#include <unistd.h>
#include <stdio.h>
#include "util.h"

#pragma once
#define num_tries 1

class LOCK {
public:
  uint32_t x;

  void init();
  void lock();
  bool try_lock();
  void unlock();
  // bool check_unlocked();
  void shared_lock();
  void shared_unlock();
};

inline void LOCK::init() {
  x = 0;
}

// should only be used in sequntial areas
// inline bool LOCK::check_unlocked() {
  // uint32_t lock = x.load(std::memory_order_acquire);
  // return lock == 0;
/// }

inline bool cas (uint32_t *old, uint32_t old_val, uint32_t new_val) {
  return __sync_bool_compare_and_swap(old, old_val, new_val);
}

// exclusive lock
inline void LOCK::lock() {
  bool success = false;
  while(!success) {
    success = cas(&x, 0, 1);
    if (success) {
      break;
    }
  }
}

inline void LOCK::shared_lock() {
  bool success = false;
  while(!success) {
    uint32_t old_x = x;
    if (old_x % 2 == 0) {
      success = cas(&x, old_x, old_x + 2);
      if (success) {
        break;
      }
    }
  }
}

inline void LOCK::shared_unlock() {
  __sync_fetch_and_add(&x, -2);
}

inline bool LOCK::try_lock() {
  bool success = false;
  uint32_t tries = 0;
  while (tries < num_tries) {
    success = cas(&x, 0, 1);
    if (success) { 
      break; 
    }
    tries++;
  }
}

inline void LOCK::unlock() {
  x = 0;
}

