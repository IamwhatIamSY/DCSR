using namespace std;

//#include <immintrin.h>
#pragma once

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <vector>
#include <tuple>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <immintrin.h>
#include <atomic>


#include <stdint.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream> 
#include <string> 

#include "ParallelTools/parallel.h"
#include "ParallelTools/reducer.h"
#include "gbbs/bridge.h"

#include "lock.h"

#include <immintrin.h>
#include <iostream>
#include <iomanip>    

#define temp_pfor for 
namespace SMA_GRAPH {

#if defined(LONG)
typedef uint64_t uint_t;
typedef int64_t int_t;
#define REDISTRIBUTE_PAR_SIZE (UINT64_MAX)
#else
typedef uint32_t uint_t;
typedef int32_t int_t;
#define REDISTRIBUTE_PAR_SIZE (UINT32_MAX)
#endif

#define NULL_VAL (UINT32_MAX)
#define SENT_VAL (UINT32_MAX -1)

// define cell size
#define CELL_SIZE (64)

// define cache line size
#define CELLS_PER_BLOCK (1)

// define the block size, 8 cache lines
#define BLOCK_SIZE (CELLS_PER_BLOCK * CELL_SIZE)

typedef struct _pair_double {
  double x;
  double y;
} pair_double;

typedef struct _node {
  // beginning and end of the associated region in the edge list
  uint_t beginning;     // deleted = max int
  uint_t end;           // end pointer is exclusive
  uint32_t num_neighbors; // number of edgess with this node as source
} node_t;

typedef struct edge_list {
  uint_t N;
  uint32_t BN; // number of items in a blcok
  uint32_t num_blocks; // number of blocks in the dest array
  uint32_t H;
  uint32_t *indices;
  uint32_t *vals;
  uint32_t *dests;

  double density_limit;
} edge_list_t;

class SMA {
public:
  // data members
  edge_list_t edges;
  std::vector<node_t> nodes;

  SMA(uint32_t init_n = 16);
  SMA(SMA &other);
  ~SMA();
  void double_list();
  void half_list();

  void slide_right(uint_t index, uint32_t *vals, uint32_t *dests);
  void slide_left(uint_t index, uint32_t *vals, uint32_t *dests);
  void redistribute(uint_t index, uint64_t len);

  uint_t fix_sentinel(uint32_t node_index, uint_t in);
  void print_array(uint_t index, uint32_t len);
  void print_graph();
  void add_node();
  uint32_t find_block_id(uint_t index);
  
  void build_from_edges(uint32_t *srcs, uint32_t *dests, uint8_t * sma_edges, uint64_t vertex_count, uint64_t edge_count, uint32_t* additional_degrees);
  uint32_t binary_find_block(uint32_t begin_id, uint32_t end_id, uint32_t dest);
  uint32_t binary_search(uint32_t elem, uint32_t start, uint32_t end);
  void add_edge_batch_wrapper(pair_uint *es, uint64_t edge_count);
  bool add_edge_update_fast(uint32_t src, uint32_t dest, uint32_t value);
  void remove_edge_batch_wrapper(pair_uint *es, uint64_t edge_count);
  void remove_edge_fast(uint32_t src, uint32_t dest);

  void insert(uint_t index, uint32_t elem_dest, uint32_t elem_value, uint32_t src);
  void remove(uint_t index, uint32_t elem_dest, uint32_t src);

  uint64_t get_size();
  uint64_t get_n();
  void clear();

  uint32_t num_neighbors(uint32_t node) {
    return nodes[node].num_neighbors;
  }

  uint64_t num_edges() {
    uint64_t num = 0;
    for (uint64_t i = 0; i < get_n(); i++) {
      num += num_neighbors(i);
    }
    return num;
  }
};

inline uint32_t SMA::find_block_id(uint_t index) { return (index / edges.BN); }

// same as find_leaf, but does it for any level in the tree
// index: index in array
// len: length of sub-level.
static inline uint_t find_node(uint_t index, uint_t len) { return (index / len) * len; }

void inline SMA::clear() {
  printf("clear called\n");
  
  free((void*)edges.vals);
  free((void*)edges.dests);
  free((void*)edges.indices);
  edges.N = 0;
  edges.num_blocks = 0;
  edges.H = 0;
}

uint64_t inline SMA::get_n() {
  uint64_t size = nodes.size();
  return size;
}

uint64_t inline SMA::get_size() {
  uint64_t size = nodes.size() * sizeof(node_t);
  size += sizeof(SMA);
  size += (uint64_t)edges.N * sizeof(uint32_t) * 2;
  size += (uint64_t)edges.num_blocks * sizeof(uint32_t);
  return size;
}

inline void SMA::print_array(uint_t index, uint32_t len) {
  for (uint_t i = index; i < index + len; i++) {
#if defined(LONG)
    printf("(%lu, %u) ", i, edges.dests[i]);
#else
    printf("(%u, %u) ", i, edges.dests[i]);
#endif
  }
  printf("\n");
}

uint_t inline get_density_count(edge_list_t *list, uint_t index, uint_t len) {
  // fater without paralleliszation since it gets properly vectorized
  uint32_t * dests = (uint32_t *) list->dests;
  uint_t full = 0;
  for (uint_t i = index; i < index+len; i+=4) {
      uint32_t add = (dests[i]!=NULL_VAL) + (dests[i+1]!=NULL_VAL) + (dests[i+2]!=NULL_VAL) + (dests[i+3]!=NULL_VAL);
      //__sync_fetch_and_add(&full, add);
      full+=add;
  }
  return full;
}

// get density of a node
double inline get_density(edge_list_t *list, uint_t index, uint_t len) {
  double full_d = (double)get_density_count(list, index, len);
  return full_d / len;
}

// height of this node in the tree
uint32_t inline get_depth(edge_list_t *list, uint_t len) { return bsr_word(list->N / len); }

// when adjusting the list size, make sure you're still in the
// density bound
pair_double inline density_bound(edge_list_t *list, uint32_t depth) {
  pair_double pair;

  // between 1/4 and 1/2
  // pair.x = 1.0/2.0 - (( .25*depth)/list->H);
  // between 1/8 and 1/4
  pair.x = 1.0 / 4.0 - ((.125 * depth) / list->H);
  pair.y = 3.0 / 4.0 + ((.25 * depth) / list->H);
  if (pair.y > list->density_limit) {
    pair.y = list->density_limit-.001;
  }
  return pair;
}

//TODO make it so the first element is known to always be the first element and don't special case it so much
//returns where me have to start checking for sentinals again
// ths is just the start + the degree so we can run some fasts paths
uint_t inline SMA::fix_sentinel(uint32_t node_index, uint_t in) {
  // we know the first sentinal will never move so we just ignore it
  assert(node_index > 0);
  nodes[node_index - 1].end = in;

  nodes[node_index].beginning = in;
  if (node_index == nodes.size() - 1) {
    nodes[node_index].end = edges.N - 1;
  }
  return nodes[node_index].beginning + nodes[node_index].num_neighbors;
}


// Evenly redistribute elements in the ofm, given a range to look into
// index: starting position in ofm structure
// len: area to redistribute
inline void SMA::redistribute(uint_t index, uint_t len) {
  uint32_t *space_vals = (uint32_t *)aligned_alloc(32, len * sizeof(uint32_t));
  uint32_t *space_dests = (uint32_t *)aligned_alloc(32, len * sizeof(uint32_t));
  uint32_t *vals = (uint32_t *) edges.vals;
  uint32_t *dests = (uint32_t *) edges.dests;
  
  uint_t j = 0;
  for (uint_t i = index; i < index + len; i += 16) {
    for (uint_t k = i; k < i + 16; k++) {
      space_vals[j] = vals[k];
      space_dests[j] = dests[k];
      // counting non-null edges
      j += (space_dests[j] != NULL_VAL);
    }
    memset (__builtin_assume_aligned((void*)&vals[i], 32), NULL_VAL, 16*sizeof(uint32_t));
    memset (__builtin_assume_aligned((void*)&dests[i], 32), NULL_VAL, 16*sizeof(uint32_t));
  }
  
  uint_t num_b = len / edges.BN;
  uint_t count_per_block = j / num_b;
  uint_t extra = j % num_b;
  __builtin_prefetch ((void *)&nodes, 0, 3);

  for (uint_t i = 0; i < num_b; i++) {
    uint_t count_for_block = count_per_block + (i < extra);
    uint_t in = index + (edges.BN * i);
    uint_t j2 = count_per_block*i + min(i,extra);
    uint_t j3 = j2;
    memcpy(__builtin_assume_aligned((void*)&vals[in], 64), (void*)&space_vals[j2], count_for_block*sizeof(uint32_t));
    for (uint_t k = in; k < count_for_block + in; k++) {
      dests[k] = space_dests[j3];
      if (dests[k] == SENT_VAL) {
        uint32_t node_index = vals[k];
        fix_sentinel(node_index, k);
      }
      j3++;
    }
    
    uint32_t block_id = in / edges.BN;
    edges.indices[block_id] = dests[in];
  }

  free(space_dests);
  free(space_vals);
}

//TODO pass in subcounts and do redistibute_par when big
void inline SMA::double_list() {
  uint64_t new_N = edges.N * 2;
  edges.N = new_N;
  edges.num_blocks *= 2;
  edges.H++;

  uint32_t *new_dests = (uint32_t *)aligned_alloc(32, new_N * sizeof(*(edges.dests)));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(32, new_N * sizeof(*(edges.vals)));
  uint32_t *new_indices = (uint32_t *)aligned_alloc(32, edges.num_blocks * sizeof(*(edges.indices)));
  uint32_t * vals = (uint32_t *)edges.vals;
  uint32_t * dests = (uint32_t *)edges.dests;
  uint32_t * indices = (uint32_t *)edges.indices;
  std::memcpy(new_vals, vals, (new_N / 2) * sizeof(uint32_t));
  std::memcpy(new_dests, dests, (new_N / 2) * sizeof(uint32_t));

  temp_pfor (uint_t i = new_N / 2; i < new_N; i++) {
    new_vals[i] = 0; // setting second half to null
    new_dests[i] = NULL_VAL; // setting second half to null
  }

  temp_pfor (uint32_t i = 0; i < edges.num_blocks; i++) {
    new_indices[i] = NULL_VAL;
  }

  free((void*)edges.vals);
  edges.vals = new_vals;
  free((void*)edges.dests);
  edges.dests = new_dests;
  free((void*)edges.indices);
  edges.indices = new_indices;

  assert(edges.dests != NULL && edges.vals != NULL);
  
  redistribute(0, edges.N);
}

void inline SMA::half_list() {
  uint64_t new_N = edges.N / 2;
  edges.num_blocks /= 2;
  edges.H--;

  uint32_t *new_dests = (uint32_t *)aligned_alloc(32, new_N * sizeof(*(edges.dests)));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(32, new_N * sizeof(*(edges.vals)));
  uint32_t *new_indices = (uint32_t *)aligned_alloc(32, edges.num_blocks * sizeof(*(edges.indices)));
  uint32_t * vals = (uint32_t *)edges.vals;
  uint32_t * dests = (uint32_t *)edges.dests;
  uint32_t * indices = (uint32_t *)edges.indices;

  assert(edges.dests != NULL && edges.vals != NULL);
  
    uint_t start = 0;
    for (uint_t i = 0; i < edges.N; i++) {
      if (dests[i] != NULL_VAL) {
        new_vals[start] = vals[i];
        new_dests[start] = dests[i];
        start += 1;
      }
    }

		for (uint_t i = start; i < new_N; i++) {
			new_vals[i] = 0; 
      new_dests[i] = NULL_VAL;
		}
    
    for (uint_t i = 0; i < edges.num_blocks; i++) {
      new_indices[i] = NULL_VAL;
    }

    free(vals);
    free(dests);
    free(indices);
    edges.vals = new_vals;
    edges.dests = new_dests;
    edges.indices = new_indices;
    edges.N = new_N;
    redistribute(0, new_N);
}


// index is the beginning of the sequence that you want to slide right.
void inline SMA::slide_right(uint_t index, uint32_t *vals, uint32_t *dests) {
  uint32_t el_val = vals[index];
  uint32_t el_dest = dests[index];
  dests[index] = NULL_VAL;
  vals[index] = 0;

  index++;
  while (index < edges.N && (dests[index] != NULL_VAL)) {
    uint32_t temp_val = vals[index];
    uint32_t temp_dest = dests[index];
    vals[index] = el_val;
    dests[index] = el_dest;
    if (el_dest == SENT_VAL) {
      // fixing pointer of node that goes to this sentinel
      uint32_t node_index = el_val;
      fix_sentinel(node_index, index);
    }
    el_val = temp_val;
    el_dest = temp_dest;
    index++;
  }

  if (el_dest == SENT_VAL) {
    // fixing pointer of node that goes to this sentinel
    uint32_t node_index = el_val;
    fix_sentinel(node_index, index);
  }

  vals[index] = el_val;
  dests[index] = el_dest;
}


// index is the beginning of the sequence that you want to slide left.
// the element we start at will be deleted
void inline SMA::slide_left(uint_t index, uint32_t *vals, uint32_t *dests) {
  while (index+1 < edges.N) {
    uint32_t temp_val = vals[index+1];
    uint32_t temp_dest = dests[index+1];
    vals[index] = temp_val;
    dests[index] = temp_dest;
    if (temp_dest == SENT_VAL) {
      // fixing pointer of node that goes to this sentinel
      uint32_t node_index = temp_val;
      fix_sentinel(node_index, index);
    }
    if (dests[index] == NULL_VAL) {
      break;
    }
    index++;
  }

  assert(index != edges.N);
}

// important: make sure start, end don't include sentinels
// returns the index of the smallest element bigger than you in the range
// [start, end)
// if no such element is found, returns end (because insert shifts everything to
// the right)
inline uint32_t SMA::binary_search(uint32_t elem, uint32_t start, uint32_t end) {
  uint32_t *dests = (uint32_t *) edges.dests;

  while (start + 1 < end) {
    uint32_t mid = (start + end) / 2;
    __builtin_prefetch ((void *)&dests[mid], 0, 3);
    __builtin_prefetch ((void *)&dests[(mid + end)/2], 0, 3);
    __builtin_prefetch ((void *)&dests[(start + mid)/2], 0, 3);

    uint32_t item = dests[mid];
    uint32_t change = 1;
    uint32_t check = mid;

    bool flag = true;
    while ((item == NULL_VAL) && flag) {
      flag = false;
      check = mid + change;
      if (check < end) {
        flag = true;
        if (check <= end) {
          item = dests[check];
          if (item != NULL_VAL) {
            break;
          } else if (check == end) {
            break;
          }
        }
      }
      check = mid - change;
      if (check >= start) {
        flag = true;
        item = dests[check];
      }
      change++;
    }

    if ((item == NULL_VAL) || start == check || end == check) {
      if ((item != NULL_VAL) && start == check && elem <= item) {
        return check;
      }
      return mid;
    }

    // if we found it, return
    if (elem == item) {
      return check;
    } else if (elem < item) {
      end =
          check; // if the searched for item is less than current item, set end
    } else {
      start = check;
      // otherwise, searched for item is more than current and we set start
    }
  }
  if (end < start) {
    start = end;
  }

  if (elem <= dests[start] && (dests[start] != NULL_VAL)) {
    return start;
  }
  return end;
}

// insert elem at index
// and releases it when it is done with it
void inline SMA::insert(uint_t index, uint32_t elem_dest, uint32_t elem_val, uint32_t src) {
  uint32_t level = edges.H;
  uint_t len = edges.BN;

  uint32_t * vals = (uint32_t *) edges.vals;
  uint32_t * dests = (uint32_t *) edges.dests;
  // always deposit on the left
  if (dests[index] == NULL_VAL) {
    // printf("added to empty\n");
    vals[index] = elem_val;
    dests[index] = elem_dest;

  } else {
    assert(index < edges.N - 1);
    // if the edge already exists in the graph, update its value
    // do not make another edge
    if ((elem_dest != SENT_VAL) && dests[index] == elem_dest) {
      vals[index] = elem_val;
      return;
    } else {
      slide_right(index, vals, dests);
      vals[index] = elem_val;
      dests[index] = elem_dest;
    }
  }
  
  uint_t node_index = find_node(index, len);
  double density = get_density(&edges, node_index, len);
  double density_b = density_bound(&edges, level).y;

  // while density too high, go up the implicit tree
  // go up to the biggest node above the density bound
  while(density >= density_b) {
    len *= 2;
    if (len <= edges.N) {
      level--;
      node_index = find_node(node_index, len);
      density = get_density(&edges, node_index, len);
      density_b = density_bound(&edges, level).y;
    } else {
      // if you reach the root, double the list
      double_list();
      return;
    }
  }

  if (len > edges.BN) {
    redistribute(node_index, len); 
  }
  return;
}

// remove elem at index
// and releases it when it is done with it
void inline SMA::remove(uint_t index, uint32_t elem_dest, uint32_t src) {
  uint32_t level = edges.H;
  uint_t len = edges.BN;

  uint32_t * vals = (uint32_t *) edges.vals;
  uint32_t * dests = (uint32_t *) edges.dests;
  // always deposit on the left
  assert(index < edges.N - 1);
  // if the edge already exists in the graph, update its value
  // do not make another edge
  slide_left(index, vals, dests);

  uint_t node_index = find_node(index, len);
  double density = get_density(&edges, node_index, len);
  double density_b = density_bound(&edges, level).x;

  // while density too high, go up the implicit tree
  // go up to the biggest node above the density bound
  //printf("node_index = %d, desnsity = %f, density bound = %f\n", node_index, density, density_b.y);
  while (density <= density_b) {
    //printf("node_index = %d, desnsity = %f, density bound = %f, len = %d, worker = %lu\n", node_index, density, density_b.y, len, get_worker_num());
    len *= 2;
    if (len <= edges.N) {
      level--;
      node_index = find_node(node_index, len);
      density = get_density(&edges, node_index, len);
      density_b = density_bound(&edges, level).x;
    } else {
      half_list();
      return;
    }
  }

  if(len > edges.BN) { 
    redistribute(node_index, len);
  }

  return;
}

void inline SMA::print_graph() {
  uint32_t num_vertices = nodes.size();
  for (uint32_t i = 0; i < num_vertices; i++) {
    uint32_t matrix_index = 0;

    for (uint_t j = nodes[i].beginning + 1; j < nodes[i].end; j++) {
      if (edges.dests[j]!=NULL_VAL) {
        while (matrix_index < edges.dests[j]) {
          printf("000 ");
          matrix_index++;
        }
        printf("%03d ", edges.vals[j]);
        matrix_index++;
      }
    }
    for (uint32_t j = matrix_index; j < num_vertices; j++) {
      printf("000 ");
    }
    printf("\n");
  }
}

// add a node to the graph
void inline SMA::add_node() {
  node_t node;
  uint32_t len = nodes.size();
  node.beginning = 0;
  node.end = 0;
  node.num_neighbors = 0;
  nodes.push_back(node);
}

inline uint32_t SMA::binary_find_block(uint32_t begin_id, uint32_t end_id, uint32_t dest) {
    uint32_t l = begin_id + 1, r = end_id, ans = end_id + 1;
    while (l <= r) {
        uint32_t mid = l + (r - l) / 2;
        uint32_t x = edges.indices[mid];
        if (x > dest) {
            ans = mid;
            r = mid - 1;
        } else {
            l = mid + 1;
        }
    }
    if (ans <= end_id)
        return ans - 1;
    else
        return end_id;
}

bool inline SMA::add_edge_update_fast(uint32_t src, uint32_t dest, uint32_t value) {
    __builtin_prefetch(&nodes[src]);
    if (value != 0) {
      node_t node = nodes[src];
      uint_t loc_to_add;
      
      // loc_to_add =
          // binary_search(dest, node.beginning + 1, node.end);
      // printf("node begin = %u, node end = %u\n", node.beginning, node.end);
      // loc_to_add = binary_search(dest, node.beginning + 1, node.end);

      uint32_t block_begin = find_block_id(node.beginning);
      uint32_t block_end = find_block_id(node.end);
      uint32_t block_id;

      /* if (block_end == block_begin) {
        loc_to_add = binary_search(dest, node.beginning + 1, node.end);
      } else {
        __builtin_prefetch ((void *)&edges.indices[block_begin], 0, 3);
        block_id = binary_find_block(block_begin, block_end, dest);

        if (block_id != block_end && block_id != block_begin) {
          loc_to_add = binary_search(dest, block_id * edges.BN, (block_id + 1) * edges.BN);
        } else if (block_id == block_begin) {
          loc_to_add = binary_search(dest, node.beginning + 1, (block_id + 1) * edges.BN);
        } else {
          loc_to_add = binary_search(dest, block_id * edges.BN, node.end);
        }
      }*/

    uint32_t left, right;
    if (block_end == block_begin) {
      left = node.beginning + 1;
      right = node.end;
    } else {
      __builtin_prefetch((void *)&edges.indices[block_begin], 0, 3);
      block_id = binary_find_block(block_begin, block_end, dest);

      if (block_id == block_begin) {
        left = node.beginning + 1;
        right = (block_id + 1) * edges.BN;
      } else if (block_id == block_end) {
        left = block_id * edges.BN;
        right = node.end;
      } else {
        left = block_id * edges.BN;
        right = (block_id + 1) * edges.BN;
      }
    }

    loc_to_add = binary_search(dest, left, right);

      
      // if (loc_to_add != loc_to_add1) {
        // printf("error: %u, %u, %u, %u, %u, %u\n", src, dest, loc_to_add, loc_to_add1, edges.dests[loc_to_add], edges.dests[loc_to_add1]);
        // print_array(node.beginning + 1, node.end - node.beginning);
      // }
      
      // if (block_id > edges.N) {
      // if (leaf_id != leaf_id1) {
        // printf("error \n");
      // }

      if (loc_to_add > edges.N) {
        printf("error \n");
      }

      /* if (edges.dests[loc_to_add] == dest) {
        edges.vals[loc_to_add] = value;
        return false;
      }

      __sync_fetch_and_add(&nodes[src].num_neighbors,1);
      insert(loc_to_add, e.dest, e.value, src); */
      return true;
    }
  return false;
}

// batch delete exclude merge
void inline SMA::build_from_edges(uint32_t *srcs, uint32_t *dests, uint8_t * sma_edges, uint64_t vertex_count, uint64_t edge_count, uint32_t* additional_degrees) {
  // step 1 : build a CSR
  uint_t* vertex_array = (uint_t*)calloc(vertex_count, sizeof(uint_t)); 
  uint64_t edges_for_sma = 0;
  for(uint64_t i = 0; i < edge_count; i++) {
    if(sma_edges[i]) {
      uint32_t s = srcs[i];
      additional_degrees[s]++;
      vertex_array[s]++;
      edges_for_sma++;
    }
  }

  printf("build from edges: edges for sma = %u\n", edges_for_sma);
  nodes[0].num_neighbors = additional_degrees[0];

  // do prefix sum to get top level of CSR into vertex_array
  for(uint32_t i = 1; i < vertex_count; i++) {
    vertex_array[i] += vertex_array[i-1];
    nodes[i].num_neighbors = additional_degrees[i];
  }

  // and get CSR edge array into sma_edge_array
  uint32_t* sma_edge_array = (uint32_t*)malloc(edges_for_sma * sizeof(uint32_t));
  uint64_t sma_edges_so_far = 0;
  for(uint64_t i = 0; i < edge_count; i++) {
    if (sma_edges[i]) {
      sma_edge_array[sma_edges_so_far] = dests[i];
      sma_edges_so_far++;
    }
  } 
  
  uint_t num_elts = vertex_count + edges_for_sma;

  while (edges.N < num_elts) { edges.N *= 2; }
  if (edges.N < edges.BN) {edges.N = edges.BN;}
  edges.num_blocks = edges.N / edges.BN;
  edges.H = bsr_word(edges.num_blocks);
  edges.density_limit = ((double) edges.BN - 1) / edges.BN;

  uint32_t *space_vals = (uint32_t *)aligned_alloc(64, num_elts * sizeof(*(edges.vals)));
  uint32_t *space_dests = (uint32_t *)aligned_alloc(64, num_elts * sizeof(*(edges.dests)));
  
  // TODO: can also make this parallel
  uint64_t position_so_far = 0;
  for(uint64_t i = 0; i < vertex_count; i++) {
    // first, write the sentinel
    if (i == 0) {
      space_dests[position_so_far] = 0;
      space_vals[position_so_far] = NULL_VAL;
    } else {
      space_dests[position_so_far] = SENT_VAL;
      space_vals[position_so_far] = i;
    }
    position_so_far++;
    // then write the edges
    // printf("sma degree of vertex %u = %u\n", i, additional_degrees[i]);
    for(uint64_t j = 0; j < additional_degrees[i]; j++) {
      if (i == 0) {
        space_dests[position_so_far] = sma_edge_array[j];
      } else {
        space_dests[position_so_far] = sma_edge_array[vertex_array[i - 1] + j];
      }

      space_vals[position_so_far] = 1;
      position_so_far++;
    }
  }
  assert(num_elts == position_so_far);

  // step 3: redistribute
  printf("Creating SMA with N = %u, BN = %u, num_blocks = %u, H = %u\n", edges.N, edges.BN, edges.num_blocks, edges.H);
  uint_t count_per_block = num_elts / edges.num_blocks;
  uint_t extra = num_elts % edges.num_blocks;

  uint32_t *new_dests = (uint32_t *)aligned_alloc(32, edges.N * sizeof(*(edges.dests)));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(32, edges.N * sizeof(*(edges.vals)));
  uint32_t *new_indices = (uint32_t *)aligned_alloc(32, edges.num_blocks * sizeof(uint32_t));

  parlay::parallel_for (0, edges.N, [&](uint64_t i) {
    new_vals[i] = 0; // setting to null
    new_dests[i] = NULL_VAL; // setting to null
  });
  
  parlay::parallel_for(0, edges.num_blocks, [&](uint_t i) {
  // for(uint_t i = 0; i < num_leaves; i++) {
    // how many are going to this leaf
    uint_t count_for_block = count_per_block + (i < extra);
    // start of leaf in output
    uint_t in = i * edges.BN;
    // start in input
    uint_t j2 = count_per_block*i +min(i,extra);
    uint_t j3 = j2;
    for(uint_t k = in; k < count_for_block + in; k++) {
     // assert(j2 < num_items);
      new_vals[k] = space_vals[j2];
      j2++;
    }

    for (uint_t k = in; k < count_for_block + in; k++) {
      new_dests[k] = space_dests[j3];
      if (new_dests[k] == SENT_VAL) {
        // fixing pointer of node that goes to this sentinel
        uint32_t node_index = space_vals[j3];
        fix_sentinel(node_index, k);
      }
      j3++;
    } 

    new_indices[i] = new_dests[in];
  });

  free(space_dests);
  free(space_vals);
  free(vertex_array);
  free(sma_edge_array);

  free((void*)edges.indices);
  edges.indices = new_indices;
  free((void*)edges.vals);
  edges.vals = new_vals;
  free((void*)edges.dests);
  edges.dests = new_dests;
}

// do merge or not based on size of batch
void inline SMA::add_edge_batch_wrapper(pair_uint *es, uint64_t edge_count) {
    // parlay::parallel_for (0, edge_count, [&](uint64_t i) {
    temp_pfor (uint32_t i = 0; i < edge_count; i++) {
      uint32_t src = es[i].x;
      uint32_t dest = es[i].y;
      add_edge_update_fast(src,dest,1);
    // });
    }
}

// do merge or not based on size of batch
void inline SMA::remove_edge_batch_wrapper(pair_uint *es, uint64_t edge_count) {
    parlay::parallel_for (0, edge_count, [&](uint64_t i) {
      uint32_t src = es[i].x;
      uint32_t dest = es[i].y;
      remove_edge_fast(src,dest);
    });
}

void inline SMA::remove_edge_fast(uint32_t src, uint32_t dest) {
  node_t node = nodes[src];

  uint_t loc_to_remove =
      binary_search(dest, node.beginning + 1, node.end);
  if (edges.dests[loc_to_remove] != dest) {
    return;
  }
  __sync_fetch_and_add(&nodes[src].num_neighbors,-1);
  remove(loc_to_remove, dest, src);
}

inline SMA::SMA(uint32_t init_n) {
  //making sure logN is at least 4
  edges.N = max(2UL << bsr_word(init_n*2), 16UL);
  edges.BN = BLOCK_SIZE / sizeof(uint32_t);
  edges.num_blocks = edges.N / edges.BN;
  edges.H = bsr_word(edges.num_blocks);

  edges.indices = (uint32_t *)aligned_alloc(64, edges.num_blocks * sizeof(uint32_t));
  edges.vals = (uint32_t *)aligned_alloc(32, edges.N * sizeof(*(edges.vals)));
  edges.dests = (uint32_t *)aligned_alloc(32, edges.N * sizeof(*(edges.dests)));
  temp_pfor (uint_t i = 0; i < edges.N; i++) {
    edges.vals[i] = 0;
    edges.dests[i] = NULL_VAL;
  }

  temp_pfor (uint_t i = 0; i < edges.num_blocks; i++) {
    edges.indices[i] = NULL_VAL;
  }
  //TODO might be an issue if we grow it one at a time and let nodes be moved during operation
  nodes.reserve(init_n);
  for (uint32_t i = 0; i < init_n; i++) {
    add_node();
  }
}

inline SMA::SMA(SMA &other) {
  nodes = other.nodes;
  edges.N = other.edges.N;
  edges.BN = other.edges.BN;
  edges.num_blocks = other.edges.num_blocks;
  edges.density_limit = other.edges.density_limit;
  edges.H = other.edges.H;

  edges.indices = (uint32_t *)aligned_alloc(32, edges.num_blocks * sizeof(*(edges.indices)));
  memcpy(__builtin_assume_aligned((void *)edges.indices, 32), __builtin_assume_aligned((void *)other.edges.indices, 32), edges.num_blocks * sizeof(*(edges.indices)));

  edges.vals = (uint32_t *)aligned_alloc(32, edges.N * sizeof(*(edges.vals)));
  memcpy(__builtin_assume_aligned((void *)edges.vals,32), __builtin_assume_aligned((void *)other.edges.vals, 32), edges.N * sizeof(*(edges.vals)));

  edges.dests = (uint32_t *)aligned_alloc(32, edges.N * sizeof(*(edges.dests)));
  memcpy(__builtin_assume_aligned((void *)edges.dests, 32), __builtin_assume_aligned((void *)other.edges.dests, 32), edges.N * sizeof(*(edges.dests)));
}

inline SMA::~SMA() { 
  free((void*)edges.vals);
  free((void*)edges.dests);
  free((void*)edges.indices);
}

}
