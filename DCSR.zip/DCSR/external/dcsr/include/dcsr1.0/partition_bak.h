/*
 * =======================================================================================
 *
 *         Author:  Shen Yue, shenyue24b@ict.ac.cn
 *   Organization:  State Key Lab of Processors, Institute of Computing Technology, CAS  
 *
 * =======================================================================================
 */

using namespace std;

#pragma once

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <vector>
#include <tuple>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <immintrin.h>
#include <atomic>
#include <stdint.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream> 
#include <string> 
#include <malloc.h>
#include <cmath>

#include "ParallelTools/parallel.h"
#include "ParallelTools/reducer.h"
#include "gbbs/bridge.h"
#include "lock.h"

#include <cassert>
#include <mutex>
#include <sys/mman.h>

#include <immintrin.h>
#include <iostream>
#include <iomanip>  

namespace SMA_GRAPH {

#if defined(LONG)
  typedef uint64_t uint_t;
#else
  typedef uint32_t uint_t;
#endif

// define the null value in the dest array
#define NULL_VAL (UINT32_MAX)

// define the sentinel value in the dest array
#define SENT_VAL (UINT32_MAX - 1)

// define the lower density bound for the dest array
#define LOWER_DENSITY_BOUND (0.25)

// define the upper density bound for the dest array
#define UPPER_DENSITY_BOUND (0.75)

// define the block size, 16 cache lines
constexpr size_t BLOCK_SIZE = 16 * 64;

typedef struct _node {
  uint_t beginning;
  uint_t end;
  uint32_t degree;
} node_t;

typedef struct _index {
  uint32_t index;
  uint_t non_null_num;
  LOCK block_lock;
  double last_dist_time;
} index_t;

class SMA {
public:
  LOCK sma_lock; // lock for the double or half dest array
  uint32_t num_workers;
  uint_t N; // number of items in the dest array
  uint_t BN; // number of items in a blcok
  uint32_t num_blocks; // number of blocks in the dest array
  uint_t H; // height of the dest array
  index_t *indices; // index array
  uint32_t *dests; // dest array
  uint32_t *vals; // value array
  std::vector<node_t> nodes;
  
  SMA(uint32_t init_n);
  ~SMA();
  void print_graph();
  void print_array(uint_t index, uint32_t len);
  void add_node();
  void clear();
  uint_t get_size();
  uint32_t degree(const uint32_t v) const;
  uint32_t get_num_vertices(void) const;
  uint32_t find_value(uint32_t src, uint32_t dest);
  double getCurrentTimeAsDouble();
  void build_from_edges(uint32_t *edges_srcs, uint32_t *edges_dests, uint8_t *is_edge, uint_t vertex_count, uint_t edge_count, uint32_t *degrees);

  void double_list();
  void half_list();
  void slide_right(uint_t index);
  void slide_left(uint_t index);
  void redistribute(uint_t index, uint32_t len);
  void redistribute_par(uint_t index, uint32_t len);
  void fix_sentinel(uint32_t node_index, uint_t in);
  uint32_t find_block_id(uint32_t index);
  uint32_t find_node(uint32_t index, uint32_t len);
  double get_density(uint32_t block_index, uint32_t num);
  uint32_t binary_search(uint32_t elem, uint32_t start, uint32_t end);
  uint32_t binary_search_todo(uint32_t elem, uint32_t start, uint32_t end);
  uint32_t sequential_search(uint32_t dest, uint32_t start, uint32_t end);
  void grab_locks_range(uint32_t block_index_begin, uint32_t len);
  void release_locks_range(uint32_t block_index_begin, uint32_t len);

  void insert(uint_t index, uint32_t src, uint32_t dest, uint32_t value);
  void block_inner_move(uint_t index);
  pair_uint insert_dist(uint_t index);
  void remove(uint_t index, uint32_t src, uint32_t dest);
  pair_uint remove_dist(uint_t index);
  void add_edge(uint32_t src, uint32_t dest, uint32_t value);
  void remove_edge(uint32_t src, uint32_t dest);
  void add_edge_batch(pair_uint *es, uint_t edge_count);
  void remove_edge_batch(pair_uint *es, uint_t edge_count);
};

inline double SMA::getCurrentTimeAsDouble() {
    auto now = std::chrono::system_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration<double>(duration).count();
}

inline void SMA::print_array(uint_t index, uint32_t len) {
  for (uint_t i = index; i < index + len; i++) {
#if defined(LONG)
    printf("(%lu, %u) ", i, dests[i]);
#else
    printf("(%u, %u) ", i, dests[i]);
#endif
  }
  printf("\n");
}

inline uint32_t SMA::degree(const uint32_t v) const {
  return nodes[v].degree;
}
inline uint32_t SMA::get_num_vertices() const {
  return nodes.size();
}

inline uint32_t SMA::find_block_id(uint32_t index) { return (index / BN); }

inline uint32_t SMA::find_node(uint32_t index, uint32_t len) { return (index / len) * len; }

inline double SMA::get_density(uint32_t block_index, uint32_t num) {
  uint32_t non_null = 0;
  for (uint32_t i = block_index; i < (block_index + num); i++) {
    non_null += indices[i].non_null_num;
  }
  double density = (double)non_null / (double)(num * BN);
  return density;
}

// TODO: optimize this function
// important: make sure start, end don't include sentinels
// returns the index of the smallest element bigger than you in the range
// [start, end) if no such element is found, returns end (because insert shifts
// everything to the right)
inline uint32_t SMA::binary_search(uint32_t elem, uint32_t start, uint32_t end) {
  while (start + 1 < end) {
    uint32_t mid = (start + end) / 2;
    __builtin_prefetch ((void *)&dests[mid], 0, 3);
    __builtin_prefetch ((void *)&dests[(mid + end)/2], 0, 3);
    __builtin_prefetch ((void *)&dests[(start + mid)/2], 0, 3);

    uint32_t item = dests[mid];
    uint32_t change = 1;
    uint32_t check = mid;

    bool flag = true;
    while ((item == NULL_VAL) && flag) {
      flag = false;
      check = mid + change;
      if (check < end) {
        flag = true;
        if (check <= end) {
          item = dests[check];
          if (item != NULL_VAL) {
            break;
          } else if (check == end) {
            break;
          }
        }
      }
      check = mid - change;
      if (check >= start) {
        flag = true;
        item = dests[check];
      }
      change++;
    }

    if ((item == NULL_VAL) || start == check || end == check) {
      if ((item != NULL_VAL) && start == check && elem <= item) {
        return check;
      }
      return mid;
    }

    // if we found it, return
    if (elem == item) {
      return check;
    } else if (elem < item) {
      end =
          check; // if the searched for item is less than current item, set end
    } else {
      start = check;
      // otherwise, searched for item is more than current and we set start
    }
  }
  if (end < start) {
    start = end;
  }

  if (elem <= dests[start] && (dests[start] != NULL_VAL)) {
    return start;
  }
  return end;
}

inline uint32_t SMA::sequential_search(uint32_t dest, uint32_t start, uint32_t end) {
  for (uint32_t i = start; i < end; ++i) {
    if (dests[i] != NULL_VAL && dests[i] >= dest) {
      // printf("sequential search used! loc = %u, start = %u, end = %u \n", i, start, end);
      return i;
    }
  }
  // printf("sequential search used! loc = %u, start = %u, end = %u \n", end, start, end);
  return end;
}

// TODO: a new binary search
inline uint32_t SMA::binary_search_todo(uint32_t elem, uint32_t start, uint32_t end) {

}

inline SMA::SMA(uint32_t init_n) {
  N = 2 << bsr_word(init_n);
  BN = BLOCK_SIZE / sizeof(uint32_t);
  num_blocks = N / BN;
  H = bsr_word(num_blocks);
  sma_lock.init();
  num_workers = 0;
  
  indices = (index_t *)aligned_alloc(64, num_blocks * sizeof(index_t));
  dests = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t)); 
  vals = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));

  for (uint32_t i = 0; i < N; i++) {
    vals[i] = NULL_VAL;
    dests[i] = NULL_VAL;
  }

  for (uint32_t i = 0; i < num_blocks; i++) {
    indices[i].index = NULL_VAL;
    indices[i].non_null_num = 0;
    indices[i].block_lock.init();
    indices[i].last_dist_time = 0.0;
  }

  nodes.reserve(init_n);
  for (uint32_t i = 0; i < init_n; i++) {
    add_node();
  }
}

inline SMA::~SMA() { 
  free(indices);
  free(dests);
  free(vals);  
}

inline void SMA::print_graph() {
  for (uint32_t i = 0; i < nodes.size(); i++) { 
    for (uint32_t j = nodes[i].beginning + 1; j < nodes[i].end; j++) {
        if (dests[j] != NULL_VAL) {
            printf("(%03d, %03d)", i, dests[j]);
        }
    }
    printf("\n");   
  }
}

inline uint_t SMA::get_size() {
  uint_t size = sizeof(SMA);
  size += N * sizeof(uint32_t) * 2;
  size += nodes.size() * sizeof(node_t);
  size += sizeof(index_t) * num_blocks;
  return size;
}

void inline SMA::add_node() {
  node_t node;
  uint32_t len = nodes.size();
  uint32_t sentinel_dest = SENT_VAL;
  uint32_t sentinel_value = len;

  if (len > 0) {
    node.beginning = nodes[len - 1].end;
    node.end = node.beginning + 1;
  } else {
    node.beginning = 0;
    node.end = 1;
  }
  node.degree = 0;
  nodes.push_back(node);
  insert(node.beginning, nodes.size() - 1, sentinel_dest, sentinel_value);
}

inline void SMA::clear() {
  free(indices);
  free(dests);
  free(vals);
  N = 0;
  num_blocks = 0;
  H = 0;
  
  for (uint32_t i = 0; i < nodes.size(); i++) {
    nodes[i].beginning = 0;
    nodes[i].end = 0;
    nodes[i].degree = 0;
  }
}

inline void SMA::fix_sentinel(uint32_t node_index, uint_t in) {
  nodes[node_index].beginning = in;
  if (node_index > 0) {
    nodes[node_index - 1].end = in;
  }
  if (node_index == nodes.size() - 1) {
    nodes[node_index].end = N - 1;
  }
}

inline uint32_t SMA::find_value(uint32_t src, uint32_t elem) {
  node_t node = nodes[src];
  uint32_t block_id;
  uint32_t node_begin_id = find_block_id(node.beginning);
  uint32_t node_end_id = find_block_id(node.end);

  if (node_begin_id == node_end_id) {
    block_id = node_begin_id;
  } else {
    if (elem > indices[node_end_id].index) {
      block_id = node_end_id;
    } else {
      for (uint32_t i = node_begin_id + 1; i <= node_end_id; i++) {
        if (elem < indices[i].index) {
          block_id = i - 1;
          break;
        } 
      }
    }
  }

  uint32_t start = (block_id == node_begin_id) ? node.beginning + 1 : (block_id * BN);
  uint32_t end = (block_id == node_end_id) ? node.end : ((block_id + 1) * BN);
  uint32_t loc = binary_search(elem, start, end);
  if (dests[loc] == elem) {
    return vals[loc];
  } else {
    return 0;
  }
}


inline void SMA::build_from_edges(uint32_t *edges_srcs, uint32_t *edges_dests, uint8_t *is_edge, uint_t vertex_count, uint_t edge_count, uint32_t *degrees) {
  // step 1 : build a CSR offset array
  uint32_t* vertex_array = (uint32_t*)calloc(vertex_count, sizeof(uint32_t));
  uint_t edges_num = 0;
  for (uint_t i = 0; i < edge_count; i++) {
    if (is_edge[i]) {
      uint32_t s = edges_srcs[i];
      degrees[s]++;
      vertex_array[s]++;
      edges_num++;
    }
  }

  // step 2 : build a CSR edges array
  uint32_t* edges_array = (uint32_t*)malloc(edges_num * sizeof(uint32_t));
  uint_t edges_so_far = 0;
  for (uint_t i = 0; i < edge_count; i++) {
    if (is_edge[i]) {
      edges_array[edges_so_far] = edges_dests[i];
      edges_so_far++;
    }
  }
  
  // step 3 : calculate the CSR offset array and get the degree of nodes
  uint_t sma_edges_num = 0;
  nodes[0].degree = degrees[0];
  sma_edges_num += degrees[0];

  for (uint32_t i = 1; i < vertex_count; i++) {
    vertex_array[i] += vertex_array[i-1];
    nodes[i].degree = degrees[i];
    sma_edges_num += degrees[i];
  }

  uint_t num_items = vertex_count + sma_edges_num;
  uint32_t *space_vals = (uint32_t *)aligned_alloc(64, num_items * sizeof(uint32_t));
  uint32_t *space_dests = (uint32_t *)aligned_alloc(64, num_items * sizeof(uint32_t));
  
  uint_t position_so_far = 0;
  for (uint_t i = 0; i < vertex_count; i++) {
    // set the sentinels for all the nodes
    space_dests[position_so_far] = SENT_VAL;
    space_vals[position_so_far] = i;
    position_so_far++;
    // then write the edges, the values are all 1
    for (uint_t j = 0; j < degrees[i]; j++) {
        if (i == 0) {
          space_dests[position_so_far] = edges_array[j];
          space_vals[position_so_far] = 1;
        } else {
          space_dests[position_so_far] = edges_array[vertex_array[i - 1] + j];
          space_vals[position_so_far] = 1;
        }
        position_so_far++;
    }
  }
 // assert(num_items == position_so_far);
  while (N < num_items) { N *= 2; }
  if (N < BN) {N = BN;}
  num_blocks = N / BN;
  H = bsr_word(num_blocks);
  printf("Creating SMA with N = %u, BN = %u, num_blocks = %u, H = %u\n", N, BN, num_blocks, H);
  uint_t count_per_block = num_items / num_blocks;
  uint_t extra = num_items % num_blocks;
  
  uint32_t *new_vals = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  uint32_t *new_dests = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  index_t *new_indices = (index_t *)aligned_alloc(64, num_blocks * sizeof(index_t));

  parlay::parallel_for (0, N, [&](uint_t i) {
    new_vals[i] = NULL_VAL; // setting to null
    new_dests[i] = NULL_VAL; // setting to null
  });
  parlay::parallel_for(0, num_blocks, [&](uint_t i) {
  // uint32_t node_index_last = NULL_VAL;
  // for(uint_t i = 0; i < num_blocks; i++) {
    // how many are going to this leaf
    uint_t count_for_block = count_per_block + (i < extra);
    // start of leaf in output
    uint_t in = i * BN;
    // start in input
    uint_t j2 = count_per_block*i +min(i,extra);
    uint_t j3 = j2;
    // // // // printf("real count %u, num_leaves %u, leaf %u, count_for_block = %u, in = %u, j2 = %u, j3 = %u\n", num_items, num_leaves, i, count_for_block, in, j2, j3);
    for(uint_t k = in; k < count_for_block + in; k++) {
     // assert(j2 < num_items);
      new_vals[k] = space_vals[j2];
      j2++;
    }
    
    for (uint_t k = in; k < count_for_block + in; k++) {
      new_dests[k] = space_dests[j3];
      if (new_dests[k] == SENT_VAL) {
        // fixing pointer of node that goes to this sentinel
        uint32_t node_index = space_vals[j3];
        fix_sentinel(node_index, k);
      }
      j3++;
    } 

    new_indices[i].index = new_dests[in];
    new_indices[i].non_null_num = count_for_block;
    new_indices[i].block_lock.init();
    new_indices[i].last_dist_time = 0.0;
  });

  free(space_dests);
  free(space_vals);
  free(vertex_array);
  free(edges_array);
  free(vals);
  free(dests);
  free(indices);
  vals = new_vals;
  dests = new_dests;
  indices = new_indices;
}
  
inline void SMA::double_list() {
  double_t time1 = getCurrentTimeAsDouble();
  N *= 2;
  num_blocks *= 2;
  H = H + 1;
  printf("Doubling the list, N = %u, num_blocks = %u, H = %u\n", N, num_blocks, H);
  uint32_t *new_dests = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  index_t *new_indices = (index_t *)aligned_alloc(64, num_blocks * sizeof(index_t));
  // printf("here 0\n");
  std::memcpy(new_vals, vals, (N / 2) * sizeof(uint32_t));
  std::memcpy(new_dests, dests, (N / 2) * sizeof(uint32_t));
  parlay::parallel_for(N / 2, N, [&](uint32_t i) {
  //for (uint32_t i = N / 2; i < N; i++) {
    new_vals[i] = NULL_VAL;
    new_dests[i] = NULL_VAL;
  //}
  });
  
  parlay::parallel_for(0, num_blocks, [&](uint32_t i) {
  //for (uint32_t i = 0; i < num_blocks; i++) {
    new_indices[i].index = NULL_VAL;
    new_indices[i].non_null_num = 0;
    new_indices[i].block_lock.init();
    new_indices[i].last_dist_time = 0.0;
  //}
  });
  double_t time2 = getCurrentTimeAsDouble();
  // printf("here 1\n");
  free(dests);
  free(vals);
  free(indices);
  // printf("here 2\n");
  dests = new_dests;
  vals = new_vals;
  indices = new_indices;
  // printf("here 3\n");
  redistribute(0, N);
  double_t time3 = getCurrentTimeAsDouble();
  printf("Time to double the list: %.6f seconds, %.6f seconds\n", time3 - time2, time2 - time1);
}

inline void SMA::half_list() {
  N /= 2;
  num_blocks /= 2;
  H = H - 1;
  printf("half the list, N = %u, num_blocks = %u, H = %u\n", N, num_blocks, H);
  uint32_t *new_dests = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  uint32_t *new_vals = (uint32_t *)aligned_alloc(64, N * sizeof(uint32_t));
  index_t *new_indices = (index_t *)aligned_alloc(64, num_blocks * sizeof(index_t));
 
  uint32_t j = 0;
  for (uint32_t i = 0; i < N * 2; i++) {
    if (dests[i] != NULL_VAL) {
      new_vals[j] = vals[i];
      new_dests[j] = dests[i];
      j++;
    }
  }
  for (uint_t i = j; i < N; i++) {
		new_vals[i] = NULL_VAL; 
    new_dests[i] = NULL_VAL;
	}

  for (uint_t i = 0; i < num_blocks; i++) {
    new_indices[i].index = NULL_VAL;
    new_indices[i].non_null_num = 0;
    new_indices[i].block_lock.init();
    new_indices[i].last_dist_time = 0.0;
  }

  free(vals);
  free(dests);
  free(indices);
  vals = new_vals;
  dests = new_dests;
  indices = new_indices;
  redistribute(0, N);
}

inline void SMA::redistribute(uint_t index, uint32_t len) {
  uint32_t *space_vals = (uint32_t *)aligned_alloc(64, len * sizeof(uint32_t));
  uint32_t *space_dests = (uint32_t *)aligned_alloc(64, len * sizeof(uint32_t));
  
  uint_t j = 0;
  for (uint_t i = index; i < index + len; i += 16) {
    for (uint_t k = i; k < i + 16; k++) {
      space_vals[j] = vals[k];
      space_dests[j] = dests[k];
      // counting non-null edges
      j += (space_dests[j]!=NULL_VAL);
    }
    // why
    memset (__builtin_assume_aligned((void*)&vals[i], 64), NULL_VAL, 16*sizeof(uint32_t));
    memset (__builtin_assume_aligned((void*)&dests[i], 64), NULL_VAL, 16*sizeof(uint32_t));
  }
  
  uint_t num_b = len / BN;
  uint_t count_per_block = j / num_b;
  uint_t extra = j % num_b;
  __builtin_prefetch ((void *)&nodes, 0, 3);

  for (uint_t i = 0; i < num_b; i++) {
    uint_t count_for_block = count_per_block + (i < extra);
    uint_t in = index + (BN * i);
    uint_t j2 = count_per_block*i + min(i,extra);
    uint_t j3 = j2;
    memcpy(__builtin_assume_aligned((void*)&vals[in], 64), (void*)&space_vals[j2], count_for_block*sizeof(uint32_t));
    for (uint_t k = in; k < count_for_block + in; k++) {
      dests[k] = space_dests[j3];
      if (dests[k] == SENT_VAL) {
        uint32_t node_index = vals[k];
        fix_sentinel(node_index, k);
      }
      j3++;
    }
    
    uint32_t block_id = in / BN;
    indices[block_id].index = dests[in];
    indices[block_id].non_null_num = count_for_block;
    indices[block_id].last_dist_time = getCurrentTimeAsDouble();
  }

  free(space_dests);
  free(space_vals);
}

inline void SMA::redistribute_par(uint_t index, uint32_t len) {
  uint32_t *space_vals = (uint32_t *)aligned_alloc(64, len * sizeof(uint32_t));
  uint32_t *space_dests = (uint32_t *)aligned_alloc(64, len * sizeof(uint32_t));
  
  uint_t j = 0;
  for (uint_t i = index; i < index + len; i += 16) {
    for (uint_t k = i; k < i + 16; k++) {
      space_vals[j] = vals[k];
      space_dests[j] = dests[k];
      // counting non-null edges
      j += (space_dests[j]!=NULL_VAL);
    }
    // why
    memset (__builtin_assume_aligned((void*)&vals[i], 64), NULL_VAL, 16*sizeof(uint32_t));
    memset (__builtin_assume_aligned((void*)&dests[i], 64), NULL_VAL, 16*sizeof(uint32_t));
  }
  
  uint_t num_blocks = len / BN;
  uint_t count_per_block = j / num_blocks;
  uint_t extra = j % num_blocks;
  __builtin_prefetch ((void *)&nodes, 0, 3);
  
  //parlay::parallel_for(0, num_blocks, [&](uint32_t i) {
  for (uint_t i = 0; i < num_blocks; i++) {
    uint_t count_for_block = count_per_block + (i < extra);
    uint_t in = index + (BN * i);
    uint_t j2 = count_per_block*i + min(i,extra);
    uint_t j3 = j2;
    memcpy(__builtin_assume_aligned((void*)&vals[in], 64), (void*)&space_vals[j2], count_for_block*sizeof(uint32_t));
    for (uint_t k = in; k < count_for_block + in; k++) {
      dests[k] = space_dests[j3];
      if (dests[k] == SENT_VAL) {
        uint32_t node_index = vals[k];
        fix_sentinel(node_index, k);
      }
      j3++;
    }
  
    uint32_t block_id = in / BN;
    indices[block_id].index = space_dests[in];
    indices[block_id].non_null_num = count_for_block;
    indices[block_id].last_dist_time = getCurrentTimeAsDouble();
  }
  //});

  free(space_dests);
  free(space_vals);
}

void inline SMA::slide_right(uint_t index) {
  // make sure to slide in a block
  uint32_t cur_block_index = find_node(index, BN);
  uint32_t next_block_index = (cur_block_index + BN < N) ? (cur_block_index + BN) : N;
  uint32_t el_dest = dests[index];
  uint32_t el_value = vals[index];
  dests[index] = NULL_VAL;
  vals[index] = NULL_VAL;
  index++;
  while (index < next_block_index && dests[index] != NULL_VAL) {
    uint32_t temp_dest = dests[index];
    uint32_t temp_value = vals[index];
    dests[index] = el_dest;
    vals[index] = el_value;
    if (el_dest == SENT_VAL) {
      uint32_t node_index = el_value;
      fix_sentinel(node_index, index);
    }
    el_dest = temp_dest;
    el_value = temp_value;
    index++;
  }
  
  dests[index] = el_dest;
  vals[index] = el_value;
  if (el_dest == SENT_VAL) {
    uint32_t node_index = el_value;
    fix_sentinel(node_index, index);
  } 
}

void inline SMA::slide_left(uint_t index) {
  // make sure to slide in a block
  uint32_t cur_block_index = find_node(index, BN);
  uint32_t next_block_index = (cur_block_index + BN < N) ? (cur_block_index + BN) : N;
  while (index + 1 < next_block_index) {
    uint32_t temp_dest = dests[index + 1];
    uint32_t temp_value = vals[index + 1];
    dests[index] = temp_dest;
    vals[index] = temp_value;
    if (temp_dest == SENT_VAL) {
      uint32_t node_index = temp_value;
      fix_sentinel(node_index, index);
    }
    if (dests[index] == NULL_VAL) {
      break;
    }
    index++;
  }
  dests[index + 1] = NULL_VAL;
  vals[index + 1] = NULL_VAL;
}

inline void SMA::block_inner_move(uint_t block_index) {
  uint32_t last_item_index = block_index + BN - 1;
  if (dests[last_item_index] != NULL_VAL) {
    redistribute(block_index, BN);
  }
}

inline void SMA::insert(uint_t index, uint32_t src, uint32_t dest, uint32_t value) {
  // insert in a block
  if (dests[index] == NULL_VAL) {
    dests[index] = dest;
    vals[index] = value;
  } else {
    if (dests[index] == dest) {
      vals[index] = value;
    } else {
      slide_right(index); 
      dests[index] = dest;
      vals[index] = value;
    }
  }
  __sync_fetch_and_add(&nodes[src].degree, 1);
}

inline pair_uint SMA::insert_dist(uint_t block_index) {
  uint32_t len = BN * 2;
  uint32_t node_index = find_node(block_index, len);
  double density = get_density(find_block_id(node_index), len / BN);
  double density_b = (double)UPPER_DENSITY_BOUND;
  pair_uint ret;

  while (density >= density_b) {
    len *= 2;
    if (len <= N) {
      node_index = find_node(node_index, len);
      density = get_density(find_block_id(node_index), len / BN);
    } else {
      ret.x = 0;
      ret.y = N;
      return ret;
    }
  }
  ret.x = node_index;
  ret.y = len;
  return ret;
}

void inline SMA::remove(uint_t index, uint32_t src, uint32_t dest) {
  // delete the element at index by slide left
  slide_left(index);
  __sync_fetch_and_add(&nodes[src].degree, -1);
}

inline pair_uint SMA::remove_dist(uint_t block_index) {
  uint32_t len = BN * 2;
  uint32_t node_index = find_node(block_index, len);
  double density = get_density(find_block_id(node_index), len / BN);
  double density_b = (double)LOWER_DENSITY_BOUND;
  pair_uint ret;

  while (density <= density_b) {
    len *= 2;
    if (len <= N) {
      node_index = find_node(node_index, len);
      density = get_density(find_block_id(node_index), len / BN);
    } else {
      ret.x = 0;
      ret.y = N;
      return ret;
    }
  }
  ret.x = node_index;
  ret.y = len;
  return ret;
}

inline void SMA::add_edge(uint32_t src, uint32_t dest, uint32_t value) {
  //   __builtin_prefetch(&nodes[src], 0, 3);
  // bool success = false;

  //  while (!success) {
    // if (sma_lock.check_unlocked()) {
      // __sync_fetch_and_add(&num_workers, 1);
      
      // double time_add = 1.0;//getCurrentTimeAsDouble();
      node_t node = nodes[src];
      uint32_t start;
      uint32_t end;
      uint32_t node_begin_id = node.beginning / BN;
      uint32_t node_end_id = node.end / BN;

      if (node_end_id == node_begin_id) {
        start = node.beginning + 1;
        end = node.end;
      } else {
        if (dest < indices[node_begin_id + 1].index) {
          start = node.beginning + 1;
          end = (node_begin_id + 1) * BN;
        } else if (dest >= indices[node_end_id].index) {
          start = node_end_id * BN;
          end = node.end;
        } else {
          for (uint32_t i = node_begin_id + 2; i <= node_end_id; i++) {
            if (dest < indices[i].index) {
              start = (i - 1) * BN;
              end = i * BN;
              break;
            } 
          } 
        }
      }

      uint32_t loc_to_add2 = sequential_search(dest, start, end);
      // uint32_t loc_to_add2 = binary_search(dest, start, end);
      //  printf("node_begin_id = %u, node_end_id = %u, node.beginning = %u, node.end = %u\n", node_begin_id, node_end_id, node.beginning, node.end);
      // printf("dest = %u, start = %u, end = %u\n", dest, start, end);
      // uint32_t start = (block_id_add == node_begin_id) ? node.beginning + 1 : (block_id_add * BN);
       // __builtin_prefetch(&dests[start], 0, 3);
      // uint32_t end = (block_id_add == node_end_id) ? node.end : ((block_id_add + 1) * BN);
      // __builtin_prefetch(&dests[end], 0, 3);
      // uint32_t block_id_add = rand()%num_blocks;
      // uint32_t loc_to_add2 = binary_search(dest, start, end);
      //  if (start != node.beginning + 1 || end != node.end) {
        //printf("Error in finding block to add edge!\n");
      //  }
      // uint32_t loc_to_add2 = binary_search(dest, node.beginning + 1, node.end);
      // uint32_t loc_to_add2 = binary_search(dest, start, end);
      //   printf("here 0 \n");
     //  indices[block_id_add].block_lock.lock();
      //  if (indices[block_id_add].last_dist_time > time_add) {
        // printf("here 1 \n");
        // get old index, retry
        //indices[block_id_add].block_lock.unlock();
        //__sync_fetch_and_add(&num_workers, -1);
        //continue;
      //  } else {
        //if (indices[block_id_add].non_null_num < BN) {
          // printf("here 2 \n");
          // 预取 nodes[block_id_add]
          //__builtin_prefetch(&nodes[block_id_add], 1, 0);
          //uint32_t loc_to_add1 = sequential_search(dest, node.beginning + 1, node.end);
          // uint32_t loc_to_add1 = sequential_search(dest, start, end);
          // uint32_t loc_to_add2 = binary_search(dest, node.beginning + 1, node.end);
          // uint32_t loc_to_add2 = binary_search(dest, start, end);
          // printf("here \n");
          //__builtin_prefetch ((void *)&vals[loc_to_add2], 1, 3);
          //if (loc_to_add1 != loc_to_add2) {
            //printf("loc_to_add1 = %u, loc_to_add2 = %u, start = %u, end = %u\n", loc_to_add1, loc_to_add2, start, end);
          //}
          //insert(loc_to_add2, src, dest, value);
          //indices[block_id_add].non_null_num++;
          //if (indices[block_id_add].non_null_num < BN) {
            //block_inner_move(block_id_add * BN);
          //}
          //success = true;
          //indices[block_id_add].block_lock.unlock();
          //__sync_fetch_and_add(&num_workers, -1);
          // finish add, return
          //return;
          //} else {
          /*
          if (indices[block_id_add].non_null_num == BN) {
          // printf("here 3 \n");
          //indices[block_id_add].block_lock.unlock();
            pair_uint dist_range = insert_dist(block_id_add * BN);
            if (dist_range.y != N) {
            // printf("here 4 \n");
            //grab_locks_range(dist_range.x, dist_range.y);
              redistribute(dist_range.x, dist_range.y);
            //release_locks_range(dist_range.x, dist_range.y);
            //__sync_fetch_and_add(&num_workers, -1);
            // after distination, retry
            //continue;
            } else {
            // printf("here 5 \n");
            //if (sma_lock.try_lock()) {
              //while (num_workers > 1) {
                // wait for other workers to finish
                //std::this_thread::sleep_for(std::chrono::milliseconds(10));
              //}
              double_list();
              //sma_lock.unlock();
            //}
            //__sync_fetch_and_add(&num_workers, -1);
            // after double, retry
            //continue;
            }
          }*/
     // }
    // }
  // }
}

inline void SMA::remove_edge(uint32_t src, uint32_t dest) {
  bool success = false;
  
  while (!success) {
    if (sma_lock.check_unlocked()) {
      __sync_fetch_and_add(&num_workers, 1);

      double time_remove = getCurrentTimeAsDouble();
      node_t node = nodes[src];
      uint32_t node_begin_id = find_block_id(node.beginning);
      uint32_t node_end_id = find_block_id(node.end);
      uint32_t block_id_remove = node_begin_id;
      if (node_begin_id != node_end_id) {
        if (dest > indices[node_end_id].index) {
          block_id_remove = node_end_id;
        } else {
          for (uint32_t i = node_begin_id + 1; i <= node_end_id; i++) {
            if (dest < indices[i].index) {
              block_id_remove = i - 1;
              break;
            } 
          }
        }
      }
      // printf("here 0 \n");
      indices[block_id_remove].block_lock.lock();
      if (indices[block_id_remove].last_dist_time > time_remove) {
        // printf("here 1 \n");
        // get old index, retry
        indices[block_id_remove].block_lock.unlock();
        __sync_fetch_and_add(&num_workers, -1);
        continue;
      } else {
        // printf("here 2 \n");
        uint32_t start = (block_id_remove == node_begin_id) ? node.beginning + 1 : (block_id_remove * BN);
        uint32_t end = (block_id_remove == node_end_id) ? node.end : ((block_id_remove + 1) * BN);
        uint32_t loc_to_remove = binary_search(dest, start, end);
        if (dests[loc_to_remove] == dest) {
          // printf("here 3 \n");
          remove(loc_to_remove, src, dest);
          indices[block_id_remove].non_null_num--;
          if (loc_to_remove % BN == 0) {
            // if we removed the first element in the block, we need to update the index
            indices[block_id_remove].index = dests[block_id_remove * BN];
          }
          success = true;
          indices[block_id_remove].block_lock.unlock();

          if (get_density(block_id_remove, BN) < LOWER_DENSITY_BOUND) {
            pair_uint dist_range = remove_dist(block_id_remove * BN);
            if (dist_range.y != N) {
              grab_locks_range(dist_range.x, dist_range.y);
              redistribute(dist_range.x, dist_range.y);
              release_locks_range(dist_range.x, dist_range.y);
            } else {
              if (sma_lock.try_lock()) {
                while (num_workers > 1) {
                  // wait for other workers to finish
                  std::this_thread::sleep_for(std::chrono::milliseconds(10));
                }
                half_list();
                sma_lock.unlock();
              }
            }
          }
          __sync_fetch_and_add(&num_workers, -1);
          // finish remove, return
          return;
        } else {
          // not found, return
          indices[block_id_remove].block_lock.unlock();
          __sync_fetch_and_add(&num_workers, -1);
          return;
        }
      }
    }   
  }
}

inline void SMA::add_edge_batch(pair_uint *es, uint_t edge_count) {
  // parlay::parallel_for(0, edge_count, [&](uint32_t i) {
  for (uint32_t i = 0; i < edge_count; i++) {
    uint32_t src = es[i].x;
    uint32_t dest = es[i].y;
    uint32_t value = 1; // default value for edges
    // printf("here /n");
    add_edge(src, dest, value);
  }
  //});
}

inline void SMA::remove_edge_batch(pair_uint *es, uint_t edge_count) {
  // parlay::parallel_for(0, edge_count, [&](uint32_t i) {
  for (uint32_t i = 0; i < edge_count; i++) {
    uint32_t src = es[i].x;
    uint32_t dest = es[i].y;
    remove_edge(src, dest);
  // });
  }
}

inline void SMA::grab_locks_range(uint32_t block_index_begin, uint32_t len) {
  bool success = false;
  while (!success) {
    uint32_t locks_num = 0;
    for (uint_t i = block_index_begin; i < block_index_begin + len; i += BN) {
      if (!indices[find_block_id(i)].block_lock.try_lock()) {
        release_locks_range(block_index_begin, i - block_index_begin);
        break;
      } else {
        locks_num++;
      }
    }
    if (locks_num == len / BN) {
      success = true;
    }
  }
}

inline void SMA::release_locks_range(uint32_t block_index_begin, uint32_t len) {
  for (uint_t i = block_index_begin; i < block_index_begin + len; i += BN) {
    indices[find_block_id(i)].block_lock.unlock();
  }
}

}
