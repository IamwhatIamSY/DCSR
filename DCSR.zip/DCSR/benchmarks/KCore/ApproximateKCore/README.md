This directory includes an implementation of a (2+\epsilon)-approxiamte coreness
algorithm that runs in O(n + m) work and O(\log^3 n) depth on the fetch-add binary-forking model.

