This package implements the 2-approximate densest subgraph algorithm
by Charikar.

Reference:
@inproceedings{charikar2000greedy,
  title={Greedy approximation algorithms for finding dense components in a graph},
  author={Charikar, Moses},
  booktitle={International Workshop on Approximation Algorithms for Combinatorial Optimization},
  pages={84--95},
  year={2000},
  organization={Springer}
}
