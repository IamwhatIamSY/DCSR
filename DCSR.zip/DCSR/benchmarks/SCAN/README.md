# SCAN

SCAN is a graph clustering algorithm, introduced in "SCAN: A Structural
Clustering Algorithm for Networks" by Xu et al.
